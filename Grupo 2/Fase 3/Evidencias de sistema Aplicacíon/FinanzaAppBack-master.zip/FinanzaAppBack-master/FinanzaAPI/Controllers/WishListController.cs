﻿using FinanzaAPI.Data;
using FinanzaAPI.DTO;
using FinanzaAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FinanzaAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class WishlistController : ControllerBase
    {
        private readonly AppDbContext _context;

        public WishlistController(AppDbContext context)
        {
            _context = context;
        }

        // POST api/Wishlist/Ensure
        // Crea una wishlist para el usuario si no existe y devuelve IdWishlist
        [HttpPost("Ensure")]
        public async Task<ActionResult<object>> EnsureWishlist([FromBody] WishlistEnsureDto dto)
        {
            if (dto.IdUsuario <= 0)
                return BadRequest("IdUsuario inválido");

            var existing = await _context.Wishlists
                .FirstOrDefaultAsync(w => w.IdUsuario == dto.IdUsuario);

            if (existing == null)
            {
                existing = new Wishlist
                {
                    IdUsuario = dto.IdUsuario,
                    Total = 0
                };

                _context.Wishlists.Add(existing);
                await _context.SaveChangesAsync();
            }

            return Ok(new { idWishlist = existing.IdWishlist });
        }

        // GET api/Wishlist/WithItems/5
        [HttpGet("WithItems/{idUsuario:int}")]
        public async Task<ActionResult<WishlistWithItemsDto>> GetWishlistWithItems(int idUsuario)
        {
            var wl = await _context.Wishlists
                .FirstOrDefaultAsync(w => w.IdUsuario == idUsuario);

            if (wl == null)
            {
                return Ok(new WishlistWithItemsDto
                {
                    Wishlist = null,
                    Items = new List<WishlistItemDto>()
                });
            }

            var items = await _context.WishListDetalles
                .Where(d => d.IdWishlist == wl.IdWishlist)
                .OrderByDescending(d => d.IdWishlistDetalle)
                .ToListAsync();

            var dto = new WishlistWithItemsDto
            {
                Wishlist = new WishlistDto
                {
                    IdWishlist = wl.IdWishlist,
                    IdUsuario = wl.IdUsuario,
                    Total = decimal.Parse(wl.Total.ToString()),
                },
                Items = items.Select(d => new WishlistItemDto
                {
                    IdWishlistDetalle = d.IdWishlistDetalle,
                    IdWishlist = d.IdWishlist,
                    Nombre = d.Nombre,
                    Monto = d.Monto,
                    FechaLimite = d.FechaLimite,
                    Descripcion = d.Descripcion,
                    Ahorrado = d.Ahorrado,
                    Completado = d.Completado
                }).ToList()
            };

            return Ok(dto);
        }

        // POST api/Wishlist/Item
        [HttpPost("Item")]
        public async Task<ActionResult<object>> AddItem([FromBody] WishlistItemCreateDto dto)
        {
            if (dto.IdWishlist <= 0)
                return BadRequest("IdWishlist inválido");

            var wl = await _context.Wishlists
                .FirstOrDefaultAsync(w => w.IdWishlist == dto.IdWishlist);

            if (wl == null)
                return NotFound("Wishlist no encontrada");

            var item = new WishListDetalle
            {
                IdWishlist = dto.IdWishlist,
                Nombre = dto.Nombre,
                Monto = dto.Monto,
                FechaLimite = dto.FechaLimite,
                Descripcion = dto.Descripcion,
                Ahorrado = 0,
                Completado = 0
            };

            _context.WishListDetalles.Add(item);

            await _context.SaveChangesAsync();

            // Recalcular total
            wl.Total = await _context.WishListDetalles
                .Where(d => d.IdWishlist == wl.IdWishlist)
                .SumAsync(d => d.Monto);

            await _context.SaveChangesAsync();

            return Ok(new { idWishlistDetalle = item.IdWishlistDetalle });
        }

        // PUT api/Wishlist/Item/{id}
        [HttpPut("Item/{id:int}")]
        public async Task<IActionResult> UpdateItem(int id, [FromBody] WishlistItemUpdateDto dto)
        {
            var item = await _context.WishListDetalles
                .FirstOrDefaultAsync(d => d.IdWishlistDetalle == id);

            if (item == null)
                return NotFound();

            item.Nombre = dto.Nombre;
            item.Monto = dto.Monto;
            item.FechaLimite = dto.FechaLimite;
            item.Descripcion = dto.Descripcion;

            await _context.SaveChangesAsync();

            // Recalcular total
            var wl = await _context.Wishlists
                .FirstOrDefaultAsync(w => w.IdWishlist == item.IdWishlist);

            if (wl != null)
            {
                wl.Total = await _context.WishListDetalles
                    .Where(d => d.IdWishlist == wl.IdWishlist)
                    .SumAsync(d => d.Monto);

                await _context.SaveChangesAsync();
            }

            return NoContent();
        }

        // PUT api/Wishlist/Item/{id}/Progreso
        [HttpPut("Item/{id:int}/Progreso")]
        public async Task<IActionResult> UpdateProgreso(int id, [FromBody] WishlistItemProgresoDto dto)
        {
            var item = await _context.WishListDetalles
                .FirstOrDefaultAsync(d => d.IdWishlistDetalle == id);

            if (item == null)
                return NotFound();

            item.Ahorrado = dto.Ahorrado;
            item.Completado = dto.Completado;

            await _context.SaveChangesAsync();

            return NoContent();
        }

        // DELETE api/Wishlist/Item/{id}
        [HttpDelete("Item/{id:int}")]
        public async Task<IActionResult> DeleteItem(int id)
        {
            var item = await _context.WishListDetalles
                .FirstOrDefaultAsync(d => d.IdWishlistDetalle == id);

            if (item == null)
                return NotFound();

            var idWishlist = item.IdWishlist;

            _context.WishListDetalles.Remove(item);
            await _context.SaveChangesAsync();

            // Recalcular total
            var wl = await _context.Wishlists
                .FirstOrDefaultAsync(w => w.IdWishlist == idWishlist);

            if (wl != null)
            {
                wl.Total = await _context.WishListDetalles
                    .Where(d => d.IdWishlist == wl.IdWishlist)
                    .SumAsync(d => d.Monto);

                await _context.SaveChangesAsync();
            }

            return NoContent();
        }
    }
}
