﻿using FinanzaAPI.Data;
using FinanzaAPI.DTO;
using FinanzaAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FinanzaAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TestController : ControllerBase
    {
        private readonly AppDbContext _context;

        public TestController(AppDbContext context)
        {
            _context = context;
        }

        // Helper para parsear FechaNacim string -> DateTime?
        private static DateTime? ParseFechaNacim(string? value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return null;

            // Puedes ajustar el formato según cómo guardes la fecha ("yyyy-MM-dd", etc.)
            if (DateTime.TryParse(value, out var dt))
                return dt;

            return null;
        }

        private static string? FormatFechaNacim(DateTime? value)
        {
            // Guarda siempre en un formato consistente en la tabla usuario
            return value?.ToString("yyyy-MM-dd");
        }

        // GET api/Test/usuarios
        [HttpGet("usuarios")]
        public async Task<IActionResult> GetUsuarios()
        {
            var usuarios = await _context.Usuarios.ToListAsync();
            return Ok(usuarios);
        }

        // GET api/Test/usuarios/5
        [HttpGet("usuarios/{id:int}")]
        public async Task<IActionResult> GetUsuarioById(int id)
        {
            var user = await _context.Usuarios
                .Where(u => u.IdUsuario == id)
                .Select(u => new UsuarioDto
                {
                    IdUsuario = u.IdUsuario,
                    Nombre = u.Nombre,
                    Apellido = u.Apellido,
                    Correo = u.Correo,
                    Contra = u.Contra,
                    // ⬇️ Manejo seguro de null
                    FechaNacim = ParseFechaNacim(u.FechaNacim),
                    Avatar = u.Avatar
                })
                .FirstOrDefaultAsync();

            if (user == null)
                return NotFound();

            return Ok(user);
        }

        // GET api/Test/ByCorreo?correo=xxx
        [HttpGet("ByCorreo")]
        public async Task<IActionResult> GetByCorreo([FromQuery] string correo)
        {
            if (string.IsNullOrWhiteSpace(correo))
                return BadRequest("Correo requerido");

            var lower = correo.Trim().ToLower();

            var user = await _context.Usuarios
                .Where(u => u.Correo.ToLower() == lower)
                .Select(u => new UsuarioDto
                {
                    IdUsuario = u.IdUsuario,
                    Nombre = u.Nombre,
                    Apellido = u.Apellido,
                    Correo = u.Correo,
                    Contra = u.Contra,
                    // ⬇️ Manejo seguro de null
                    FechaNacim = ParseFechaNacim(u.FechaNacim),
                    Avatar = u.Avatar
                })
                .FirstOrDefaultAsync();

            if (user == null)
                return Ok(null); // front espera null

            return Ok(user);
        }

        // POST api/Test/seed
        [HttpPost("seed")]
        public async Task<IActionResult> Seed()
        {
            var user = new Usuario
            {
                Nombre = "Usuario EF",
                Apellido = "Prueba",
                Correo = "ef@finanzapp.cl",
                FechaNacim = null
            };

            _context.Usuarios.Add(user);
            await _context.SaveChangesAsync();

            return Ok(user);
        }

        // POST api/Test/SingUp
        [HttpPost("SingUp")]
        public async Task<IActionResult> SingUp([FromBody] UsuarioDto dto)
        {
            try
            {
                var user = new Usuario
                {
                    Nombre = dto.Nombre,
                    Apellido = dto.Apellido,
                    Correo = dto.Correo,
                    Contra = dto.Contra,
                    // ⬇️ Guardamos como string formateado o null
                    FechaNacim = FormatFechaNacim(dto.FechaNacim),
                    Avatar = dto.Avatar
                };

                _context.Usuarios.Add(user);
                await _context.SaveChangesAsync();

                var result = new UsuarioDto
                {
                    IdUsuario = user.IdUsuario,
                    Nombre = user.Nombre,
                    Apellido = user.Apellido,
                    Correo = user.Correo,
                    // ⬇️ Volvemos a DateTime? usando el helper
                    FechaNacim = ParseFechaNacim(user.FechaNacim),
                    Avatar = user.Avatar
                };

                return Ok(result);
            }
            catch (Exception ex)
            {
                // aquí podrías loguear ex con algún logger
                return BadRequest("Error al registrar usuario");
            }
        }

        // POST api/Test/ExisteCorreo
        [HttpPost("ExisteCorreo")]
        public async Task<IActionResult> ExisteCorreo([FromBody] UsuarioDto dto)
        {
            if (string.IsNullOrWhiteSpace(dto.Correo))
                return Ok(false);

            var correo = dto.Correo.Trim().ToLower();

            bool existe = await _context.Usuarios
                .AnyAsync(u => u.Correo.ToLower() == correo);

            return Ok(existe);
        }

        // POST api/Test/SingIn
        [HttpPost("SingIn")]
        public async Task<IActionResult> SingIn([FromBody] UsuarioDto dto)
        {
            if (string.IsNullOrWhiteSpace(dto.Correo) || string.IsNullOrWhiteSpace(dto.Contra))
                return BadRequest("Correo y contraseña requeridos");

            var correo = dto.Correo.Trim().ToLower();
            var contra = dto.Contra;

            var user = await _context.Usuarios
                .Where(u => u.Correo.ToLower() == correo && u.Contra == contra)
                .Select(u => new UsuarioDto
                {
                    IdUsuario = u.IdUsuario,
                    Nombre = u.Nombre,
                    Apellido = u.Apellido,
                    Correo = u.Correo,
                    // ⬇️ Manejo null seguro
                    FechaNacim = ParseFechaNacim(u.FechaNacim),
                    Avatar = u.Avatar
                })
                .FirstOrDefaultAsync();

            if (user == null)
                return BadRequest("Credenciales inválidas");

            return Ok(user);
        }
    }
}
