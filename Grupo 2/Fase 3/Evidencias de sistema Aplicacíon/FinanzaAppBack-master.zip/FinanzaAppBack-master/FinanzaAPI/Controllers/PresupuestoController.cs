﻿using FinanzaAPI.Data;
using FinanzaAPI.DTO;
using FinanzaAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FinanzaAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PresupuestoController : ControllerBase
    {
        private readonly AppDbContext _context;

        public PresupuestoController(AppDbContext context)
        {
            _context = context;
        }

        private static string GetPeriodKey(DateTime date)
        {
            return $"{date.Year:D4}-{date.Month:D2}";
        }

        /// <summary>
        /// Devuelve el último período (YYYY-MM) que tiene el usuario en Income/Expense.
        /// Si no tiene ninguno, toma el mes actual y, opcionalmente, puede normalizar
        /// registros antiguos con Period NULL/"" para ese usuario.
        /// </summary>
        private async Task<string> GetUserCurrentPeriodAsync(int userId)
        {
            // Todos los períodos no vacíos en incomes y expenses
            var incomePeriods = await _context.Incomes
                .Where(i => i.UserId == userId && !string.IsNullOrEmpty(i.Period))
                .Select(i => i.Period!)
                .ToListAsync();

            var expensePeriods = await _context.Expenses
                .Where(e => e.UserId == userId && !string.IsNullOrEmpty(e.Period))
                .Select(e => e.Period!)
                .ToListAsync();

            var allPeriods = incomePeriods.Concat(expensePeriods).ToList();

            if (allPeriods.Count == 0)
            {
                // Si el usuario no tiene períodos, usamos el mes actual
                var now = DateTime.UtcNow;
                var basePeriod = GetPeriodKey(now);

                // Si quieres, puedes normalizar registros antiguos sin Period:
                var incomesNoPeriod = await _context.Incomes
                    .Where(i => i.UserId == userId &&
                                (i.Period == null || i.Period == ""))
                    .ToListAsync();

                var expensesNoPeriod = await _context.Expenses
                    .Where(e => e.UserId == userId &&
                                (e.Period == null || e.Period == ""))
                    .ToListAsync();

                if (incomesNoPeriod.Count > 0 || expensesNoPeriod.Count > 0)
                {
                    foreach (var i in incomesNoPeriod)
                        i.Period = basePeriod;

                    foreach (var e in expensesNoPeriod)
                        e.Period = basePeriod;

                    await _context.SaveChangesAsync();
                }

                return basePeriod;
            }

            // Los períodos están en formato YYYY-MM, por lo que el Max string funciona como máximo cronológico
            return allPeriods.Max()!;
        }

        /* ========== INCOMES ========== */

        // GET api/Presupuesto/incomes?userId=1[&period=2025-11]
        [HttpGet("incomes")]
        public async Task<ActionResult<IEnumerable<IncomeDto>>> GetIncomes(
            [FromQuery] int userId,
            [FromQuery] string? period = null)
        {
            if (userId <= 0)
                return BadRequest("userId inválido");

            // Si no te mandan período, usamos el PERÍODO ACTUAL del usuario
            if (string.IsNullOrWhiteSpace(period))
            {
                period = await GetUserCurrentPeriodAsync(userId);
            }

            var incomes = await _context.Incomes
                .Where(i => i.UserId == userId && i.Period == period)
                .OrderByDescending(i => i.Id)
                .ToListAsync();

            var result = incomes.Select(i => new IncomeDto
            {
                Id = i.Id,
                UserId = i.UserId,
                Name = i.Name,
                Amount = i.Amount,
                IsFixed = i.IsFixed,
                Date = i.Date,
                InstallmentsTotal = i.InstallmentsTotal,
                Period = i.Period
            });

            return Ok(result);
        }

        // POST api/Presupuesto/incomes
        [HttpPost("incomes")]
        public async Task<ActionResult<IncomeDto>> AddIncome([FromBody] IncomeCreateDto dto)
        {
            if (dto.UserId <= 0)
                return BadRequest("UserId inválido");

            var userExists = await _context.Usuarios
                .AnyAsync(u => u.IdUsuario == dto.UserId);

            if (!userExists)
                return BadRequest($"Usuario {dto.UserId} no existe");

            try
            {
                var now = DateTime.UtcNow;
                var date = dto.Date ?? now;

                // Si el front no manda Period, usamos el período actual del usuario
                string period;
                if (string.IsNullOrWhiteSpace(dto.Period))
                {
                    period = await GetUserCurrentPeriodAsync(dto.UserId);
                }
                else
                {
                    period = dto.Period;
                }

                var income = new Income
                {
                    UserId = dto.UserId,
                    Name = dto.Name,
                    Amount = dto.Amount,
                    IsFixed = dto.IsFixed,
                    Date = date,
                    InstallmentsTotal = dto.InstallmentsTotal ?? 0,
                    Period = period
                };

                _context.Incomes.Add(income);
                await _context.SaveChangesAsync();

                var result = new IncomeDto
                {
                    Id = income.Id,
                    UserId = income.UserId,
                    Name = income.Name,
                    Amount = income.Amount,
                    IsFixed = income.IsFixed,
                    Date = income.Date,
                    InstallmentsTotal = income.InstallmentsTotal,
                    Period = income.Period
                };

                return Ok(result);
            }
            catch (DbUpdateException dbEx)
            {
                return StatusCode(500,
                    $"Error BD al insertar Income: {dbEx.InnerException?.Message ?? dbEx.Message}");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al insertar Income: {ex.Message}");
            }
        }

        // PUT api/Presupuesto/incomes/{id}
        [HttpPut("incomes/{id:int}")]
        public async Task<ActionResult<IncomeDto>> UpdateIncome(int id, [FromBody] IncomeUpdateDto dto)
        {
            if (dto.UserId <= 0)
                return BadRequest("UserId inválido");

            var income = await _context.Incomes
                .FirstOrDefaultAsync(i => i.Id == id && i.UserId == dto.UserId);

            if (income == null)
                return NotFound();

            income.Name = dto.Name;
            income.Amount = dto.Amount;
            income.IsFixed = dto.IsFixed;
            income.Date = dto.Date;
            income.InstallmentsTotal = dto.InstallmentsTotal ?? income.InstallmentsTotal;

            if (!string.IsNullOrWhiteSpace(dto.Period))
                income.Period = dto.Period;

            await _context.SaveChangesAsync();

            var result = new IncomeDto
            {
                Id = income.Id,
                UserId = income.UserId,
                Name = income.Name,
                Amount = income.Amount,
                IsFixed = income.IsFixed,
                Date = income.Date,
                InstallmentsTotal = income.InstallmentsTotal,
                Period = income.Period
            };

            return Ok(result);
        }

        // DELETE api/Presupuesto/incomes/{id}?userId=1
        [HttpDelete("incomes/{id:int}")]
        public async Task<IActionResult> DeleteIncome(int id, [FromQuery] int userId)
        {
            if (userId <= 0)
                return BadRequest("userId inválido");

            var income = await _context.Incomes
                .FirstOrDefaultAsync(i => i.Id == id && i.UserId == userId);

            if (income == null)
                return NotFound();

            _context.Incomes.Remove(income);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        /* ========== EXPENSES ========== */

        // GET api/Presupuesto/expenses?userId=1[&period=2025-11]
        [HttpGet("expenses")]
        public async Task<ActionResult<IEnumerable<ExpenseDto>>> GetExpenses(
            [FromQuery] int userId,
            [FromQuery] string? period = null)
        {
            if (userId <= 0)
                return BadRequest("userId inválido");

            // Igual que incomes: si no mandan período, usamos el PERÍODO ACTUAL del usuario
            if (string.IsNullOrWhiteSpace(period))
            {
                period = await GetUserCurrentPeriodAsync(userId);
            }

            var expenses = await _context.Expenses
                .Where(e => e.UserId == userId && e.Period == period)
                .OrderByDescending(e => e.Id)
                .ToListAsync();

            var result = expenses.Select(e => new ExpenseDto
            {
                Id = e.Id,
                UserId = e.UserId,
                Name = e.Name,
                Amount = e.Amount,
                Day = e.Day,
                IsFixed = e.IsFixed,
                Date = e.Date,
                InstallmentsTotal = e.InstallmentsTotal,
                Period = e.Period
            });

            return Ok(result);
        }

        // POST api/Presupuesto/expenses
        [HttpPost("expenses")]
        public async Task<ActionResult<ExpenseDto>> AddExpense([FromBody] ExpenseCreateDto dto)
        {
            if (dto.UserId <= 0)
                return BadRequest("UserId inválido");

            var userExists = await _context.Usuarios
                .AnyAsync(u => u.IdUsuario == dto.UserId);

            if (!userExists)
                return BadRequest($"Usuario {dto.UserId} no existe");

            try
            {
                var now = DateTime.UtcNow;
                var date = dto.Date ?? now;

                string period;
                if (string.IsNullOrWhiteSpace(dto.Period))
                {
                    period = await GetUserCurrentPeriodAsync(dto.UserId);
                }
                else
                {
                    period = dto.Period;
                }

                var expense = new Expense
                {
                    UserId = dto.UserId,
                    Name = dto.Name,
                    Amount = dto.Amount,
                    Day = dto.Day,
                    IsFixed = dto.IsFixed,
                    Date = date,
                    InstallmentsTotal = dto.InstallmentsTotal ?? 0,
                    Period = period
                };

                _context.Expenses.Add(expense);
                await _context.SaveChangesAsync();

                var result = new ExpenseDto
                {
                    Id = expense.Id,
                    UserId = expense.UserId,
                    Name = expense.Name,
                    Amount = expense.Amount,
                    Day = expense.Day,
                    IsFixed = expense.IsFixed,
                    Date = expense.Date,
                    InstallmentsTotal = expense.InstallmentsTotal,
                    Period = expense.Period
                };

                return Ok(result);
            }
            catch (DbUpdateException dbEx)
            {
                return StatusCode(500,
                    $"Error BD al insertar Expense: {dbEx.InnerException?.Message ?? dbEx.Message}");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al insertar Expense: {ex.Message}");
            }
        }

        // PUT api/Presupuesto/expenses/{id}
        [HttpPut("expenses/{id:int}")]
        public async Task<ActionResult<ExpenseDto>> UpdateExpense(int id, [FromBody] ExpenseUpdateDto dto)
        {
            if (dto.UserId <= 0)
                return BadRequest("UserId inválido");

            var expense = await _context.Expenses
                .FirstOrDefaultAsync(e => e.Id == id && e.UserId == dto.UserId);

            if (expense == null)
                return NotFound();

            expense.Name = dto.Name;
            expense.Amount = dto.Amount;
            expense.Day = dto.Day;
            expense.IsFixed = dto.IsFixed;
            expense.Date = dto.Date;
            expense.InstallmentsTotal = dto.InstallmentsTotal ?? expense.InstallmentsTotal;

            if (!string.IsNullOrWhiteSpace(dto.Period))
                expense.Period = dto.Period;

            await _context.SaveChangesAsync();

            var result = new ExpenseDto
            {
                Id = expense.Id,
                UserId = expense.UserId,
                Name = expense.Name,
                Amount = expense.Amount,
                Day = expense.Day,
                IsFixed = expense.IsFixed,
                Date = expense.Date,
                InstallmentsTotal = expense.InstallmentsTotal,
                Period = expense.Period
            };

            return Ok(result);
        }

        // DELETE api/Presupuesto/expenses/{id}?userId=1
        [HttpDelete("expenses/{id:int}")]
        public async Task<IActionResult> DeleteExpense(int id, [FromQuery] int userId)
        {
            if (userId <= 0)
                return BadRequest("userId inválido");

            var expense = await _context.Expenses
                .FirstOrDefaultAsync(e => e.Id == id && e.UserId == userId);

            if (expense == null)
                return NotFound();

            _context.Expenses.Remove(expense);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
