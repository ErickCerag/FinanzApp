﻿using FinanzaAPI.Data;
using FinanzaAPI.DTO;
using FinanzaAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[ApiController]
[Route("api/[controller]")]
public class SyncController : ControllerBase
{
    private readonly AppDbContext _context;
    public SyncController(AppDbContext context) => _context = context;

    // POST api/Sync/incomes/push
    [HttpPost("incomes/push")]
    public async Task<ActionResult<IEnumerable<IncomeSyncPushResponseItemDto>>> PushIncomes(
        [FromBody] IEnumerable<IncomeSyncItemDto> items)
    {
        var responses = new List<IncomeSyncPushResponseItemDto>();

        foreach (var item in items)
        {
            // Verificamos que el usuario existe
            var userExists = await _context.Usuarios
                .AnyAsync(u => u.IdUsuario == item.UserId);
            if (!userExists)
                continue;

            Income? income = null;

            if (item.ServerId.HasValue)
            {
                // Ya existe en servidor → update / delete
                income = await _context.Incomes
                    .FirstOrDefaultAsync(i => i.Id == item.ServerId.Value && i.UserId == item.UserId);
            }

            if (income == null && !item.IsDeleted)
            {
                // Nuevo registro en servidor
                income = new Income
                {
                    UserId = item.UserId
                };
                _context.Incomes.Add(income);
            }

            if (income == null && item.IsDeleted)
            {
                // Era algo nuevo local borrado antes de subirlo → ignoramos
                continue;
            }

            if (income != null)
            {
                // Regla simple: siempre aceptamos la versión más nueva (por UpdatedAt)
                if (income.UpdatedAt <= item.UpdatedAt)
                {
                    income.Name = item.Name;
                    income.Amount = item.Amount;
                    income.IsFixed = item.IsFixed;
                    income.Date = item.Date;
                    income.IsDeleted = item.IsDeleted;
                    income.UpdatedAt = item.UpdatedAt;
                }

                await _context.SaveChangesAsync();

                responses.Add(new IncomeSyncPushResponseItemDto
                {
                    LocalId = item.LocalId,
                    ServerId = income.Id,
                    UpdatedAt = DateTime.Parse(income.UpdatedAt.ToString())
                });
            }
        }

        return Ok(responses);
    }

    // GET api/Sync/incomes/pull?userId=1&since=2025-01-01T00:00:00Z
    [HttpGet("incomes/pull")]
    public async Task<ActionResult<IEnumerable<IncomeSyncPullItemDto>>> PullIncomes(
        [FromQuery] int userId,
        [FromQuery] DateTime since)
    {
        if (userId <= 0)
            return BadRequest("userId inválido");

        var incomes = await _context.Incomes
            .Where(i => i.UserId == userId && i.UpdatedAt > since)
            .ToListAsync();

        var result = incomes.Select(i => new IncomeSyncPullItemDto
        {
            ServerId = i.Id,
            UserId = i.UserId,
            Name = i.Name,
            Amount = i.Amount,
            IsFixed = i.IsFixed,
            Date = i.Date,
            IsDeleted = i.IsDeleted,
            UpdatedAt = DateTime.Parse(i.UpdatedAt.ToString())
        });

        return Ok(result);
    }
}
