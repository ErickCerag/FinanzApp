﻿namespace FinanzaAPI.Models
{
    public class SchemaVersion
    {
        public int Id { get; set; }        // id (PRIMARY KEY, siempre 1)
        public int Version { get; set; }   // version (INTEGER)
    }
}
