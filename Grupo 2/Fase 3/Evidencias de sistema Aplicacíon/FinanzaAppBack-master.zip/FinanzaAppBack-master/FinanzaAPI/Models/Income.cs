﻿namespace FinanzaAPI.Models
{
    public class Income
    {
        public int Id { get; set; }

        public int UserId { get; set; }

        public string Name { get; set; } = string.Empty;

        public decimal Amount { get; set; }

        public bool IsFixed { get; set; }

        public DateTime? Date { get; set; }

        public bool IsDeleted { get; set; }
        public DateTime? UpdatedAt { get; set; }
        public int? InstallmentsTotal { get; set; }
        public string? Period { get; set; }
    }
}
