﻿namespace FinanzaAPI.Models
{
    public class Expense
    {
        public int Id { get; set; }

        public int UserId { get; set; }

        public string Name { get; set; } = string.Empty;

        public decimal Amount { get; set; }

        public int Day { get; set; } = 1; // Día del mes en que ocurre (1-31)

        public bool IsFixed { get; set; }

        public DateTime? Date { get; set; }

        public bool IsDeleted { get; set; }
        public DateTime? UpdatedAt { get; set; }
        public string? Period { get; set; }
        public int? InstallmentsTotal { get; set; }
    }
}
