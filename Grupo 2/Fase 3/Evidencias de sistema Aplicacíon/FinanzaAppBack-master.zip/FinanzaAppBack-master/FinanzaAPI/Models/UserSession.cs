﻿namespace FinanzaAPI.Models
{

    public class UserSession
    {
        public int Id { get; set; }               // id (PRIMARY KEY, siempre 1)
        public int? RealUserId { get; set; }      // real_user_id (FOREIGN KEY a usuario.id_usuario)

        public Usuario? RealUser { get; set; }    // navegación → Usuario
    }

}
