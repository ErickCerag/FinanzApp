﻿namespace FinanzaAPI.Models
{
    public class Usuario
    {
        public int IdUsuario { get; set; }
        public string Nombre { get; set; } = null!;
        public string? Apellido { get; set; }
        public string? Correo { get; set; }
        public string? Contra { get; set; }
        public string? FechaNacim { get; set; }
        public string? Avatar { get; set; }

        public Wishlist? Wishlist { get; set; }
    }
}
