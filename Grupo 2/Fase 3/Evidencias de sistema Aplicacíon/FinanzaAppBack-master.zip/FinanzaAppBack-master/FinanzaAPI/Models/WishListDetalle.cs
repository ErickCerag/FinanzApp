﻿namespace FinanzaAPI.Models
{
    public class WishListDetalle
    {
        public int IdWishlistDetalle { get; set; }     // PK
        public int IdWishlist { get; set; }            // FK a Wishlist

        public string Nombre { get; set; } = string.Empty;
        public decimal Monto { get; set; }
        public string? FechaLimite { get; set; }
        public string? Descripcion { get; set; }

        // Nuevos campos (coinciden con SQLite del móvil)
        public decimal Ahorrado { get; set; }          // Total ahorrado
        public int Completado { get; set; }            // 0 o 1

        // Navegación
        public Wishlist Wishlist { get; set; } = null!;
    }
}
