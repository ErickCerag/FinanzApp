﻿namespace FinanzaAPI.Models
{
    public class Wishlist
    {
        public int IdWishlist { get; set; }            // PK
        public int IdUsuario { get; set; }             // FK a Usuario
        public decimal? Total { get; set; }            // Total acumulado (coincide con móvil)

        // Navegación
        public Usuario Usuario { get; set; } = null!;
        public ICollection<WishListDetalle> Detalles { get; set; } = new List<WishListDetalle>();
    }
}
