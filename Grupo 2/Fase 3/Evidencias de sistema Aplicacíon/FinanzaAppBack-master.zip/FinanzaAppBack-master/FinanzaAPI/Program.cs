﻿using FinanzaAPI.Data;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Render inyecta PORT, escuchamos en 0.0.0.0:PORT
var port = Environment.GetEnvironmentVariable("PORT") ?? "8080";
builder.WebHost.UseUrls($"http://0.0.0.0:{port}");

// Servicios básicos
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// DB
builder.Services.AddDbContext<AppDbContext>(options =>
{
    options.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection"));
});

// 🔓 CORS: permitir tu frontend de Render (y, opcional, localhost para desarrollo)
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowFrontend", policy =>
    {
        policy
            .WithOrigins(
                "https://finanzaappfront.onrender.com", // FRONT en Render
                "http://localhost:19006",               // Expo web (opcional)
                "http://localhost:3000",                // React dev (opcional)
                "http://localhost:5173",
                "http://localhost:7230",
                "http://localhost:8081"// Vite u otro (opcional)
            )
            .AllowAnyHeader()
            .AllowAnyMethod();
        // Si algún día usas cookies o credenciales:
        // .AllowCredentials();
    });
});

var app = builder.Build();

// Swagger (lo tienes abierto para prod, está ok para testing)
app.UseSwagger();
app.UseSwaggerUI();

// ⚠️ IMPORTANTE: NO redirigir a HTTPS dentro de Render
// Render ya termina HTTPS en el proxy externo.
// Si mantienes UseHttpsRedirection aquí, puedes romper el preflight CORS.
// app.UseHttpsRedirection();

// ✅ CORS ANTES de Authorization y MapControllers
app.UseCors("AllowFrontend");

app.UseAuthorization();

app.MapControllers();

app.Run();
