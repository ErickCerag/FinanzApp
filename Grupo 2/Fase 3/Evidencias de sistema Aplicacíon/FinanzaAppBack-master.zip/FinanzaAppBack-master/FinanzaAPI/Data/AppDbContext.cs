﻿using FinanzaAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace FinanzaAPI.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }


        public DbSet<Income> Incomes { get; set; } = null!;
        public DbSet<Expense> Expenses { get; set; } = null!;


        public DbSet<Usuario> Usuarios { get; set; } = null!;
        public DbSet<Wishlist> Wishlists { get; set; } = null!;
        public DbSet<WishListDetalle> WishListDetalles { get; set; } = null!;
        public DbSet<SchemaVersion> SchemaVersions { get; set; } = null!;
        public DbSet<UserSession> UserSessions { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // ======= income =======
            modelBuilder.Entity<Income>(entity =>
            {
                entity.ToTable("income");

                entity.HasKey(e => e.Id);

                entity.Property(e => e.Id)
                    .HasColumnName("id");

                entity.Property(e => e.UserId)
                    .HasColumnName("user_id");

                entity.Property(e => e.Name)
                    .HasColumnName("name");

                entity.Property(e => e.Amount)
                    .HasColumnName("amount")
                    .HasColumnType("numeric(12,2)");

                entity.Property(e => e.IsFixed)
                    .HasColumnName("isfixed");

                entity.Property(e => e.Period)
                  .HasColumnName("period");

                entity.Property(e => e.Date)
                    .HasColumnName("date");

                entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
                entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");

                entity.Property(e => e.InstallmentsTotal)
         .HasColumnName("installments_total");

                entity.HasOne<Usuario>()
                    .WithMany()
                    .HasForeignKey(e => e.UserId)
                    .HasConstraintName("FK_Income_Usuario")
                    .OnDelete(DeleteBehavior.Cascade);
            });

            modelBuilder.Entity<Expense>(entity =>
            {
                entity.ToTable("expense");

                entity.HasKey(e => e.Id);

                entity.Property(e => e.Id)
                    .HasColumnName("id");

                entity.Property(e => e.UserId)
                    .HasColumnName("user_id");

                entity.Property(e => e.Name)
                    .HasColumnName("name");

                entity.Property(e => e.Period)
                    .HasColumnName("period");

                entity.Property(e => e.Amount)
                    .HasColumnName("amount")
                    .HasColumnType("numeric(12,2)");

                entity.Property(e => e.Day)
                    .HasColumnName("day");

                entity.Property(e => e.IsFixed)
                    .HasColumnName("isfixed");

                entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
                entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
                entity.Property(e => e.InstallmentsTotal)
         .HasColumnName("installments_total");
                entity.Property(e => e.Date)
                    .HasColumnName("date");
                entity.HasOne<Usuario>()
                    .WithMany()
                    .HasForeignKey(e => e.UserId)
                    .HasConstraintName("FK_Expense_Usuario")
                    .OnDelete(DeleteBehavior.Cascade);
            });

            modelBuilder.Entity<Usuario>(entity =>
            {
                entity.ToTable("usuario");

                entity.HasKey(e => e.IdUsuario);

                entity.Property(e => e.IdUsuario)
                    .HasColumnName("id_usuario");

                entity.Property(e => e.Nombre)
                    .HasColumnName("nombre");

                entity.Property(e => e.Apellido)
                    .HasColumnName("apellido");

                entity.Property(e => e.Correo)
                    .HasColumnName("correo");

                entity.Property(e => e.Contra)
                    .HasColumnName("contra");

                entity.Property(e => e.FechaNacim)
                    .HasColumnName("fechanacim");

                entity.Property(e => e.Avatar)
                    .HasColumnName("avatar");
            });

            // ======= wishlist =======
            modelBuilder.Entity<Wishlist>(entity =>
            {
                entity.ToTable("wishlist");

                entity.HasKey(e => e.IdWishlist);

                entity.Property(e => e.IdWishlist)
                    .HasColumnName("id_wishlist");

                entity.Property(e => e.IdUsuario)
                    .HasColumnName("id_usuario");

                entity.Property(e => e.Total)
                    .HasColumnName("total")
                    .HasColumnType("numeric(12,2)");

                entity.HasOne(e => e.Usuario)
                    .WithOne(u => u.Wishlist)
                    .HasForeignKey<Wishlist>(e => e.IdUsuario)
                    .OnDelete(DeleteBehavior.Cascade);

                entity.HasIndex(e => e.IdUsuario)
                    .IsUnique();
            });

            // ======= wishlistdetalle =======
            modelBuilder.Entity<WishListDetalle>(entity =>
            {
                entity.ToTable("wishlistdetalle");

                entity.HasKey(e => e.IdWishlistDetalle);

                entity.Property(e => e.IdWishlistDetalle)
                    .HasColumnName("id_wishlistdetalle");

                entity.Property(e => e.IdWishlist)
                    .HasColumnName("id_wishlist");

                entity.Property(e => e.Nombre)
                    .HasColumnName("nombre");

                entity.Property(e => e.Monto)
                    .HasColumnName("monto")
                    .HasColumnType("numeric(12,2)");

                entity.Property(e => e.FechaLimite)
                    .HasColumnName("fechalimite");

                entity.Property(e => e.Descripcion)
                    .HasColumnName("descripcion");

                // 🔹 FALTABAN ESTAS DOS:
                entity.Property(e => e.Ahorrado)
                    .HasColumnName("ahorrado")
                    .HasColumnType("numeric(12,2)");

                entity.Property(e => e.Completado)
                    .HasColumnName("completado");

                entity.HasOne(e => e.Wishlist)
                    .WithMany(w => w.Detalles)
                    .HasForeignKey(e => e.IdWishlist)
                    .OnDelete(DeleteBehavior.Cascade);
            });

            // ======= schema_version =======
            modelBuilder.Entity<SchemaVersion>(entity =>
            {
                entity.ToTable("schema_version");

                entity.HasKey(e => e.Id);

                entity.Property(e => e.Id)
                    .HasColumnName("id");

                entity.Property(e => e.Version)
                    .HasColumnName("version");
            });

            // ======= usersession =======
            modelBuilder.Entity<UserSession>(entity =>
            {
                entity.ToTable("usersession");

                entity.HasKey(e => e.Id);

                entity.Property(e => e.Id)
                    .HasColumnName("id");

                entity.Property(e => e.RealUserId)
                    .HasColumnName("real_user_id");

                entity.HasOne(e => e.RealUser)
                    .WithMany()
                    .HasForeignKey(e => e.RealUserId)
                    .OnDelete(DeleteBehavior.Restrict);
            });
        }
    }
}