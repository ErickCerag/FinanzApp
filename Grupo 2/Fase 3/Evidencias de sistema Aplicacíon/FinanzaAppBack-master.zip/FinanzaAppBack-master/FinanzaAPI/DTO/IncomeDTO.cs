﻿namespace FinanzaAPI.DTO
{

    public class IncomeDto
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public string Name { get; set; } = null!;
        public decimal Amount { get; set; }
        public bool IsFixed { get; set; }
        public DateTime? Date { get; set; }
        public int? InstallmentsTotal { get; set; }
        public string? Period { get; set; }
    }

    public class IncomeCreateDto
    {
        public int UserId { get; set; }
        public string Name { get; set; } = null!;
        public decimal Amount { get; set; }
        public bool IsFixed { get; set; }
        public DateTime? Date { get; set; }
        public int? InstallmentsTotal { get; set; }
        public string? Period { get; set; }
    }

    public class IncomeUpdateDto
    {
        public int UserId { get; set; }
        public string Name { get; set; } = null!;
        public decimal Amount { get; set; }
        public bool IsFixed { get; set; }
        public DateTime? Date { get; set; }
        public int? InstallmentsTotal { get; set; }
        public string? Period { get; set; }
    }


    /* ================================
     *        EXPENSE DTOs
     * ================================ */

    public class ExpenseDto
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public string Name { get; set; } = null!;
        public decimal Amount { get; set; }
        public int Day { get; set; }
        public bool IsFixed { get; set; }
        public DateTime? Date { get; set; }
        public int? InstallmentsTotal { get; set; }
        public string? Period { get; set; }
    }

    public class ExpenseCreateDto
    {
        public int UserId { get; set; }
        public string Name { get; set; } = null!;
        public decimal Amount { get; set; }
        public int Day { get; set; }
        public bool IsFixed { get; set; }
        public DateTime? Date { get; set; }
        public int? InstallmentsTotal { get; set; }
        public string? Period { get; set; }
    }

    public class ExpenseUpdateDto
    {
        public int UserId { get; set; }
        public string Name { get; set; } = null!;
        public decimal Amount { get; set; }
        public int Day { get; set; }
        public bool IsFixed { get; set; }
        public DateTime? Date { get; set; }
        public int? InstallmentsTotal { get; set; }
        public string? Period { get; set; }
    }
}


