﻿using FinanzaAPI.Models;

namespace FinanzaAPI.DTO
{
    public class WishListDTO
    {
        public int? IdWishlist { get; set; }
        public int? IdUsuario { get; set; }
        public decimal? Total { get; set; }

        public UsuarioDto? Usuario { get; set; } = null!;
        public List<WishListDetalleDTO> Detalles { get; set; } = new List<WishListDetalleDTO>();
    }


    public class WishlistEnsureDto
    {
        public int IdUsuario { get; set; }
    }

    public class WishlistDto
    {
        public int IdWishlist { get; set; }
        public int IdUsuario { get; set; }
        public decimal Total { get; set; }
    }

    public class WishlistItemDto
    {
        public int IdWishlistDetalle { get; set; }
        public int IdWishlist { get; set; }
        public string Nombre { get; set; } = string.Empty;
        public decimal Monto { get; set; }
        public string? FechaLimite { get; set; }
        public string? Descripcion { get; set; }
        public decimal Ahorrado { get; set; }
        public int Completado { get; set; }
    }

    public class WishlistWithItemsDto
    {
        public WishlistDto? Wishlist { get; set; }
        public List<WishlistItemDto> Items { get; set; } = new();
    }

    public class WishlistItemCreateDto
    {
        public int IdWishlist { get; set; }
        public string Nombre { get; set; } = string.Empty;
        public decimal Monto { get; set; }
        public string? FechaLimite { get; set; }
        public string? Descripcion { get; set; }
    }

    public class WishlistItemUpdateDto
    {
        public string Nombre { get; set; } = string.Empty;
        public decimal Monto { get; set; }
        public string? FechaLimite { get; set; }
        public string? Descripcion { get; set; }
    }

    public class WishlistItemProgresoDto
    {
        public decimal Ahorrado { get; set; }
        public int Completado { get; set; }  // 0 o 1
    }
}


