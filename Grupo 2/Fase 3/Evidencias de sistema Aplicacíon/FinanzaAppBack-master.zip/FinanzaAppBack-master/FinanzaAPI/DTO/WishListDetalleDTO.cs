﻿using FinanzaAPI.Models;

namespace FinanzaAPI.DTO
{
    public class WishListDetalleDTO
    {

        public int? IdWishlistDetalle { get; set; }
        public int? IdWishlist { get; set; }

        public string? Nombre { get; set; }
        public decimal? Monto { get; set; }
        public DateTime? FechaLimite { get; set; }
        public string? Descripcion { get; set; }

        public WishListDetalleDTO Wishlist { get; set; } = new WishListDetalleDTO()!;
    }
}
