﻿namespace FinanzaAPI.DTO
{
    public class IncomeSyncItemDto
    {
        public int? ServerId { get; set; }        // Id en servidor (income.id)
        public int LocalId { get; set; }          // Id local en SQLite
        public int UserId { get; set; }
        public string Name { get; set; } = null!;
        public decimal Amount { get; set; }
        public bool IsFixed { get; set; }
        public DateTime? Date { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime UpdatedAt { get; set; }   // fecha local de última modificación
    }

    public class IncomeSyncPushResponseItemDto
    {
        public int LocalId { get; set; }
        public int ServerId { get; set; }
        public DateTime UpdatedAt { get; set; }
    }

    public class IncomeSyncPullItemDto
    {
        public int ServerId { get; set; }
        public int UserId { get; set; }
        public string Name { get; set; } = null!;
        public decimal Amount { get; set; }
        public bool IsFixed { get; set; }
        public DateTime? Date { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime UpdatedAt { get; set; }
    }

}
