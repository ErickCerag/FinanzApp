﻿namespace FinanzaAPI.DTO
{
    public class UsuarioDto
    {
        public int? IdUsuario { get; set; }
        public string? Nombre { get; set; } = null!;
        public string? Apellido { get; set; }
        public string? Correo { get; set; }
        public string? Contra { get; set; }
        public DateTime? FechaNacim { get; set; }
        public string? Avatar { get; set; }
    }
}
