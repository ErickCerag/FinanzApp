

// Si no viene nada, usa localhost (para desarrollo local)
export const API_URL = "https://finanzaappback.onrender.com" ;

// export const API_URL = "https://localhost:7230";