// Service/ApiClient.ts

import { API_URL } from "@/Constants";


type HttpMethod = "GET" | "POST" | "PUT" | "DELETE" | "PATCH";

async function request<T>(
  path: string,
  options: { method?: HttpMethod; body?: any; headers?: Record<string, string> } = {}
): Promise<T> {
  const url = `${API_URL}${path}`;

  try {
    console.log("[ApiClient] Fetch:", {
      url,
      method: options.method ?? "GET",
      body: options.body ?? null,
    });

    const res = await fetch(url, {
      method: options.method ?? "GET",
      headers: {
        "Content-Type": "application/json",
        ...(options.headers ?? {}),
      },
      body: options.body ? JSON.stringify(options.body) : undefined,
      // Si usas cookies/sesiones en el futuro:
      // credentials: "include",
    });

    if (!res.ok) {
      const text = await res.text().catch(() => "");
      console.error("[ApiClient] Error HTTP:", {
        url,
        status: res.status,
        statusText: res.statusText,
        body: text,
      });
      throw new Error(`Error API (${res.status})`);
    }

    if (res.status === 204) {
      // No Content
      return null as T;
    }

    const json = (await res.json()) as T;
    return json;
  } catch (err: any) {
    console.error("[ApiClient] Failed to fetch:", {
      url,
      method: options.method ?? "GET",
      errorName: err?.name,
      errorMessage: err?.message,
    });
    throw err;
  }
}

export const ApiClient = {
  get:  <T>(path: string) => request<T>(path),
  post: <T>(path: string, body?: any) =>
    request<T>(path, { method: "POST", body }),
  put:  <T>(path: string, body?: any) =>
    request<T>(path, { method: "PUT", body }),
  del:  <T>(path: string) => request<T>(path, { method: "DELETE" }),
};
