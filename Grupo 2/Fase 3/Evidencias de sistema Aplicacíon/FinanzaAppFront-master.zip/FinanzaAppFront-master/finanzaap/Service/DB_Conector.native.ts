// Service/budget/budget.service.native.ts

import { Expense, Income } from "./budget/budget.service";
import { getDb } from "./DB_Conector";
import { obtenerSesion } from "./user/user.service";


function getPeriodKeyFromDate(d: Date): string {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, "0");
  return `${year}-${month}`;
}

function getNextPeriod(period: string): string {
  const [y, m] = period.split("-").map((x) => Number(x));
  const base = new Date(y, m - 1, 1);
  const next = new Date(base.getFullYear(), base.getMonth() + 1, 1);
  return getPeriodKeyFromDate(next);
}

async function getCurrentUserId(): Promise<number> {
  const u = await obtenerSesion();
  return u?.id_usuario ?? 1;
}

async function ensureSchema() {
  const db: any = await getDb();

  await db.execAsync?.(`
    PRAGMA foreign_keys = ON;

    CREATE TABLE IF NOT EXISTS Income (
      id                 INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id            INTEGER NOT NULL,
      name               TEXT    NOT NULL,
      amount             REAL    NOT NULL DEFAULT 0,
      isFixed            INTEGER NOT NULL DEFAULT 0,
      date               TEXT    NULL,
      sync_status        TEXT    NOT NULL DEFAULT 'pending',
      updated_at         TEXT    NOT NULL DEFAULT (datetime('now')),
      is_deleted         INTEGER NOT NULL DEFAULT 0,
      period             TEXT    NULL,
      installments_total INTEGER NOT NULL DEFAULT 0,
      FOREIGN KEY (user_id) REFERENCES Usuario(id_usuario) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Expense (
      id                 INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id            INTEGER NOT NULL,
      name               TEXT    NOT NULL,
      amount             REAL    NOT NULL DEFAULT 0,
      day                INTEGER NOT NULL DEFAULT 1,
      isFixed            INTEGER NOT NULL DEFAULT 0,
      date               TEXT    NULL,
      sync_status        TEXT    NOT NULL DEFAULT 'pending',
      updated_at         TEXT    NULL DEFAULT (datetime('now')),
      is_deleted         INTEGER NOT NULL DEFAULT 0,
      period             TEXT    NULL,
      installments_total INTEGER NOT NULL DEFAULT 0,
      FOREIGN KEY (user_id) REFERENCES Usuario(id_usuario) ON DELETE CASCADE
    );
  `);

  try {
    await db.execAsync?.(`ALTER TABLE Income ADD COLUMN user_id INTEGER;`);
  } catch {}
  try {
    await db.execAsync?.(`ALTER TABLE Expense ADD COLUMN user_id INTEGER;`);
  } catch {}

  try {
    await db.execAsync?.(`ALTER TABLE Income ADD COLUMN isFixed INTEGER NOT NULL DEFAULT 0;`);
  } catch {}
  try {
    await db.execAsync?.(`ALTER TABLE Expense ADD COLUMN isFixed INTEGER NOT NULL DEFAULT 0;`);
  } catch {}

  try {
    await db.execAsync?.(`ALTER TABLE Income ADD COLUMN date TEXT NULL;`);
  } catch {}
  try {
    await db.execAsync?.(`ALTER TABLE Expense ADD COLUMN date TEXT NULL;`);
  } catch {}

  try {
    await db.execAsync?.(`ALTER TABLE Income ADD COLUMN period TEXT NULL;`);
  } catch {}
  try {
    await db.execAsync?.(`ALTER TABLE Expense ADD COLUMN period TEXT NULL;`);
  } catch {}

  try {
    await db.execAsync?.(
      `ALTER TABLE Income ADD COLUMN installments_total INTEGER NOT NULL DEFAULT 0;`
    );
  } catch {}
  try {
    await db.execAsync?.(
      `ALTER TABLE Expense ADD COLUMN installments_total INTEGER NOT NULL DEFAULT 0;`
    );
  } catch {}

  await db.execAsync?.(`UPDATE Income  SET user_id = 1 WHERE user_id IS NULL;`);
  await db.execAsync?.(`UPDATE Expense SET user_id = 1 WHERE user_id IS NULL;`);
}

async function getOrInitCurrentPeriod(db: any, userId: number): Promise<string> {
  let incomeRow =
    (await db.getFirstAsync?.(
      `SELECT period
         FROM Income
        WHERE user_id = ? AND period IS NOT NULL AND period <> ''
        ORDER BY period DESC
        LIMIT 1;`,
      [userId]
    )) ?? null;

  let expenseRow =
    (await db.getFirstAsync?.(
      `SELECT period
         FROM Expense
        WHERE user_id = ? AND period IS NOT NULL AND period <> ''
        ORDER BY period DESC
        LIMIT 1;`,
      [userId]
    )) ?? null;

  let pIncome: string | null = incomeRow?.period ?? null;
  let pExpense: string | null = expenseRow?.period ?? null;

  let basePeriod: string | null = null;
  if (pIncome && pExpense) {
    basePeriod = pIncome > pExpense ? pIncome : pExpense;
  } else {
    basePeriod = pIncome ?? pExpense ?? null;
  }

  if (!basePeriod) {
    basePeriod = getPeriodKeyFromDate(new Date());
    await db.runAsync?.(
      `UPDATE Income SET period = ? WHERE user_id = ? AND (period IS NULL OR period = '');`,
      [basePeriod, userId]
    );
    await db.runAsync?.(
      `UPDATE Expense SET period = ? WHERE user_id = ? AND (period IS NULL OR period = '');`,
      [basePeriod, userId]
    );
  }

  return basePeriod;
}

/* ================== INCOMES ================== */

export async function fetchIncomes(): Promise<Income[]> {
  await ensureSchema();
  const db: any = await getDb();
  const userId = await getCurrentUserId();
  const period = await getOrInitCurrentPeriod(db, userId);

  const rows = await db.getAllAsync?.(
    `SELECT id, user_id, name, amount, isFixed, date, period, installments_total
       FROM Income
      WHERE user_id = ? AND period = ?
      ORDER BY id DESC;`,
    [userId, period]
  );

  return (rows ?? []).map((r: any) => ({
    id: r.id,
    name: r.name,
    amount: Number(r.amount ?? 0),
    isFixed: !!r.isFixed,
    date: r.date ?? null,
    period: r.period ?? period,
    installmentsTotal: Number(r.installments_total ?? 0) || 0,
  })) as any;
}

export async function addIncome(data: {
  name: string;
  amount: number;
  isFixed?: boolean;
  date?: string;
  installmentsTotal?: number;
}): Promise<Income> {
  await ensureSchema();
  const db: any = await getDb();
  const userId = await getCurrentUserId();
  const period = await getOrInitCurrentPeriod(db, userId);

  const isFixed = data.isFixed ? 1 : 0;
  const date = data.date ?? new Date().toISOString();
  const installmentsTotal = Number(data.installmentsTotal ?? 0);

  await db.runAsync?.(
    `INSERT INTO Income (user_id, name, amount, isFixed, date, period, installments_total)
     VALUES (?, ?, ?, ?, ?, ?, ?);`,
    [userId, data.name, Number(data.amount) || 0, isFixed, date, period, installmentsTotal]
  );

  const row = await db.getFirstAsync?.(
    `SELECT id, user_id, name, amount, isFixed, date, period, installments_total
       FROM Income
      WHERE user_id = ? AND period = ?
      ORDER BY id DESC
      LIMIT 1;`,
    [userId, period]
  );

  return {
    id: row.id,
    name: row.name,
    amount: Number(row.amount ?? 0),
    isFixed: !!row.isFixed,
    date: row.date ?? null,
    period: row.period ?? period,
    installmentsTotal: Number(row.installments_total ?? 0) || 0,
  } as any;
}

export async function updateIncome(data: {
  id: number;
  name: string;
  amount: number;
  isFixed?: boolean;
  installmentsTotal?: number;
}): Promise<Income> {
  await ensureSchema();
  const db: any = await getDb();
  const userId = await getCurrentUserId();

  const isFixed = data.isFixed ? 1 : 0;
  const installmentsTotal = Number(data.installmentsTotal ?? 0);

  await db.runAsync?.(
    `UPDATE Income
        SET name = ?, amount = ?, isFixed = ?, installments_total = ?
      WHERE id = ? AND user_id = ?;`,
    [data.name, Number(data.amount) || 0, isFixed, installmentsTotal, data.id, userId]
  );

  const row = await db.getFirstAsync?.(
    `SELECT id, user_id, name, amount, isFixed, date, period, installments_total
       FROM Income
      WHERE id = ? AND user_id = ?;`,
    [data.id, userId]
  );

  return {
    id: row.id,
    name: row.name,
    amount: Number(row.amount ?? 0),
    isFixed: !!row.isFixed,
    date: row.date ?? null,
    period: row.period ?? null,
    installmentsTotal: Number(row.installments_total ?? 0) || 0,
  } as any;
}

export async function deleteIncome(id: number): Promise<void> {
  await ensureSchema();
  const db: any = await getDb();
  const userId = await getCurrentUserId();

  await db.runAsync?.(
    `DELETE FROM Income WHERE id = ? AND user_id = ?;`,
    [id, userId]
  );
}

/* ================== EXPENSES ================== */

export async function fetchExpenses(): Promise<Expense[]> {
  await ensureSchema();
  const db: any = await getDb();
  const userId = await getCurrentUserId();
  const period = await getOrInitCurrentPeriod(db, userId);

  const rows = await db.getAllAsync?.(
    `SELECT id, user_id, name, amount, day, isFixed, date, period, installments_total
       FROM Expense
      WHERE user_id = ? AND period = ?
      ORDER BY id DESC;`,
    [userId, period]
  );

  return (rows ?? []).map((r: any) => ({
    id: r.id,
    name: r.name,
    amount: Number(r.amount ?? 0),
    day: Number(r.day ?? 1),
    isFixed: !!r.isFixed,
    date: r.date ?? null,
    period: r.period ?? period,
    installmentsTotal: Number(r.installments_total ?? 0) || 0,
  })) as any;
}

export async function addExpense(data: {
  name: string;
  amount: number;
  day: number;
  isFixed?: boolean;
  date?: string;
  installmentsTotal?: number;
}): Promise<Expense> {
  await ensureSchema();
  const db: any = await getDb();
  const userId = await getCurrentUserId();
  const period = await getOrInitCurrentPeriod(db, userId);

  const isFixed = data.isFixed ? 1 : 0;
  const date = data.date ?? new Date().toISOString();
  const day = Number(data.day || 1);
  const installmentsTotal = Number(data.installmentsTotal ?? 0);

  await db.runAsync?.(
    `INSERT INTO Expense (user_id, name, amount, day, isFixed, date, period, installments_total)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?);`,
    [userId, data.name, Number(data.amount) || 0, day, isFixed, date, period, installmentsTotal]
  );

  const row = await db.getFirstAsync?.(
    `SELECT id, user_id, name, amount, day, isFixed, date, period, installments_total
       FROM Expense
      WHERE user_id = ? AND period = ?
      ORDER BY id DESC
      LIMIT 1;`,
    [userId, period]
  );

  return {
    id: row.id,
    name: row.name,
    amount: Number(row.amount ?? 0),
    day: Number(row.day ?? 1),
    isFixed: !!row.isFixed,
    date: row.date ?? null,
    period: row.period ?? period,
    installmentsTotal: Number(row.installments_total ?? 0) || 0,
  } as any;
}

export async function updateExpense(data: {
  id: number;
  name: string;
  amount: number;
  day: number;
  isFixed?: boolean;
  installmentsTotal?: number;
}): Promise<Expense> {
  await ensureSchema();
  const db: any = await getDb();
  const userId = await getCurrentUserId();

  const isFixed = data.isFixed ? 1 : 0;
  const day = Number(data.day || 1);
  const installmentsTotal = Number(data.installmentsTotal ?? 0);

  await db.runAsync?.(
    `UPDATE Expense
        SET name = ?, amount = ?, day = ?, isFixed = ?, installments_total = ?
      WHERE id = ? AND user_id = ?;`,
    [data.name, Number(data.amount) || 0, day, isFixed, installmentsTotal, data.id, userId]
  );

  const row = await db.getFirstAsync?.(
    `SELECT id, user_id, name, amount, day, isFixed, date, period, installments_total
       FROM Expense
      WHERE id = ? AND user_id = ?;`,
    [data.id, userId]
  );

  return {
    id: row.id,
    name: row.name,
    amount: Number(row.amount ?? 0),
    day: Number(row.day ?? 1),
    isFixed: !!row.isFixed,
    date: row.date ?? null,
    period: row.period ?? null,
    installmentsTotal: Number(row.installments_total ?? 0) || 0,
  } as any;
}

export async function deleteExpense(id: number): Promise<void> {
  await ensureSchema();
  const db: any = await getDb();
  const userId = await getCurrentUserId();

  await db.runAsync?.(
    `DELETE FROM Expense WHERE id = ? AND user_id = ?;`,
    [id, userId]
  );
}

/* ================== CONTINUAR PRESUPUESTO AL SIGUIENTE MES (NATIVE) ================== */

export async function continueBudgetNextMonth(): Promise<{
  incomes: Income[];
  expenses: Expense[];
}> {
  await ensureSchema();
  const db: any = await getDb();
  const userId = await getCurrentUserId();

  const currentPeriod = await getOrInitCurrentPeriod(db, userId);
  const nextPeriod = getNextPeriod(currentPeriod);
  const nowIso = new Date().toISOString();

  const incomeRows = await db.getAllAsync?.(
    `SELECT id, user_id, name, amount, isFixed, date, period, installments_total
       FROM Income
      WHERE user_id = ? AND period = ?
      ORDER BY id ASC;`,
    [userId, currentPeriod]
  );

  // Ingresos fijos → copiar al siguiente periodo
  for (const r of incomeRows ?? []) {
    if (!r.isFixed) continue;

    await db.runAsync?.(
      `INSERT INTO Income (user_id, name, amount, isFixed, date, period, installments_total)
       VALUES (?, ?, ?, ?, ?, ?, ?);`,
      [
        userId,
        r.name,
        Number(r.amount ?? 0),
        r.isFixed ? 1 : 0,
        nowIso,
        nextPeriod,
        Number(r.installments_total ?? 0) || 0,
      ]
    );
  }

  const expenseRows = await db.getAllAsync?.(
    `SELECT id, user_id, name, amount, day, isFixed, date, period, installments_total
       FROM Expense
      WHERE user_id = ? AND period = ?
      ORDER BY id ASC;`,
    [userId, currentPeriod]
  );

  for (const r of expenseRows ?? []) {
    const isFixed = !!r.isFixed;
    const total = Number(r.installments_total ?? 0); // cuotas restantes en mes actual

    if (total > 0) {
      // 🔥 restamos una cuota
      const newRemaining = total - 1;
      if (newRemaining > 0) {
        await db.runAsync?.(
          `INSERT INTO Expense
             (user_id, name, amount, day, isFixed, date, period, installments_total)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?);`,
          [
            userId,
            r.name,
            Number(r.amount ?? 0),
            Number(r.day ?? 1),
            isFixed ? 1 : 0,
            nowIso,
            nextPeriod,
            newRemaining,
          ]
        );
      }
      // Si llega a 0, no se copia
    } else if (isFixed) {
      await db.runAsync?.(
        `INSERT INTO Expense
           (user_id, name, amount, day, isFixed, date, period, installments_total)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?);`,
        [
          userId,
          r.name,
          Number(r.amount ?? 0),
          Number(r.day ?? 1),
          1,
          nowIso,
          nextPeriod,
          0,
        ]
      );
    }
  }

  // Ahora el "periodo actual" lógico pasa a ser nextPeriod
  // y volvemos solo ese presupuesto
  const incomesNextRows = await db.getAllAsync?.(
    `SELECT id, user_id, name, amount, isFixed, date, period, installments_total
       FROM Income
      WHERE user_id = ? AND period = ?
      ORDER BY id DESC;`,
    [userId, nextPeriod]
  );

  const expensesNextRows = await db.getAllAsync?.(
    `SELECT id, user_id, name, amount, day, isFixed, date, period, installments_total
       FROM Expense
      WHERE user_id = ? AND period = ?
      ORDER BY id DESC;`,
    [userId, nextPeriod]
  );

  const incomes: Income[] = (incomesNextRows ?? []).map((r: any) => ({
    id: r.id,
    name: r.name,
    amount: Number(r.amount ?? 0),
    isFixed: !!r.isFixed,
    date: r.date ?? null,
    period: r.period ?? nextPeriod,
    installmentsTotal: Number(r.installments_total ?? 0) || 0,
  })) as any;

  const expenses: Expense[] = (expensesNextRows ?? []).map((r: any) => ({
    id: r.id,
    name: r.name,
    amount: Number(r.amount ?? 0),
    day: Number(r.day ?? 1),
    isFixed: !!r.isFixed,
    date: r.date ?? null,
    period: r.period ?? nextPeriod,
    installmentsTotal: Number(r.installments_total ?? 0) || 0,
  })) as any;

  return { incomes, expenses };
}
