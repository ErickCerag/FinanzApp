// Service/wishList/wishlist.service.web.ts
import { ApiClient } from "../ApiClient";
import type { WishlistItemRow, WishlistRow } from "./wishlist.service";

/**
 * Crear wishlist para un usuario si no existe.
 * POST /api/Wishlist/Ensure
 */
export async function crearWishlistSiNoExiste(idUsuario: number): Promise<number> {
  const payload = { idUsuario };

  const res = await ApiClient.post<{ idWishlist: number }>(
    "/api/Wishlist/Ensure",
    payload
  );

  if (!res || !res.idWishlist) {
    throw new Error("No se pudo obtener idWishlist desde el backend");
  }

  return res.idWishlist;
}

/**
 * Agregar un deseo a una wishlist.
 * POST /api/Wishlist/Item
 */
export async function agregarDeseo(
  idWishlist: number,
  nombre: string,
  monto: number,
  fechaLimite?: string | null,
  descripcion?: string | null
): Promise<number> {
  const payload = {
    idWishlist,
    nombre,
    monto: Number(monto) || 0,
    fechaLimite: fechaLimite ?? null,
    descripcion: descripcion ?? null,
  };

  const res = await ApiClient.post<{ idWishlistDetalle: number }>(
    "/api/Wishlist/Item",
    payload
  );

  if (!res || !res.idWishlistDetalle) {
    // En native devolvías Date.now() como "marcador"
    return Date.now();
  }

  return res.idWishlistDetalle;
}

/**
 * Obtener wishlist + items por usuario.
 * GET /api/Wishlist/WithItems/{idUsuario}
 */
export async function obtenerWishlistConItems(
  idUsuario: number
): Promise<{ wishlist: WishlistRow | null; items: WishlistItemRow[] }> {
  const res = await ApiClient.get<{
    wishlist: any | null;
    items: any[];
  }>(`/api/Wishlist/WithItems/${idUsuario}`);

  if (!res || !res.wishlist) {
    return { wishlist: null, items: [] };
  }

  const wl: WishlistRow = {
    id_wishlist:
      res.wishlist.id_wishlist ??
      res.wishlist.idWishlist ??
      res.wishlist.IdWishlist,
    Total: res.wishlist.Total ?? res.wishlist.total ?? 0,
  };

  const items: WishlistItemRow[] = (res.items || []).map((x: any) => ({
    id_wishlistDetalle:
      x.id_wishlistDetalle ??
      x.idWishlistDetalle ??
      x.IdWishlistDetalle,
    id_wishlist:
      x.id_wishlist ??
      x.idWishlist ??
      x.IdWishlist ??
      wl.id_wishlist,
    Nombre: x.Nombre ?? x.nombre ?? "",
    Monto: x.Monto ?? x.monto ?? 0,
    FechaLimite: x.FechaLimite ?? x.fechaLimite ?? null,
    Descripcion: x.Descripcion ?? x.descripcion ?? null,
    Ahorrado: x.Ahorrado ?? x.ahorrado ?? 0,
    Completado: x.Completado ?? x.completado ?? 0,
  }));

  return { wishlist: wl, items };
}

/**
 * Actualizar datos base del deseo (nombre, monto, fecha, descripción)
 * PUT /api/Wishlist/Item/{idWishlistDetalle}
 */
export async function actualizarDeseo(
  idWishlistDetalle: number,
  nombre: string,
  monto: number,
  fechaLimite?: string | null,
  descripcion?: string | null
): Promise<void> {
  const payload = {
    nombre,
    monto: Number(monto) || 0,
    fechaLimite: fechaLimite ?? null,
    descripcion: descripcion ?? null,
  };

  await ApiClient.put(`/api/Wishlist/Item/${idWishlistDetalle}`, payload);
}

/**
 * Actualizar solo progreso (ahorrado + completado)
 * PUT /api/Wishlist/Item/{idWishlistDetalle}/Progreso
 */
export async function actualizarProgresoDeseo(
  idWishlistDetalle: number,
  ahorrado: number,
  completado: number
): Promise<void> {
  const payload = {
    ahorrado: Number(ahorrado) || 0,
    completado: completado ? 1 : 0,
  };

  await ApiClient.put(
    `/api/Wishlist/Item/${idWishlistDetalle}/Progreso`,
    payload
  );
}

/**
 * Eliminar deseo
 * DELETE /api/Wishlist/Item/{idWishlistDetalle}
 */
export async function eliminarDeseo(idWishlistDetalle: number): Promise<void> {
  await ApiClient.del(`/api/Wishlist/Item/${idWishlistDetalle}`);
}
