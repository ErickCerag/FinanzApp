import { ApiClient } from "./ApiClient";
import { getDb } from "./DB_Conector";
import { obtenerSesion } from "./user/user.service";


// Tabla local para guardar el último sync
async function ensureSyncTable() {
  const db: any = await getDb();
  await db.execAsync?.(`
    CREATE TABLE IF NOT EXISTS SyncState (
      key   TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );
  `);
}

async function getLastSync(key: string): Promise<string | null> {
  await ensureSyncTable();
  const db: any = await getDb();
  const row = await db.getFirstAsync?.(
    `SELECT value FROM SyncState WHERE key = ? LIMIT 1`, [key]
  );
  return row?.value ?? null;
}

async function setLastSync(key: string, value: string) {
  await ensureSyncTable();
  const db: any = await getDb();
  await db.runAsync?.(
    `INSERT INTO SyncState (key, value)
     VALUES (?, ?)
     ON CONFLICT(key) DO UPDATE SET value = excluded.value;`,
    [key, value]
  );
}

// ===================== SYNC INCOMES ===================== //

export async function syncIncomes() {
  const session = await obtenerSesion();
  const userId = session?.id_usuario;
  if (!userId) return;

  const db: any = await getDb();

  // 1) PUSH cambios locales pendientes
  const localRows = await db.getAllAsync?.(
    `SELECT id, user_id, name, amount, isFixed, date,
            sync_status, updated_at, is_deleted, server_id
       FROM Income
      WHERE user_id = ? AND sync_status != 'synced';`,
    [userId]
  );

  const payload = (localRows ?? []).map((r: any) => ({
    serverId: r.server_id ?? null,
    localId: r.id,
    userId,
    name: r.name,
    amount: Number(r.amount ?? 0),
    isFixed: !!r.isFixed,
    date: r.date ? new Date(r.date).toISOString() : null,
    isDeleted: !!r.is_deleted,
    updatedAt: r.updated_at ? new Date(r.updated_at).toISOString() : new Date().toISOString()
  }));

  if (payload.length > 0) {
    const resp = await ApiClient.post<any[]>(
      "/api/Sync/incomes/push",
      payload
    );

    // Actualizar mapping local <-> server
    for (const item of resp) {
      await db.runAsync?.(
        `UPDATE Income
            SET sync_status = 'synced',
                server_id = ?,
                updated_at = ?
          WHERE id = ?;`,
        [item.serverId, item.updatedAt, item.localId]
      );
    }
  }

  // 2) PULL cambios desde servidor
  const last = await getLastSync("incomes_last_sync");
  const since = last ?? "2000-01-01T00:00:00Z";

  const serverChanges = await ApiClient.get<any[]>(
    `/api/Sync/incomes/pull?userId=${userId}&since=${encodeURIComponent(
      since
    )}`
  );

  for (const s of serverChanges ?? []) {
    const serverId = s.serverId ?? s.ServerId;
    const updatedAt = s.updatedAt ?? s.UpdatedAt;
    const isDeleted = s.isDeleted ?? s.IsDeleted;

    // ¿Existe ya localmente?
    const row = await db.getFirstAsync?.(
      `SELECT id, server_id, updated_at
         FROM Income
        WHERE server_id = ? AND user_id = ?
        LIMIT 1;`,
      [serverId, userId]
    );

    if (!row) {
      if (isDeleted) continue; // nada que insertar
      // Insertamos nuevo
      await db.runAsync?.(
        `INSERT INTO Income (user_id, name, amount, isFixed, date,
                             sync_status, updated_at, is_deleted, server_id)
         VALUES (?, ?, ?, ?, ?, 'synced', ?, ?, ?);`,
        [
          userId,
          s.name ?? s.Name,
          Number(s.amount ?? s.Amount ?? 0),
          s.isFixed ?? s.IsFixed ? 1 : 0,
          s.date ?? s.Date ?? null,
          updatedAt,
          isDeleted ? 1 : 0,
          serverId,
        ]
      );
    } else {
      // Local existente: si el servidor es más nuevo, pisamos
      const localUpdated = new Date(row.updated_at);
      const remoteUpdated = new Date(updatedAt);
      if (remoteUpdated > localUpdated) {
        if (isDeleted) {
          // Marcamos como borrado o incluso lo eliminamos físico
          await db.runAsync?.(
            `UPDATE Income
                SET is_deleted = 1,
                    sync_status = 'synced',
                    updated_at = ?
              WHERE server_id = ? AND user_id = ?;`,
            [updatedAt, serverId, userId]
          );
        } else {
          await db.runAsync?.(
            `UPDATE Income
                SET name = ?, amount = ?, isFixed = ?, date = ?,
                    sync_status = 'synced',
                    updated_at = ?, is_deleted = ?
              WHERE server_id = ? AND user_id = ?;`,
            [
              s.name ?? s.Name,
              Number(s.amount ?? s.Amount ?? 0),
              s.isFixed ?? s.IsFixed ? 1 : 0,
              s.date ?? s.Date ?? null,
              updatedAt,
              isDeleted ? 1 : 0,
              serverId,
              userId,
            ]
          );
        }
      }
    }
  }

  // 3) Actualizar marca de último sync
  await setLastSync("incomes_last_sync", new Date().toISOString());
}
