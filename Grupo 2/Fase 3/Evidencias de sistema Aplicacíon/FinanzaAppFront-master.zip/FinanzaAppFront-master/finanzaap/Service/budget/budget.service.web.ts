// Service/budget/budget.service.web.ts
import { ApiClient } from "../ApiClient";
import { obtenerSesion } from "../user/user.service";
import type { Expense, Income } from "./budget.service";

async function getCurrentUserId(): Promise<number> {
  const u = await obtenerSesion();
  return u?.id_usuario ?? 1;
}

function getPeriodKeyFromDate(d: Date): string {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, "0");
  return `${year}-${month}`;
}

function getNextPeriod(period: string): string {
  const [y, m] = period.split("-").map((x) => Number(x));
  const base = new Date(y, m - 1, 1);
  const next = new Date(base.getFullYear(), base.getMonth() + 1, 1);
  return getPeriodKeyFromDate(next);
}

/** Devuelve el período más reciente presente en una lista (o null) */
function getLatestPeriodInList(items: { period?: string | null }[]): string | null {
  const periods = items
    .map((x) => x.period ?? null)
    .filter((p): p is string => !!p);
  if (periods.length === 0) return null;
  return periods.sort().at(-1) ?? null;
}

/* ================== INCOMES ================== */

export async function fetchIncomes(): Promise<Income[]> {
  const userId = await getCurrentUserId();

  const rows = await ApiClient.get<any[]>(
    `/api/Presupuesto/incomes?userId=${userId}`
  );

  const mapped: Income[] = (rows ?? []).map((r) => ({
    id: r.id ?? r.Id,
    name: r.name ?? r.Name,
    amount: Number(r.amount ?? r.Amount ?? 0),
    isFixed: !!(r.isFixed ?? r.IsFixed ?? r.isfixed),
    date: r.date ?? r.Date ?? null,
    period: r.period ?? r.Period ?? null,
    installmentsTotal:
      Number(r.installmentsTotal ?? r.InstallmentsTotal ?? 0) || 0,
  })) as any;

  // Filtrar solo al período más reciente
  const latest = getLatestPeriodInList(mapped);
  if (!latest) return mapped;
  return mapped.filter((i) => i.period === latest);
}

export async function addIncome(data: {
  name: string;
  amount: number;
  isFixed?: boolean;
  date?: string;
  installmentsTotal?: number;
}): Promise<Income> {
  const userId = await getCurrentUserId();

  const period = getPeriodKeyFromDate(new Date());

  const payload = {
    userId,
    name: data.name,
    amount: Number(data.amount) || 0,
    isFixed: !!data.isFixed,
    date: data.date ?? new Date().toISOString(),
    period,
    installmentsTotal: Number(data.installmentsTotal ?? 0),
  };

  const r = await ApiClient.post<any>("/api/Presupuesto/incomes", payload);

  return {
    id: r.id ?? r.Id,
    name: r.name ?? r.Name,
    amount: Number(r.amount ?? r.Amount ?? 0),
    isFixed: !!(r.isFixed ?? r.IsFixed ?? r.isfixed),
    date: r.date ?? r.Date ?? null,
    period: r.period ?? r.Period ?? period,
    installmentsTotal:
      Number(r.installmentsTotal ?? r.InstallmentsTotal ?? 0) || 0,
  } as any;
}

export async function updateIncome(data: {
  id: number;
  name: string;
  amount: number;
  isFixed?: boolean;
  date?: string;
  installmentsTotal?: number;
}): Promise<Income> {
  const userId = await getCurrentUserId();

  const payload = {
    userId,
    name: data.name,
    amount: Number(data.amount) || 0,
    isFixed: !!data.isFixed,
    date: data.date ?? null,
    installmentsTotal: Number(data.installmentsTotal ?? 0),
  };

  const r = await ApiClient.put<any>(
    `/api/Presupuesto/incomes/${data.id}`,
    payload
  );

  return {
    id: r.id ?? r.Id,
    name: r.name ?? r.Name,
    amount: Number(r.amount ?? r.Amount ?? 0),
    isFixed: !!(r.isFixed ?? r.IsFixed ?? r.isfixed),
    date: r.date ?? r.Date ?? null,
    period: r.period ?? r.Period ?? null,
    installmentsTotal:
      Number(r.installmentsTotal ?? r.InstallmentsTotal ?? 0) || 0,
  } as any;
}

export async function deleteIncome(id: number): Promise<void> {
  const userId = await getCurrentUserId();
  await ApiClient.del(`/api/Presupuesto/incomes/${id}?userId=${userId}`);
}

/* ================== EXPENSES ================== */

export async function fetchExpenses(): Promise<Expense[]> {
  const userId = await getCurrentUserId();

  const rows = await ApiClient.get<any[]>(
    `/api/Presupuesto/expenses?userId=${userId}`
  );

  const mapped: Expense[] = (rows ?? []).map((r) => ({
    id: r.id ?? r.Id,
    name: r.name ?? r.Name,
    amount: Number(r.amount ?? r.Amount ?? 0),
    day: Number(r.day ?? r.Day ?? 1),
    isFixed: !!(r.isFixed ?? r.IsFixed ?? r.isfixed),
    date: r.date ?? r.Date ?? null,
    period: r.period ?? r.Period ?? null,
    installmentsTotal:
      Number(r.installmentsTotal ?? r.InstallmentsTotal ?? 0) || 0,
  })) as any;

  const latest = getLatestPeriodInList(mapped);
  if (!latest) return mapped;
  return mapped.filter((e) => e.period === latest);
}

export async function addExpense(data: {
  name: string;
  amount: number;
  day: number;
  isFixed?: boolean;
  date?: string;
  installmentsTotal?: number;
}): Promise<Expense> {
  const userId = await getCurrentUserId();

  const period = getPeriodKeyFromDate(new Date());

  const payload = {
    userId,
    name: data.name,
    amount: Number(data.amount) || 0,
    day: Number(data.day || 1),
    isFixed: !!data.isFixed,
    date: data.date ?? new Date().toISOString(),
    period,
    installmentsTotal: Number(data.installmentsTotal ?? 0),
  };

  const r = await ApiClient.post<any>("/api/Presupuesto/expenses", payload);

  return {
    id: r.id ?? r.Id,
    name: r.name ?? r.Name,
    amount: Number(r.amount ?? r.Amount ?? 0),
    day: Number(r.day ?? r.Day ?? 1),
    isFixed: !!(r.isFixed ?? r.IsFixed ?? r.isfixed),
    date: r.date ?? r.Date ?? null,
    period: r.period ?? r.Period ?? period,
    installmentsTotal:
      Number(r.installmentsTotal ?? r.InstallmentsTotal ?? 0) || 0,
  } as any;
}

export async function updateExpense(data: {
  id: number;
  name: string;
  amount: number;
  day: number;
  isFixed?: boolean;
  date?: string;
  installmentsTotal?: number;
}): Promise<Expense> {
  const userId = await getCurrentUserId();

  const payload = {
    userId,
    name: data.name,
    amount: Number(data.amount) || 0,
    day: Number(data.day || 1),
    isFixed: !!data.isFixed,
    date: data.date ?? null,
    installmentsTotal: Number(data.installmentsTotal ?? 0),
  };

  const r = await ApiClient.put<any>(
    `/api/Presupuesto/expenses/${data.id}`,
    payload
  );

  return {
    id: r.id ?? r.Id,
    name: r.name ?? r.Name,
    amount: Number(r.amount ?? r.Amount ?? 0),
    day: Number(r.day ?? r.Day ?? 1),
    isFixed: !!(r.isFixed ?? r.IsFixed ?? r.isfixed),
    date: r.date ?? r.Date ?? null,
    period: r.period ?? r.Period ?? null,
    installmentsTotal:
      Number(r.installmentsTotal ?? r.InstallmentsTotal ?? 0) || 0,
  } as any;
}

export async function deleteExpense(id: number): Promise<void> {
  const userId = await getCurrentUserId();
  await ApiClient.del(`/api/Presupuesto/expenses/${id}?userId=${userId}`);
}

/* ================== CONTINUAR PRESUPUESTO AL SIGUIENTE MES ================== */

export async function continueBudgetNextMonth(): Promise<{
  incomes: Income[];
  expenses: Expense[];
}> {
  const userId = await getCurrentUserId();

  // Usamos solo el período actual (fetchIncomes/Expenses ya lo filtran)
  const incomes = await fetchIncomes();
  const expenses = await fetchExpenses();

  const existingIncomeWithPeriod = incomes.find((i) => !!i.period);
  const existingExpenseWithPeriod = expenses.find((e) => !!e.period);

  const basePeriod =
    existingIncomeWithPeriod?.period ??
    existingExpenseWithPeriod?.period ??
    getPeriodKeyFromDate(new Date());

  const nextPeriod = getNextPeriod(basePeriod);
  const nowIso = new Date().toISOString();

  // Ingresos fijos → copiar tal cual
  const incomePosts = incomes
    .filter((i) => !!i.isFixed)
    .map((i) =>
      ApiClient.post<any>("/api/Presupuesto/incomes", {
        userId,
        name: i.name,
        amount: Number(i.amount) || 0,
        isFixed: !!i.isFixed,
        date: nowIso,
        period: nextPeriod,
        installmentsTotal: Number(i.installmentsTotal ?? 0),
      })
    );

  // Gastos: cuotas → restar 1; si queda 0, no se crea. Fijo sin cuotas → copiar.
  const expensePosts: Promise<any>[] = [];

  for (const g of expenses) {
    const total = Number(g.installmentsTotal ?? 0);
    const isFixed = !!g.isFixed;

    if (total > 0) {
      const newRemaining = total - 1;
      if (newRemaining > 0) {
        expensePosts.push(
          ApiClient.post<any>("/api/Presupuesto/expenses", {
            userId,
            name: g.name,
            amount: Number(g.amount) || 0,
            day: Number(g.day || 1),
            isFixed,
            date: nowIso,
            period: nextPeriod,
            installmentsTotal: newRemaining,
          })
        );
      }
    } else if (isFixed) {
      expensePosts.push(
        ApiClient.post<any>("/api/Presupuesto/expenses", {
          userId,
          name: g.name,
          amount: Number(g.amount) || 0,
          day: Number(g.day || 1),
          isFixed: true,
          date: nowIso,
          period: nextPeriod,
          installmentsTotal: 0,
        })
      );
    }
  }

  const createdIncomesRaw = await Promise.all(incomePosts);
  const createdExpensesRaw = await Promise.all(expensePosts);

  const nextIncomes: Income[] = createdIncomesRaw.map((r) => ({
    id: r.id ?? r.Id,
    name: r.name ?? r.Name,
    amount: Number(r.amount ?? r.Amount ?? 0),
    isFixed: !!(r.isFixed ?? r.IsFixed ?? r.isfixed),
    date: r.date ?? r.Date ?? nowIso,
    period: r.period ?? r.Period ?? nextPeriod,
    installmentsTotal:
      Number(r.installmentsTotal ?? r.InstallmentsTotal ?? 0) || 0,
  })) as any;

  const nextExpenses: Expense[] = createdExpensesRaw.map((r) => ({
    id: r.id ?? r.Id,
    name: r.name ?? r.Name,
    amount: Number(r.amount ?? r.Amount ?? 0),
    day: Number(r.day ?? r.Day ?? 1),
    isFixed: !!(r.isFixed ?? r.IsFixed ?? r.isfixed),
    date: r.date ?? r.Date ?? nowIso,
    period: r.period ?? r.Period ?? nextPeriod,
    installmentsTotal:
      Number(r.installmentsTotal ?? r.InstallmentsTotal ?? 0) || 0,
  })) as any;

  return {
    incomes: nextIncomes,
    expenses: nextExpenses,
  };
}

/* ================== REVERTIR PRESUPUESTO AL MES ANTERIOR (WEB) ================== */

export async function revertBudgetToPreviousMonth(): Promise<{
  incomes: Income[];
  expenses: Expense[];
}> {
  const userId = await getCurrentUserId();
  if (!userId) return { incomes: [], expenses: [] };

  // 1) Obtener el último período (fetchIncomes/Expenses ya lo filtran)
  const currentIncomes = await fetchIncomes();
  const currentExpenses = await fetchExpenses();

  if (currentIncomes.length === 0 && currentExpenses.length === 0) {
    return { incomes: [], expenses: [] };
  }

  // 2) Borrar TODOS los registros de ese período (los que tenemos en memoria)
  const incomeDeletes = currentIncomes.map((i) =>
    ApiClient.del(`/api/Presupuesto/incomes/${i.id}?userId=${userId}`)
  );
  const expenseDeletes = currentExpenses.map((e) =>
    ApiClient.del(`/api/Presupuesto/expenses/${e.id}?userId=${userId}`)
  );

  await Promise.all([...incomeDeletes, ...expenseDeletes]);

  // 3) Volver a cargar → ahora el backend devolverá el período anterior
  const prevIncomes = await fetchIncomes();
  const prevExpenses = await fetchExpenses();

  return {
    incomes: prevIncomes,
    expenses: prevExpenses,
  };
}
