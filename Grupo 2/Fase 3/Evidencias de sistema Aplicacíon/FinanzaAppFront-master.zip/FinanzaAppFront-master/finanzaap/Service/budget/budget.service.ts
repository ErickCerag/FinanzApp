// Service/budget/budget.service.ts
// Solo tipos + stubs, las implementaciones reales están en .native / .web

export type Income = {
  id: number;
  name: string;
  amount: number;
  isFixed?: boolean;
  date?: string | null;
  period?: string | null;
  installmentsTotal?: number; // cuotas restantes
};

export type Expense = {
  id: number;
  name: string;
  amount: number;
  day: number;
  isFixed?: boolean;
  date?: string | null;
  period?: string | null;
  installmentsTotal?: number; // cuotas restantes
};

// ====== Incomes ======

export async function fetchIncomes(): Promise<Income[]> {
  throw new Error("[Budget] Sin implementación de plataforma (native/web).");
}

export async function addIncome(_data: {
  name: string;
  amount: number;
  isFixed?: boolean;
  date?: string;
  installmentsTotal?: number;
}): Promise<Income> {
  throw new Error("[Budget] Sin implementación de plataforma (native/web).");
}

export async function updateIncome(_data: {
  id: number;
  name: string;
  amount: number;
  isFixed?: boolean;
  date?: string;
  installmentsTotal?: number;
}): Promise<Income> {
  throw new Error("[Budget] Sin implementación de plataforma (native/web).");
}

export async function deleteIncome(_id: number): Promise<void> {
  throw new Error("[Budget] Sin implementación de plataforma (native/web).");
}

// ====== Expenses ======

export async function fetchExpenses(): Promise<Expense[]> {
  throw new Error("[Budget] Sin implementación de plataforma (native/web).");
}

export async function addExpense(_data: {
  name: string;
  amount: number;
  day: number;
  isFixed?: boolean;
  date?: string;
  installmentsTotal?: number;
}): Promise<Expense> {
  throw new Error("[Budget] Sin implementación de plataforma (native/web).");
}

export async function updateExpense(_data: {
  id: number;
  name: string;
  amount: number;
  day: number;
  isFixed?: boolean;
  date?: string;
  installmentsTotal?: number;
}): Promise<Expense> {
  throw new Error("[Budget] Sin implementación de plataforma (native/web).");
}

export async function deleteExpense(_id: number): Promise<void> {
  throw new Error("[Budget] Sin implementación de plataforma (native/web).");
}

// ====== Continuar presupuesto al siguiente mes ======

export async function continueBudgetNextMonth(): Promise<{
  incomes: Income[];
  expenses: Expense[];
}> {
  throw new Error("[Budget] Sin implementación de plataforma (native/web).");
}

// ====== Revertir presupuesto al mes anterior ======

export async function revertBudgetToPreviousMonth(): Promise<{
  incomes: Income[];
  expenses: Expense[];
}> {
  throw new Error("[Budget] Sin implementación de plataforma (native/web).");
}
