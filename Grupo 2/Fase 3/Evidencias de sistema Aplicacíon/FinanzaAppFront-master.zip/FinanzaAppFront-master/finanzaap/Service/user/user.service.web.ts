// Service/user/user.service.web.ts
import { ApiClient } from "../ApiClient";
import type { RegistroPayload, Usuario } from "./user.service";

const SESSION_KEY = "session_user_id_v1";

/* ============================================
   Helpers de sesión (localStorage)
============================================ */

function readSessionId(): number | null {
  try {
    if (typeof localStorage === "undefined") return null;
    const v = localStorage.getItem(SESSION_KEY);
    return v ? Number(v) : null;
  } catch {
    return null;
  }
}

function writeSessionId(id: number | null) {
  try {
    if (typeof localStorage === "undefined") return;
    if (id == null) localStorage.removeItem(SESSION_KEY);
    else localStorage.setItem(SESSION_KEY, String(id));
  } catch {
    // ignore
  }
}

const norm = (s?: string | null) => (s ?? "").normalize("NFKC").trim();

/** Forzar logout y redirección al login */
function forceLogoutAndRedirect() {
  writeSessionId(null);

  if (typeof window !== "undefined") {
    console.log("[UsuarioService.web] Sesión inválida, redirigiendo a /login");
    try {
      window.location.href = "/login";
    } catch (e) {
      console.error("[UsuarioService.web] Error al redirigir a /login:", e);
    }
  }
}

/** Mapea el DTO de la API (UsuarioDto) a la interfaz Usuario del front */
function mapDtoToUsuario(dto: any): Usuario {
  return {
    id_usuario: dto.idUsuario ?? dto.IdUsuario ?? dto.id_usuario ?? 0,
    Nombre: dto.nombre ?? dto.Nombre ?? "",
    Apellido: dto.apellido ?? dto.Apellido ?? null,
    Correo: dto.correo ?? dto.Correo ?? "",
    FechaNacim:
      dto.fechaNacim ??
      dto.FechaNacim ??
      null,
    Avatar: dto.avatar ?? dto.Avatar ?? null,
    // 👇 Nunca tomamos la contraseña desde el backend
    Contra: null,
  };
}

/* ============================================
   Debug en window
============================================ */

if (typeof window !== "undefined") {
  console.log(
    "%c[UsuarioService] WEB impl cargada (backend + sesión)",
    "color:#6B21A8;font-weight:bold"
  );
  (window as any).finUser = {
    async dump() {
      const sid = readSessionId();
      let user: Usuario | null = null;
      if (sid) {
        try {
          user = await obtenerUsuario(sid);
        } catch (e) {
          console.error("[finUser.dump] error obteniendo usuario actual:", e);
        }
      }
      console.log("[finUser.dump] sessionId:", sid, "user:", user);
    },
    clearAll() {
      localStorage.removeItem(SESSION_KEY);
      console.log("[finUser.clearAll] session cleared");
    },
  };
}

/* ============================================
   API: Usuarios (TestController)
   - GET  /api/Test/usuarios/{id}
   - GET  /api/Test/ByCorreo?correo=...
   - POST /api/Test/SingUp
   - POST /api/Test/ExisteCorreo
   - POST /api/Test/SingIn
============================================ */

/**
 * GET /api/Test/usuarios/{id}
 */
export async function obtenerUsuario(id: number): Promise<Usuario | null> {
  if (!id) return null;

  try {
    const dto = await ApiClient.get<any>(`/api/Test/usuarios/${id}`);
    if (!dto) return null;
    return mapDtoToUsuario(dto);
  } catch (e) {
    console.error("[UsuarioService.web.obtenerUsuario] error:", e);
    return null; // MUY IMPORTANTE: no propagamos el error
  }
}

/**
 * PUT /api/Usuario/{id} (⚠️ AÚN NO TIENES ESTE CONTROLLER)
 * La dejo preparada por si luego creas un UsuarioController.
 * De momento no la está llamando nada crítico.
 */
export async function upsertUsuario(u: Usuario): Promise<void> {
  if (!u.id_usuario) throw new Error("Usuario sin id_usuario");

  const payload = {
    IdUsuario: u.id_usuario,
    Nombre: u.Nombre ?? null,
    Apellido: (u as any).Apellido ?? null,
    Correo: u.Correo ?? null,
    FechaNacim: (u as any).FechaNacim ?? null,
    Avatar: (u as any).Avatar ?? null,
    Contra: u.Contra ?? null,
  };

  console.warn("[UsuarioService.web.upsertUsuario] Aún no hay endpoint /api/Usuario", payload);
  // Cuando tengas endpoint:
  // await ApiClient.put(`/api/Usuario/${u.id_usuario}`, payload);
}

/**
 * POST /api/Test/SingIn
 */
export async function obtenerUsuarioPorCorreo(
  correo: string,
  contra: string
): Promise<Usuario | null> {
  // Normalización básica del correo
  const wanted = (correo ?? "").normalize("NFKC").trim().toLowerCase();
  if (!wanted) return null;

  try {
    const payload = {
      correo: wanted,
      contra: contra ?? "",
    };

    const dto = await ApiClient.post<any>("/api/Test/SingIn", payload);

    if (typeof window !== "undefined") {
      console.log("[UsuarioService.web.SingIn]", { wanted, dto });
    }

    if (!dto) return null;
    return mapDtoToUsuario(dto);
  } catch (e) {
    // Si el backend devuelve 400 por credenciales inválidas, caerá acá
    console.error("[UsuarioService.web.obtenerUsuarioPorCorreo] error:", e);
    return null;
  }
}

/**
 * POST /api/Test/SingUp
 * + /api/Test/ExisteCorreo
 * Crea el usuario en el backend y devuelve el id real
 */
export async function registrarUsuario(data: RegistroPayload): Promise<number> {
  const payload = {
    Nombre: data.nombre,
    Apellido: data.apellido,
    FechaNacim: data.fechaNac,
    Correo: data.correo.trim().toLowerCase(),
    Contra: data.contra,
    Avatar: null as string | null,
  };

  console.log("[registrarUsuario.web] payload a enviar:", payload);

  // VALIDAR CORREO
  const correoExiste = await ApiClient.post<boolean>(
    "/api/Test/ExisteCorreo",
    { Correo: payload.Correo }
  );

  if (correoExiste) {
    if (typeof window !== "undefined") {
      alert("El correo ya existe");
    }
    throw new Error("Correo ya está registrado");
  }

  // CREAR USUARIO
  const dto = await ApiClient.post<any>("/api/Test/SingUp", payload);
  console.log("[registrarUsuario.web] respuesta del backend:", dto);

  if (!dto || (!dto.IdUsuario && !dto.idUsuario && !dto.id_usuario)) {
    console.error("[registrarUsuario.web] backend no devolvió idUsuario:", dto);
    throw new Error("Backend no devolvió id_usuario al registrar");
  }

  const user = mapDtoToUsuario(dto);

  // GUARDAR SESIÓN
  writeSessionId(user.id_usuario);

  if (typeof window !== "undefined") {
    console.log("[UsuarioService.web.register] creado en backend:", user);
  }

  return user.id_usuario;
}

/**
 * Inicia sesión localmente con un usuario existente (ya validado por backend)
 */
export async function iniciarSesion(u: Usuario): Promise<void> {
  if (!u.id_usuario) throw new Error("Usuario sin id_usuario");
  writeSessionId(u.id_usuario);
}

/**
 * Devuelve el usuario en sesión (leyendo id del localStorage y consultando al backend).
 * Si el backend ya no reconoce al usuario (o hay error fuerte), se fuerza logout y se redirige a /login.
 */
export async function obtenerSesion(): Promise<Usuario | null> {
  const sid = readSessionId();
  if (!sid) return null;

  try {
    const user = await obtenerUsuario(sid);

    if (!user) {
      forceLogoutAndRedirect();
      return null;
    }

    return user;
  } catch (e) {
    console.error("[UsuarioService.web.obtenerSesion] error:", e);
    forceLogoutAndRedirect();
    return null;
  }
}

/**
 * Cierra sesión
 */
export async function logoutLocal(): Promise<void> {
  writeSessionId(null);
  if (typeof window !== "undefined") {
    console.log("[UsuarioService.web.logout] session removed");
  }
}

/**
 * Devuelve solo el id real del usuario en sesión
 */
export async function getRealUserIdFromSession(): Promise<number | null> {
  return readSessionId();
}

export async function _debugDumpUsuarios(): Promise<void> {
  if (typeof window !== "undefined") {
    console.log(
      "[DEBUG Usuarios][web] backend mode. Usa window.finUser.dump() para ver usuario actual."
    );
  }
}
