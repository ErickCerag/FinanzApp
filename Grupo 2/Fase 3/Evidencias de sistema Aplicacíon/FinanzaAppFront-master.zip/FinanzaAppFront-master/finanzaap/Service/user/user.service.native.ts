// Service/user/user.service.native.ts
import { ApiClient } from "../ApiClient";
import { getDb } from "../DB_Conector";
import type { RegistroPayload, Usuario } from "./user.service";

const normEmail = (s?: string | null) =>
  (s ?? "").normalize("NFKC").trim().toLowerCase();

/* ====== Schema ====== */
async function ensureSchema() {
  const db: any = await getDb();
  await db.execAsync?.(`
    PRAGMA journal_mode = WAL;

    /* Tabla usuarios con UNIQUE por correo (case-insensitive) */
    CREATE TABLE IF NOT EXISTS Usuario (
      id_usuario  INTEGER PRIMARY KEY AUTOINCREMENT,
      Nombre      TEXT NOT NULL,
      Apellido    TEXT NULL,
      Correo      TEXT NULL UNIQUE COLLATE NOCASE,
      Contra      TEXT NULL,
      FechaNacim  TEXT NULL,
      Avatar      TEXT NULL
    );

    /* ✂️ Elimina índice viejo si aún existe en tu BD */
    DROP INDEX IF EXISTS UX_Usuario_Correo_Norm;

    /* Tabla de sesión: guarda el id REAL del usuario logueado */
    CREATE TABLE IF NOT EXISTS Session (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      real_user_id INTEGER NULL
    );
    INSERT OR IGNORE INTO Session (id, real_user_id) VALUES (1, NULL);

    /* Fila snapshot reservada (id=1). NUNCA debe tener Correo único. */
    INSERT OR IGNORE INTO Usuario (id_usuario, Nombre, Correo)
    VALUES (1, '__SESSION__', NULL);
  `);
}

/* ====== Lecturas locales (SQLite) ====== */
export async function obtenerUsuario(id: number): Promise<Usuario | null> {
  await ensureSchema();
  const db: any = await getDb();
  const rows = await db.getAllAsync?.(
    `SELECT id_usuario, Nombre, Correo, Avatar, Apellido, FechaNacim, Contra
     FROM Usuario WHERE id_usuario = ? LIMIT 1`,
    [id]
  );
  const dto = rows?.[0];
  if (!dto) return null;

  const u: Usuario = {
    id_usuario: dto.id_usuario,
    Nombre: dto.Nombre ?? "",
    Correo: dto.Correo ?? null,
    Avatar: dto.Avatar ?? null,
    Apellido: dto.Apellido ?? null,
    FechaNacim: dto.FechaNacim ?? null,
    Contra: dto.Contra ?? null,
  };
  return u;
}

/* ====== Map desde DTO del backend ====== */
function mapDtoToUsuario(dto: any): Usuario {
  return {
    id_usuario: dto.idUsuario ?? dto.IdUsuario ?? dto.id_usuario ?? 0,
    Nombre: dto.nombre ?? dto.Nombre ?? "",
    Apellido: dto.apellido ?? dto.Apellido ?? null,
    Correo: dto.correo ?? dto.Correo ?? "",
    FechaNacim:
      dto.fechaNacim ??
      dto.FechaNacim ??
      null,
    Avatar: dto.avatar ?? dto.Avatar ?? null,
    // Opcional: si el backend enviara hash, podríamos guardarlo,
    // por ahora asumimos que no viene la contraseña.
    Contra: null,
  };
}

/* ====== Login contra BACKEND ====== */
export async function obtenerUsuarioPorCorreo(
  correo: string,
  contra: string
): Promise<Usuario | null> {
  const wanted = normEmail(correo);
  if (!wanted) return null;

  try {
    const payload = {
      correo: wanted,
      contra: contra ?? "",
    };

    const dto = await ApiClient.post<any>("/api/Test/SingIn", payload);

    console.log("[UsuarioService.native.SingIn]", { wanted, dto });

    if (!dto) return null;
    return mapDtoToUsuario(dto);
  } catch (e) {
    console.error("[UsuarioService.native.obtenerUsuarioPorCorreo] error:", e);
    return null;
  }
}

/* ====== Registro contra BACKEND + cache local ====== */
export async function registrarUsuario(data: RegistroPayload): Promise<number> {
  await ensureSchema();
  const db: any = await getDb();

  const correoNorm = normEmail(data.correo);

  // 1) Validar correo en backend
  const correoExiste = await ApiClient.post<boolean>(
    "/api/Test/ExisteCorreo",
    { Correo: correoNorm }
  );

  if (correoExiste) {
    console.log("[registrarUsuario.native] correo ya existe", correoNorm);
    const err: any = new Error("Correo ya está registrado");
    err.code = 19;
    throw err;
  }

  // 2) Crear usuario en backend
  const payload = {
    Nombre: data.nombre.trim(),
    Apellido: data.apellido.trim(),
    FechaNacim: data.fechaNac, // yyyy-MM-dd
    Correo: correoNorm,
    Contra: data.contra,
    Avatar: null as string | null,
  };

  console.log("[registrarUsuario.native] payload a backend:", payload);

  const dto = await ApiClient.post<any>("/api/Test/SingUp", payload);
  console.log("[registrarUsuario.native] respuesta backend:", dto);

  if (!dto || (!dto.IdUsuario && !dto.idUsuario && !dto.id_usuario)) {
    console.error("[registrarUsuario.native] backend no devolvió id_usuario:", dto);
    throw new Error("Backend no devolvió id_usuario al registrar");
  }

  const user = mapDtoToUsuario(dto);

  // 3) Guardar/actualizar en SQLite local
  const correoLocal = user.Correo ? normEmail(user.Correo) : null;

  await db.runAsync?.(
    `INSERT INTO Usuario (id_usuario, Nombre, Apellido, FechaNacim, Correo, Contra, Avatar)
     VALUES (?, ?, ?, ?, ?, ?, ?)
     ON CONFLICT(id_usuario) DO UPDATE SET
       Nombre     = excluded.Nombre,
       Apellido   = excluded.Apellido,
       FechaNacim = excluded.FechaNacim,
       Correo     = excluded.Correo,
       Contra     = excluded.Contra,
       Avatar     = excluded.Avatar;`,
    [
      user.id_usuario,
      user.Nombre,
      user.Apellido ?? null,
      user.FechaNacim ?? null,
      correoLocal,
      user.Contra ?? null,
      user.Avatar ?? null,
    ]
  );

  // 4) Opcional: iniciar sesión inmediatamente (igual que en web)
  await iniciarSesion(user);

  return user.id_usuario;
}

/* ====== Upsert local (solo SQLite) ====== */
export async function upsertUsuario(u: Usuario): Promise<void> {
  await ensureSchema();
  const db: any = await getDb();
  const correo = u.Correo != null ? normEmail(u.Correo) : null;

  await db.runAsync?.(
    `INSERT INTO Usuario (id_usuario, Nombre, Correo, Avatar, Apellido, FechaNacim, Contra)
     VALUES (?, ?, ?, ?, ?, ?, ?)
     ON CONFLICT(id_usuario) DO UPDATE SET
       Nombre     = excluded.Nombre,
       Correo     = excluded.Correo,
       Avatar     = excluded.Avatar,
       Apellido   = excluded.Apellido,
       FechaNacim = excluded.FechaNacim,
       Contra     = COALESCE(excluded.Contra, Usuario.Contra);`,
    [
      u.id_usuario,
      u.Nombre,
      correo,
      u.Avatar ?? null,
      u.Apellido ?? null,
      u.FechaNacim ?? null,
      u.Contra ?? null,
    ]
  );
}

/* ====== Sesión (SQLite) ====== */
export async function iniciarSesion(u: Usuario): Promise<void> {
  await ensureSchema();
  const db: any = await getDb();

  // Snapshot id=1: SIN correo/contra para no chocar con UNIQUE
  await db.runAsync?.(
    `INSERT INTO Usuario (id_usuario, Nombre, Correo, Avatar, Apellido, FechaNacim)
     VALUES (1, ?, NULL, ?, ?, ?)
     ON CONFLICT(id_usuario) DO UPDATE SET
       Nombre     = excluded.Nombre,
       Avatar     = excluded.Avatar,
       Apellido   = excluded.Apellido,
       FechaNacim = excluded.FechaNacim;`,
    [
      u.Nombre,
      u.Avatar ?? null,
      u.Apellido ?? null,
      u.FechaNacim ?? null,
    ]
  );

  await db.runAsync?.(
    `INSERT INTO Session (id, real_user_id) VALUES (1, ?)
     ON CONFLICT(id) DO UPDATE SET real_user_id = excluded.real_user_id`,
    [u.id_usuario]
  );
}

/* Devuelve el USUARIO REAL (para Perfil) desde SQLite. */
export async function obtenerSesion(): Promise<Usuario | null> {
  await ensureSchema();
  const db: any = await getDb();
  const row = await db.getAllAsync?.(`SELECT real_user_id FROM Session WHERE id = 1`);
  const realId = row?.[0]?.real_user_id;
  if (!realId) return null;
  return await obtenerUsuario(realId);
}

export async function getRealUserIdFromSession(): Promise<number | null> {
  await ensureSchema();
  const db: any = await getDb();
  const rows = await db.getAllAsync?.(`SELECT real_user_id FROM Session WHERE id = 1`);
  const v = rows?.[0]?.real_user_id;
  return v != null ? Number(v) : null;
}

export async function logoutLocal(): Promise<void> {
  await ensureSchema();
  const db: any = await getDb();
  await db.runAsync?.(`DELETE FROM Usuario WHERE id_usuario = 1;`);
  await db.runAsync?.(`UPDATE Session SET real_user_id = NULL WHERE id = 1;`);
}

/* ====== Debug ====== */
export async function _debugDumpUsuarios(): Promise<void> {
  try {
    await ensureSchema();
    const db: any = await getDb();
    const usuarios = await db.getAllAsync?.(
      `SELECT id_usuario, Nombre, Correo, Contra, Avatar FROM Usuario ORDER BY id_usuario`
    );
    const session = await db.getAllAsync?.(
      `SELECT id, real_user_id FROM Session WHERE id = 1`
    );
    console.log("[DEBUG Usuarios][native]", usuarios ?? []);
    console.log("[DEBUG Session][native]", session ?? []);
  } catch (e) {
    console.log("[DEBUG Usuarios][native] error:", e);
  }
}

console.log("[UsuarioService] NATIVE impl cargada");
