// app/register.tsx
import DateTimePicker from "@react-native-community/datetimepicker";
import { useRouter } from "expo-router";
import { Formik } from "formik";
import { Calendar, Eye, EyeOff } from "lucide-react-native";
import React, { useState } from "react";
import {
  KeyboardAvoidingView,
  Modal,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import * as Yup from "yup";

// ⬇️ Servicio de usuarios
import {
  iniciarSesion,
  obtenerUsuario,
  registrarUsuario,
  upsertUsuario
} from "@/Service/user/user.service";

const PURPLE = "#6B21A8";
const GRAY_BORDER = "#E5E7EB";

const schema = Yup.object({
  nombre: Yup.string().trim().required("Requerido"),
  apellido: Yup.string().trim().required("Requerido"),
  fechaNac: Yup.string().required("Requerido"),
  contra: Yup.string().min(6, "Mínimo 6 caracteres").required("Requerido"),
});

export default function RegisterPage() {
  const router = useRouter();
  const [showPass, setShowPass] = useState(false);
  const [showPicker, setShowPicker] = useState(false);

  // Helpers formato fecha
  const formatDisplayDate = (iso?: string) => {
    if (!iso) return "";
    const [y, m, d] = iso.split("-");
    return `${d}-${m}-${y}`;
  };
  const toISO = (date: Date) => {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, "0");
    const d = String(date.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : undefined}
      style={{ flex: 1, backgroundColor: "#fff" }}
    >
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        {/* Header morado */}
        <View
          style={{
            backgroundColor: PURPLE,
            paddingTop: 48,
            paddingBottom: 20,
            paddingHorizontal: 20,
          }}
        >
          <Text style={{ color: "#fff", fontSize: 24, fontWeight: "700" }}>
            FinanzApp
          </Text>
          <Text style={{ color: "#EDE9FE", marginTop: 4 }}>
            Tu compañero de ahorro
          </Text>
        </View>

        <View
          style={{
            alignItems: "center",
            marginTop: 16,
            paddingHorizontal: 16,
          }}
        >
          <View
            style={{
              width: "100%",
              maxWidth: 520,
              backgroundColor: "#fff",
              padding: 16,
              borderRadius: 14,
            }}
          >
            <Text
              style={{
                fontSize: 20,
                color: "#111827",
                fontWeight: "600",
                marginBottom: 12,
              }}
            >
              Registro
            </Text>

            <Formik
              initialValues={{
                nombre: "",
                apellido: "",
                fechaNac: "",
                correo: "",
                contra: "",
                avatarUri: "" as string | undefined,
              }}
              validationSchema={schema}
              onSubmit={async (values, { setSubmitting, setFieldError }) => {
                try {
                  // 1) Validar que el correo no exista
                  // const existe = await obtenerUsuarioPorCorreo(values.correo);
                  // if (existe) {
                  //   setFieldError("correo", "Ya existe una cuenta con este correo");
                  //   return;
                  // }

                  // 2) Insertar usuario real
                  const newId = await registrarUsuario({
                    nombre: values.nombre,
                    apellido: values.apellido,
                    fechaNac: values.fechaNac,
                    correo: values.correo,
                    contra: values.contra,
                  });

                  // 3) (Opcional) avatar
                  if (values.avatarUri) {
                    await upsertUsuario({
                      id_usuario: newId,
                      Nombre: values.nombre,
                      Correo: values.correo.toLowerCase(),
                      Avatar: values.avatarUri,
                      Apellido: values.apellido,
                      FechaNacim: values.fechaNac,
                      Contra: null,
                    });
                  }

                  // 4) Poner en sesión
                  const u = await obtenerUsuario(newId);
                  if (u) {
                    await iniciarSesion(u);
                  }

                  // 5) Ir a tabs
                  router.replace("/(tabs)");
                } catch (e) {
                  setFieldError("correo", "No se pudo registrar. Intenta nuevamente.");
                } finally {
                  setSubmitting(false);
                }
              }}
            >
              {({
                handleChange,
                handleBlur,
                handleSubmit,
                values,
                errors,
                touched,
                isSubmitting,
                setFieldValue,
              }) => (
                <View style={{ gap: 14 }}>
                  {/* Nombre */}
                  <Field label="Nombre">
                    <TextInput
                      style={inputStyle}
                      value={values.nombre}
                      onChangeText={handleChange("nombre")}
                      onBlur={handleBlur("nombre")}
                      placeholder="Tu nombre"
                      placeholderTextColor="#9CA3AF"
                    />
                    <ErrorText error={touched.nombre && errors.nombre} />
                  </Field>

                  {/* Apellido */}
                  <Field label="Apellido">
                    <TextInput
                      style={inputStyle}
                      value={values.apellido}
                      onChangeText={handleChange("apellido")}
                      onBlur={handleBlur("apellido")}
                      placeholder="Tu apellido"
                      placeholderTextColor="#9CA3AF"
                    />
                    <ErrorText error={touched.apellido && errors.apellido} />
                  </Field>

                  {/* Fecha de nacimiento */}
                  <Field label="Fecha de nacimiento">
                    {Platform.OS === "web" ? (
                      <input
                        type="date"
                        value={values.fechaNac}
                        onChange={(e: any) =>
                          setFieldValue("fechaNac", e.target.value)
                        }
                        style={{
                          width: "100%",
                          padding: 14,
                          border: "1px solid #E5E7EB",
                          borderRadius: 10,
                          outline: "none",
                        }}
                      />
                    ) : (
                      <>
                        <View
                          style={{
                            flexDirection: "row",
                            alignItems: "center",
                          }}
                        >
                          <TextInput
                            value={
                              values.fechaNac
                                ? formatDisplayDate(values.fechaNac)
                                : ""
                            }
                            editable={false}
                            placeholder="Selecciona una fecha"
                            placeholderTextColor="#9CA3AF"
                            style={[inputStyle, { flex: 1 }]}
                          />
                          <TouchableOpacity
                            onPress={() => setShowPicker(true)}
                            style={{ padding: 8, marginLeft: 8 }}
                          >
                            <Calendar size={20} color={PURPLE} />
                          </TouchableOpacity>
                        </View>

                        {showPicker && (
                          <Modal transparent animationType="slide">
                            <View style={styles.modalBackdrop}>
                              <View style={styles.modalSheet}>
                                <View style={styles.modalHeader}>
                                  <TouchableOpacity
                                    onPress={() => setShowPicker(false)}
                                  >
                                    <Text style={{ color: "#666" }}>
                                      Cancelar
                                    </Text>
                                  </TouchableOpacity>
                                  <TouchableOpacity
                                    onPress={() => setShowPicker(false)}
                                  >
                                    <Text
                                      style={{
                                        color: PURPLE,
                                        fontWeight: "700",
                                      }}
                                    >
                                      Hecho
                                    </Text>
                                  </TouchableOpacity>
                                </View>

                                <View style={styles.pickerContainer}>
                                  <DateTimePicker
                                    value={
                                      values.fechaNac
                                        ? new Date(values.fechaNac)
                                        : new Date()
                                    }
                                    mode="date"
                                    display={
                                      Platform.OS === "ios"
                                        ? "spinner"
                                        : "calendar"
                                    }
                                    maximumDate={new Date()}
                                    textColor="#111"
                                    themeVariant="light"
                                    onChange={(event: any, selectedDate?: Date) => {
                                      if (Platform.OS === "android") {
                                        if (
                                          event.type === "set" &&
                                          selectedDate
                                        ) {
                                          setFieldValue(
                                            "fechaNac",
                                            toISO(selectedDate)
                                          );
                                        }
                                        setShowPicker(false);
                                      } else if (selectedDate) {
                                        setFieldValue(
                                          "fechaNac",
                                          toISO(selectedDate)
                                        );
                                      }
                                    }}
                                    style={{
                                      backgroundColor: "#fff",
                                      height: 220,
                                    }}
                                  />
                                </View>
                              </View>
                            </View>
                          </Modal>
                        )}
                      </>
                    )}
                    <ErrorText error={touched.fechaNac && errors.fechaNac} />
                  </Field>

                  {/* Correo */}
                  <Field label="Correo">
                    <TextInput
                      style={inputStyle}
                      value={values.correo}
                      onChangeText={handleChange("correo")}
                      onBlur={handleBlur("correo")}
                      keyboardType="email-address"
                      autoCapitalize="none"
                      placeholder="ejemplo@email.com"
                      placeholderTextColor="#9CA3AF"
                    />
                    <ErrorText error={touched.correo && errors.correo} />
                  </Field>

                  {/* Contraseña */}
                  <Field label="Contraseña">
                    <View style={{ position: "relative" }}>
                      <TextInput
                        style={{ ...inputStyle, paddingRight: 44 }}
                        value={values.contra}
                        onChangeText={handleChange("contra")}
                        onBlur={handleBlur("contra")}
                        secureTextEntry={!showPass}
                        placeholder="••••••••"
                        placeholderTextColor="#9CA3AF"
                      />
                      <TouchableOpacity
                        onPress={() => setShowPass((v) => !v)}
                        style={{ position: "absolute", right: 12, top: 12 }}
                        hitSlop={10}
                      >
                        {showPass ? (
                          <EyeOff color="#6B7280" size={22} />
                        ) : (
                          <Eye color="#6B7280" size={22} />
                        )}
                      </TouchableOpacity>
                    </View>
                    <ErrorText error={touched.contra && errors.contra} />
                  </Field>

                  {/* Botón */}
                  <TouchableOpacity
                    onPress={() => handleSubmit()}
                    disabled={isSubmitting}
                    style={{
                      backgroundColor: PURPLE,
                      borderRadius: 12,
                      paddingVertical: 14,
                      alignItems: "center",
                    }}
                  >
                    <Text style={{ color: "white", fontWeight: "700" }}>
                      {isSubmitting ? "Registrando..." : "Registrarse"}
                    </Text>
                  </TouchableOpacity>
                </View>
              )}
            </Formik>
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <View>
      <Text style={{ fontSize: 12, color: "#6b7280", marginBottom: 6 }}>
        {label}
      </Text>
      {children}
    </View>
  );
}

function ErrorText({ error }: { error: any }) {
  if (!error) return null;
  return (
    <Text style={{ marginTop: 6, color: "#DC2626", fontSize: 12 }}>
      {String(error)}
    </Text>
  );
}

const inputStyle = {
  paddingVertical: 14,
  paddingHorizontal: 14,
  borderWidth: 1,
  borderColor: GRAY_BORDER,
  borderRadius: 10,
} as const;

const styles = StyleSheet.create({
  modalBackdrop: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.4)",
    justifyContent: "flex-end",
  },
  modalSheet: {
    backgroundColor: "#fff",
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
    padding: 16,
  },
  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 8,
  },
  pickerContainer: {
    backgroundColor: "#fff",
    borderRadius: 12,
    overflow: "hidden",
  },
});
