// app/start.tsx
import { useEffect } from "react";
import { useRouter, Href } from "expo-router";
import { initDb } from "@/Service/DB_Conector";
import { obtenerSesion } from "@/Service/user/user.service";

const MAX_BOOT_MS = 4500; // ~4.5s para decidir

export default function Start() {
  const router = useRouter();

  useEffect(() => {
    let alive = true;

    const decide = async () => {
      // Inicializa la BD en segundo plano (no bloquea la decisión)
      (async () => {
        try {
          await (initDb as any)();
        } catch {
          // no-op
        }
      })();

      // 🔐 Chequeo de sesión activa
      const checkSession = (async () => {
        try {
          const sesion = await obtenerSesion();
          // Si hay algo en la sesión, consideramos que está logueado
          return !!sesion;
        } catch {
          return false;
        }
      })();

      // Timeout de seguridad
      const timeout = new Promise<boolean>((res) =>
        setTimeout(() => res(false), MAX_BOOT_MS)
      );

      const hasSession = await Promise.race([checkSession, timeout]);

      if (!alive) return;

      // Si hay sesión → tabs; si no → login
      router.replace((hasSession ? "/(tabs)" : "/login") as Href);
    };

    decide();

    return () => {
      alive = false;
    };
  }, [router]);

  // No renderiza nada, solo decide y redirige
  return null;
}
