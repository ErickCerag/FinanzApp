// app/_layout.tsx
import { DarkTheme, DefaultTheme } from '@react-navigation/native';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import 'react-native-reanimated';

import { useColorScheme } from 'hooks/use-color-scheme.web';

// Hacemos que la ruta inicial sea "start"
export const unstable_settings = {
  initialRouteName: 'start',
};

export default function RootLayout() {
  const colorScheme = useColorScheme();

  return (
    <Stack
      initialRouteName="start"
      screenOptions={{ headerShown: false }}
    >
      {/* Decide entre login o (tabs) */}
      <Stack.Screen name="start" />

      {/* Pantalla de login */}
      <Stack.Screen name="login" />

      {/* Registro */}
      <Stack.Screen name="register" />

      {/* Grupo de tabs (Inicio, Balance, Wishlist, etc.) */}
      <Stack.Screen name="(tabs)" />

      {/* Modal existente */}
      <Stack.Screen
        name="modal"
        options={{ presentation: 'modal', headerShown: true, title: 'Modal' }}
      />
      <StatusBar style="auto" />
    </Stack>
  );
}
