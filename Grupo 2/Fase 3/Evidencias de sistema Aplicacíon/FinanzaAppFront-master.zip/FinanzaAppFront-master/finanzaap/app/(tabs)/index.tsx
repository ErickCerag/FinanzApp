// app/index.tsx  (Inicio/Home) — sincronizado con @finanzapp_budget_header

import { initDb } from "@/Service/DB_Conector";
import { fetchExpenses, fetchIncomes } from "@/Service/budget/budget.service";
import { obtenerSesion } from "@/Service/user/user.service";
import { obtenerWishlistConItems } from "@/Service/wishList/wishlist.service";
import BottomNav from "@/components/BarraNav";
import { Ionicons } from "@expo/vector-icons";
import { Link, useFocusEffect } from "expo-router";
import React from "react";
import {
  ActivityIndicator,
  Dimensions,
  Image,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  Modal,
  Animated,
  Easing,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

const { width: screenWidth } = Dimensions.get("window");

/* Fallback por si no hay deseos aún */
const DEFAULT_CAROUSEL = [
  { title: "Bicicleta", price: "$300.000", message: "Estás a $50.000 de obtenerlo" },
  { title: "Viaje", price: "$1.500.000", message: "Estás a $500.000 de obtenerlo" },
];

const currency = (v: number) =>
  new Intl.NumberFormat("es-CL", {
    style: "currency",
    currency: "CLP",
    maximumFractionDigits: 0,
  }).format(v);

type CarouselItem = { title: string; price: string; message: string };

// Touchable con animación
const AnimatedTouchableOpacity = Animated.createAnimatedComponent(TouchableOpacity);

export default function HomeScreen() {
  const [booting, setBooting] = React.useState(true);
  const [activeIndex, setActiveIndex] = React.useState(0);
  const [nombre, setNombre] = React.useState<string>("Usuario");
  const [avatar, setAvatar] = React.useState<string | null>(null);

  const [totalIncome, setTotalIncome] = React.useState(0);
  const [totalExpenses, setTotalExpenses] = React.useState(0);
  const [availableMoney, setAvailableMoney] = React.useState(0);

  const [carouselItems, setCarouselItems] =
    React.useState<CarouselItem[]>(DEFAULT_CAROUSEL);

  // Estado del modal de ayuda
  const [helpVisible, setHelpVisible] = React.useState(false);

  // Animación bounce para el botón "?"
  const bounceAnim = React.useRef(new Animated.Value(1)).current;

  React.useEffect(() => {
    const loopBounce = () => {
      Animated.sequence([
        Animated.timing(bounceAnim, {
          toValue: 1.08,
          duration: 450,
          easing: Easing.out(Easing.quad),
          useNativeDriver: true,
        }),
        Animated.timing(bounceAnim, {
          toValue: 1,
          duration: 450,
          easing: Easing.in(Easing.quad),
          useNativeDriver: true,
        }),
      ]).start(({ finished }) => {
        if (finished) {
          // Pausa pequeña entre rebotes
          setTimeout(loopBounce, 2000);
        }
      });
    };

    loopBounce();
  }, [bounceAnim]);

  const loadData = React.useCallback(async () => {
    await initDb();

    // Usuario
    const u = await obtenerSesion();
    if (u?.Nombre) setNombre(u.Nombre);
    setAvatar(u?.Avatar ?? null);

    /* =========================
       1) Intentar leer header
          de Presupuesto
       ========================= */
    let ti = 0;
    let te = 0;
    let av = 0;
    let fromHeader = false;

    try {
      const raw = await AsyncStorage.getItem("@finanzapp_budget_header");
      if (raw) {
        const parsed = JSON.parse(raw);

        const tiRaw =
          parsed.totalIncome ??
          parsed.totalPresupuesto ??
          parsed.ingresos ??
          0;
        const teRaw =
          parsed.totalExpenses ??
          parsed.totalGastos ??
          parsed.gastos ??
          0;
        const avRaw =
          parsed.cumulativeAvailable ?? // 👈 prioridad al acumulado
          parsed.available ??
          parsed.availableMoney ??
          parsed.disponible ??
          null;

        const tiNum = Number(tiRaw);
        const teNum = Number(teRaw);
        const avNum =
          avRaw != null ? Number(avRaw) : tiNum - teNum; // fallback

        if (!Number.isNaN(tiNum) && !Number.isNaN(teNum) && !Number.isNaN(avNum)) {
          ti = tiNum;
          te = teNum;
          av = avNum;
          fromHeader = true;
        }
      }
    } catch {
      fromHeader = false;
    }

    /* =========================
       2) Si no hay header válido,
          calculamos desde la BD
       ========================= */
    if (!fromHeader) {
      try {
        const [ins, exps] = await Promise.all([fetchIncomes(), fetchExpenses()]);

        const tiNum = ins.reduce(
          (a: number, b: any) => a + (Number(b.amount ?? b.Amount ?? 0) || 0),
          0
        );
        const teNum = exps.reduce(
          (a: number, b: any) => a + (Number(b.amount ?? b.Amount ?? 0) || 0),
          0
        );

        ti = tiNum;
        te = teNum;
        av = tiNum - teNum;
      } catch {
        ti = 0;
        te = 0;
        av = 0;
      }
    }

    setTotalIncome(ti);
    setTotalExpenses(te);
    setAvailableMoney(av);

    /* =========================
       3) Wishlist → carrusel
       ========================= */
    try {
      const userId = u?.id_usuario ?? 1;
      const { items } = await obtenerWishlistConItems(userId);

      if (items && items.length > 0) {
        const mapped: CarouselItem[] = items.slice(0, 5).map((it) => ({
          title: it.Nombre,
          price: currency(Number(it.Monto || 0)),
          message: it.FechaLimite
            ? `Meta al ${new Date(it.FechaLimite).toLocaleDateString("es-CL")}`
            : "Guardado en tu wishlist",
        }));

        setCarouselItems(mapped);
      } else {
        setCarouselItems(DEFAULT_CAROUSEL);
      }
    } catch {
      setCarouselItems(DEFAULT_CAROUSEL);
    }

    setBooting(false);
  }, []);

  // Carga inicial
  React.useEffect(() => {
    let alive = true;
    (async () => {
      await loadData();
      if (!alive) return;
    })();
    return () => {
      alive = false;
    };
  }, [loadData]);

  // Refrescar al volver a Inicio
  useFocusEffect(
    React.useCallback(() => {
      loadData();
    }, [loadData])
  );

  // Auto–carrusel
  React.useEffect(() => {
    if (!carouselItems || carouselItems.length <= 1) return;

    const total = carouselItems.length;
    const id = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % total);
    }, 4000);

    return () => clearInterval(id);
  }, [carouselItems.length]);

  React.useEffect(() => {
    if (carouselItems.length === 0) {
      setActiveIndex(0);
      return;
    }
    if (activeIndex >= carouselItems.length) {
      setActiveIndex(0);
    }
  }, [carouselItems.length, activeIndex]);

  const nextItem = () =>
    setActiveIndex((p) =>
      carouselItems.length === 0 ? 0 : (p + 1) % carouselItems.length
    );
  const prevItem = () =>
    setActiveIndex((p) =>
      carouselItems.length === 0 ? 0 : p === 0 ? carouselItems.length - 1 : p - 1
    );

  if (booting) {
    return (
      <View
        style={{
          flex: 1,
          alignItems: "center",
          justifyContent: "center",
          backgroundColor: "#fff",
        }}
      >
        <ActivityIndicator size="large" color="#6B21A8" />
        <Text style={{ marginTop: 8, color: "#6b7280" }}>Cargando…</Text>
      </View>
    );
  }

  const current = carouselItems[activeIndex] ?? DEFAULT_CAROUSEL[0];

  return (
    <>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.container}>
          {/* Header con avatar y saludo */}
          <View style={styles.headerBox}>
            {avatar ? (
              <Image source={{ uri: avatar }} style={styles.headerAvatar} />
            ) : (
              <Ionicons
                name="person-circle"
                size={72}
                color="white"
                style={{ marginBottom: 8 }}
              />
            )}
            <Text style={styles.headerTitle}>Hola {nombre}</Text>

            <Text style={styles.headerSub}>Mi presupuesto</Text>
            <Text style={styles.headerAmount}>{currency(totalIncome)}</Text>

            <Text style={styles.headerSub}>Mis gastos</Text>
            <Text style={styles.headerAmount}>{currency(totalExpenses)}</Text>

            {/* Dinero disponible — ahora viene desde Presupuesto */}
            <Text style={styles.headerSub}>Dinero disponible</Text>
            <Text style={styles.headerAvailable}>{currency(availableMoney)}</Text>
          </View>

          <View style={styles.optionsRow}>
            <Link href="/(tabs)/Presupuesto" asChild>
              <TouchableOpacity style={styles.optionCard}>
                <Text style={styles.optionText}>Gestionar presupuesto</Text>
                <Ionicons name="chevron-forward" size={20} color="#4B0082" />
              </TouchableOpacity>
            </Link>

            <Link href="/WishList/wishlist" asChild>
              <TouchableOpacity style={styles.optionCard}>
                <Text style={styles.optionText}>Mi lista de deseos</Text>
                <Ionicons name="chevron-forward" size={20} color="#4B0082" />
              </TouchableOpacity>
            </Link>
          </View>

          {/* Carrusel Wishlist */}
          <View style={styles.carouselContainer}>
            <View style={styles.carouselCard}>
              <Text style={styles.carouselTitle}>{current.title}</Text>
              <Text style={styles.carouselPrice}>{current.price}</Text>
              <Text style={styles.carouselMessage}>{current.message}</Text>
            </View>
            <View style={styles.carouselControls}>
              <TouchableOpacity onPress={prevItem}>
                <Ionicons name="chevron-back" size={18} color="black" />
              </TouchableOpacity>
              <Ionicons
                name="ellipse"
                size={10}
                color="black"
                style={{ marginHorizontal: 6 }}
              />
              <TouchableOpacity onPress={nextItem}>
                <Ionicons name="chevron-forward" size={18} color="black" />
              </TouchableOpacity>
            </View>
          </View>

          {/* Ayuda flotante */}
          <View style={styles.helpWrapper}>
            <AnimatedTouchableOpacity
              style={[styles.helpFab, { transform: [{ scale: bounceAnim }] }]}
              onPress={() => setHelpVisible(true)}
              activeOpacity={0.85}
            >
              <Text style={styles.helpFabText}>?</Text>
            </AnimatedTouchableOpacity>
            <Text style={styles.helpHint}>¿Necesitas ayuda?</Text>
          </View>

          <BottomNav active="home" />
        </View>
      </ScrollView>

      {/* Modal de ayuda */}
      <Modal
        visible={helpVisible}
        transparent
        animationType="fade"
        onRequestClose={() => setHelpVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <View style={styles.modalIconCircle}>
              <Text style={styles.modalIconText}>?</Text>
            </View>
            <Text style={styles.modalTitle}>Guía rápida</Text>
            <Text style={styles.modalText}>
              Este es tu incio, aquí ves tus ingresos y gastos, junto a tu dinero disponible. Puedes
              gestionar tu presupuesto y crear tu wishlist.
            </Text>
            <TouchableOpacity
              style={styles.modalButton}
              onPress={() => setHelpVisible(false)}
            >
              <Text style={styles.modalButtonText}>Entendido</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  scrollContainer: {
    flexGrow: 1,
    backgroundColor: "#F8F8F8",
    justifyContent: "space-between",
  },
  container: { flex: 1, alignItems: "center", paddingVertical: 24, paddingBottom: 80 },
  headerBox: {
    backgroundColor: "#6418C3",
    borderRadius: 12,
    padding: 20,
    width: "90%",
    alignItems: "center",
  },
  headerAvatar: {
    width: 72,
    height: 72,
    borderRadius: 36,
    marginBottom: 8,
    borderWidth: 2,
    borderColor: "rgba(255,255,255,0.6)",
  },
  headerTitle: { fontSize: 18, color: "white", fontWeight: "bold" },
  headerSub: { fontSize: 14, color: "white", marginTop: 6 },
  headerAmount: { fontSize: 16, color: "white", fontWeight: "bold" },
  headerAvailable: {
    fontSize: 18,
    fontWeight: "800",
    color: "#4ade80",
    marginTop: 4,
  },
  optionsRow: {
    flexDirection: screenWidth > 700 ? "row" : "column",
    width: "90%",
    justifyContent: "space-between",
    marginVertical: 20,
    gap: 12,
  },
  optionCard: {
    backgroundColor: "white",
    padding: 16,
    borderRadius: 10,
    flex: 1,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    elevation: 2,
  },
  optionText: { fontSize: 15, color: "#4B0082" },
  carouselContainer: {
    width: "90%",
    backgroundColor: "white",
    borderRadius: 10,
    padding: 20,
    marginBottom: 16,
    alignItems: "center",
    elevation: 2,
  },
  carouselCard: { alignItems: "center" },
  carouselTitle: { fontWeight: "bold", fontSize: 16 },
  carouselPrice: { fontWeight: "bold", fontSize: 16, marginTop: 4 },
  carouselMessage: { marginTop: 4, fontSize: 13, color: "gray" },
  carouselControls: { flexDirection: "row", marginTop: 12, alignItems: "center" },

  // Ayuda
  helpWrapper: {
    marginTop: 8,
    alignItems: "center",
    justifyContent: "center",
  },
  helpFab: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: "#6B21A8",
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 4,
  },
  helpFabText: {
    color: "white",
    fontWeight: "bold",
    fontSize: 22,
    marginTop: -2,
  },
  helpHint: {
    marginTop: 4,
    fontSize: 12,
    color: "#6b7280",
  },

  // Modal de ayuda
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(15,23,42,0.55)",
    alignItems: "center",
    justifyContent: "center",
    padding: 24,
  },
  modalCard: {
    width: "100%",
    maxWidth: 420,
    backgroundColor: "#ffffff",
    borderRadius: 18,
    paddingVertical: 24,
    paddingHorizontal: 20,
    alignItems: "center",
  },
  modalIconCircle: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: "#6B21A8",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 12,
  },
  modalIconText: {
    color: "white",
    fontSize: 28,
    fontWeight: "bold",
    marginTop: -3,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: "#111827",
    marginBottom: 8,
    textAlign: "center",
  },
  modalText: {
    fontSize: 14,
    color: "#4b5563",
    textAlign: "center",
    lineHeight: 20,
  },
  modalButton: {
    marginTop: 22,
    backgroundColor: "#6B21A8",
    paddingVertical: 10,
    paddingHorizontal: 26,
    borderRadius: 999,
  },
  modalButtonText: {
    color: "white",
    fontWeight: "600",
    fontSize: 14,
  },
});
