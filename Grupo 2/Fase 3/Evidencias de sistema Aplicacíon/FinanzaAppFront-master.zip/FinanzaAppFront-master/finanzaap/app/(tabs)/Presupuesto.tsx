// app/(tabs)/Presupuesto.tsx
import { useRouter } from "expo-router";
import { ArrowLeft, CheckSquare, MoreHorizontal, Plus, Square } from "lucide-react-native";
import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  InputAccessoryView,
  Keyboard,
  KeyboardAvoidingView,
  Modal,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  Animated,
  Easing,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import {
  addExpense,
  addIncome,
  deleteExpense,
  deleteIncome,
  fetchExpenses,
  fetchIncomes,
  updateExpense,
  updateIncome,
  type Expense,
  type Income,
} from "@/Service/budget/budget.service";

import BottomNav from "@/components/BarraNav";
import AsyncStorage from "@react-native-async-storage/async-storage";

/* ======== Constantes/Helpers UI ======== */
const PURPLE = "#6B21A8";
const PURPLE_LIGHT = "#A855F7"; // morado más tenue para estado "guardando"
const GRAY_BORDER = "#E5E7EB";
const isIOS = Platform.OS === "ios";
const isWeb = Platform.OS === "web";

const currency = (v: number) =>
  new Intl.NumberFormat("es-CL", {
    style: "currency",
    currency: "CLP",
    maximumFractionDigits: 0,
  }).format(v);
const onlyDigits = (s: string) => s.replace(/\D+/g, "");

// Meses en español
const MONTH_NAMES_ES = [
  "Enero",
  "Febrero",
  "Marzo",
  "Abril",
  "Mayo",
  "Junio",
  "Julio",
  "Agosto",
  "Septiembre",
  "Octubre",
  "Noviembre",
  "Diciembre",
];

// ✅ Claves para la simulación
const SIM_MAX_OFFSET_KEY = "finanzapp_max_month_offset_v1";
const SIM_STATE_KEY = "finanzapp_sim_months_state_v1";

/* ======== Tipos extendidos solo para la UI (cuotas) ======== */
type IncomeUI = Income & {
  installmentsTotal?: number | null;
  installmentsRemaining?: number | null;
};

type ExpenseUI = Expense & {
  installmentsTotal?: number | null;
  installmentsRemaining?: number | null;
};

/* ======== DoneBar iOS ======== */
function DoneBar({ nativeID, onDone }: { nativeID: string; onDone: () => void }) {
  if (!isIOS) return null;
  return (
    <InputAccessoryView nativeID={nativeID}>
      <View style={styles.accessoryBar}>
        <View style={{ flex: 1 }} />
        <TouchableOpacity onPress={onDone}>
          <Text style={styles.accessoryBtn}>Listo</Text>
        </TouchableOpacity>
      </View>
    </InputAccessoryView>
  );
}

/* ======== Modal (agregar / editar) ======== */
function BudgetModal({
  visible,
  onClose,
  type,
  editingItem,
  onSubmit,
}: {
  visible: boolean;
  onClose: () => void;
  type: "income" | "expense";
  editingItem: IncomeUI | ExpenseUI | null;
  onSubmit: (data: {
    name: string;
    amount: number;
    day?: number;
    isFixed?: boolean;
    installmentsTotal?: number;
  }) => Promise<void> | void;
}) {
  const isEditing = !!editingItem;

  const [name, setName] = useState("");
  const [amountRaw, setAmountRaw] = useState("");
  const [dayRaw, setDayRaw] = useState("01");
  const [isFixed, setIsFixed] = useState(false);

  const [hasInstallments, setHasInstallments] = useState(false);
  const [installmentsRaw, setInstallmentsRaw] = useState("");

  const [submitting, setSubmitting] = useState(false); // ⬅️ estado de guardado

  const refAmount = useRef<TextInput>(null);
  const refDay = useRef<TextInput>(null);
  const refInstallments = useRef<TextInput>(null);

  useEffect(() => {
    if (visible) {
      if (isEditing && editingItem) {
        setName(editingItem.name);
        setAmountRaw(String(editingItem.amount));
        if (type === "expense") {
          setDayRaw(String((editingItem as ExpenseUI).day).padStart(2, "0"));
        }
        setIsFixed(!!(editingItem as any)?.isFixed);

        const anyItem = editingItem as any;
        const total = Number(anyItem.installmentsTotal ?? 0);
        if (total > 0) {
          setHasInstallments(true);
          setInstallmentsRaw(String(total));
        } else {
          setHasInstallments(false);
          setInstallmentsRaw("");
        }
      } else {
        setName(type === "income" ? "Sueldo" : "");
        setAmountRaw("");
        setDayRaw("01");
        setIsFixed(false);
        setHasInstallments(false);
        setInstallmentsRaw("");
      }
    }
  }, [visible, isEditing, editingItem, type]);

  const handleSubmit = async () => {
    if (submitting) return; // por seguridad extra

    const amount = Number(onlyDigits(amountRaw) || "0");
    const trimmedName = name.trim();

    if (!trimmedName || amount <= 0) {
      if (isWeb) {
        window.alert("Nombre y monto son obligatorios.");
      } else {
        Alert.alert("Completa los datos", "Nombre y monto son obligatorios.");
      }
      return;
    }

    let installmentsTotal = 0;
    if (hasInstallments) {
      installmentsTotal = Number(onlyDigits(installmentsRaw) || "0");
      if (!Number.isFinite(installmentsTotal) || installmentsTotal < 1) {
        if (isWeb) {
          window.alert("Ingresa la cantidad de cuotas (mínimo 1).");
        } else {
          Alert.alert("Cuotas inválidas", "Ingresa la cantidad de cuotas (mínimo 1).");
        }
        return;
      }
    }

    if (type === "expense") {
      const day = Number(onlyDigits(dayRaw) || "0");
      if (day < 1 || day > 31) {
        if (isWeb) {
          window.alert("El día debe estar entre 1 y 31.");
        } else {
          Alert.alert("Día inválido", "El día debe estar entre 1 y 31.");
        }
        return;
      }

      setSubmitting(true);
      try {
        await onSubmit({
          name: trimmedName,
          amount,
          day,
          isFixed,
          installmentsTotal: hasInstallments ? installmentsTotal : undefined,
        });
      } finally {
        setSubmitting(false);
      }
    } else {
      setSubmitting(true);
      try {
        await onSubmit({
          name: trimmedName,
          amount,
          isFixed,
          installmentsTotal: hasInstallments ? installmentsTotal : undefined,
        });
      } finally {
        setSubmitting(false);
      }
    }
  };

  const modalTitle = isEditing
    ? `Editar ${type === "income" ? "ingreso" : "gasto"}`
    : `Agregar ${type === "income" ? "ingreso" : "gasto"}`;

  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <View style={styles.modalBackdrop}>
        <KeyboardAvoidingView
          behavior={isIOS ? "padding" : undefined}
          keyboardVerticalOffset={isIOS ? 12 : 0}
        >
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>{modalTitle}</Text>

            {/* Nombre */}
            <Text style={styles.label}>Nombre</Text>
            <TextInput
              value={name}
              onChangeText={setName}
              placeholder={type === "income" ? "Ej: Sueldo" : "Ej: Arriendo"}
              style={styles.input}
              returnKeyType="next"
              blurOnSubmit
            />

            {/* Monto */}
            <Text style={[styles.label, { marginTop: 12 }]}>Monto</Text>
            <TextInput
              ref={refAmount}
              value={
                Number(onlyDigits(amountRaw) || "0") > 0
                  ? currency(Number(onlyDigits(amountRaw)))
                  : ""
              }
              onChangeText={(t) => setAmountRaw(onlyDigits(t))}
              placeholder="$ 0"
              keyboardType={isIOS ? "number-pad" : "numeric"}
              style={styles.input}
              inputAccessoryViewID={isIOS ? `acc-${type}-amount` : undefined}
            />

            {/* Fijo + Cuotas en la misma fila */}
            <View style={styles.fixedRow}>
              <TouchableOpacity onPress={() => setIsFixed((v) => !v)}>
                {isFixed ? (
                  <CheckSquare size={20} color={PURPLE} />
                ) : (
                  <Square size={20} color="#6B7280" />
                )}
              </TouchableOpacity>
              <Text style={styles.fixedLabel}>
                {type === "income" ? "¿Ingreso fijo?" : "¿Gasto fijo?"}
              </Text>

              <View style={{ flex: 1 }} />

              <TouchableOpacity onPress={() => setHasInstallments((v) => !v)}>
                {hasInstallments ? (
                  <CheckSquare size={20} color={PURPLE} />
                ) : (
                  <Square size={20} color="#6B7280" />
                )}
              </TouchableOpacity>
              <Text style={styles.fixedLabel}>¿Tiene cuotas?</Text>
            </View>

            {/* Día (solo gastos) */}
            {type === "expense" && (
              <>
                <Text style={[styles.label, { marginTop: 12 }]}>Día del mes (1–31)</Text>
                <TextInput
                  ref={refDay}
                  value={dayRaw}
                  onChangeText={(t) => setDayRaw(onlyDigits(t).slice(0, 2))}
                  placeholder="01"
                  maxLength={2}
                  keyboardType={isIOS ? "number-pad" : "numeric"}
                  style={styles.input}
                  inputAccessoryViewID={isIOS ? `acc-${type}-day` : undefined}
                />
              </>
            )}

            {/* Cantidad de cuotas */}
            {hasInstallments && (
              <>
                <Text style={[styles.label, { marginTop: 12 }]}>Cantidad de cuotas</Text>
                <TextInput
                  ref={refInstallments}
                  value={installmentsRaw}
                  onChangeText={(t) => setInstallmentsRaw(onlyDigits(t).slice(0, 2))}
                  placeholder="Ej: 6"
                  maxLength={2}
                  keyboardType={isIOS ? "number-pad" : "numeric"}
                  style={styles.input}
                  inputAccessoryViewID={isIOS ? `acc-${type}-installments` : undefined}
                />
              </>
            )}

            <View style={styles.modalActions}>
              <TouchableOpacity onPress={onClose} disabled={submitting}>
                <Text style={{ color: "#666" }}>Cancelar</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={handleSubmit}
                disabled={submitting}
                style={{ opacity: submitting ? 0.6 : 1 }}
              >
                <Text
                  style={{
                    color: submitting ? PURPLE_LIGHT : PURPLE,
                    fontWeight: "700",
                  }}
                >
                  Guardar
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </KeyboardAvoidingView>
      </View>

      <DoneBar
        nativeID={`acc-${type}-amount`}
        onDone={() => {
          refAmount.current?.blur();
          Keyboard.dismiss();
        }}
      />
      {type === "expense" && (
        <DoneBar
          nativeID={`acc-${type}-day`}
          onDone={() => {
            refDay.current?.blur();
            Keyboard.dismiss();
          }}
        />
      )}
      {hasInstallments && (
        <DoneBar
          nativeID={`acc-${type}-installments`}
          onDone={() => {
            refInstallments.current?.blur();
            Keyboard.dismiss();
          }}
        />
      )}
    </Modal>
  );
}

const AnimatedTouchableOpacity = Animated.createAnimatedComponent(TouchableOpacity);

/* ======== Componente Principal ======== */

export default function BudgetPage() {
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Lo que se muestra EN PANTALLA (mes actual o simulado)
  const [incomes, setIncomes] = useState<IncomeUI[]>([]);
  const [expenses, setExpenses] = useState<ExpenseUI[]>([]);

  // Snapshot del MES REAL
  const [currentMonthIncomes, setCurrentMonthIncomes] = useState<IncomeUI[]>([]);
  const [currentMonthExpenses, setCurrentMonthExpenses] = useState<ExpenseUI[]>([]);

  // 🔹 NUEVO: snapshots en memoria para cada mes simulado (0..N)
  const [simSnapshots, setSimSnapshots] = useState<
    Record<number, { incomes: IncomeUI[]; expenses: ExpenseUI[] }>
  >({});

  const [modalState, setModalState] = useState<{
    visible: boolean;
    type: "income" | "expense";
    editingItem: IncomeUI | ExpenseUI | null;
  }>({
    visible: false,
    type: "income",
    editingItem: null,
  });

  const [menu, setMenu] = useState<{
    type: "income" | "expense";
    id: number;
    x: number;
    y: number;
  } | null>(null);

  // Mes simulado (0 = actual, 1 = próximo, etc.)
  const [monthOffset, setMonthOffset] = useState(0);

  const { monthName } = useMemo(() => {
    const now = new Date();
    const d = new Date(now.getFullYear(), now.getMonth() + monthOffset, 1);
    return {
      monthName: MONTH_NAMES_ES[d.getMonth()],
    };
  }, [monthOffset]);

  // ====== AYUDA (botón flotante + modal) ======
  const [helpVisible, setHelpVisible] = useState(false);
  const bounceAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    const loopBounce = () => {
      Animated.sequence([
        Animated.timing(bounceAnim, {
          toValue: 1.08,
          duration: 450,
          easing: Easing.out(Easing.quad),
          useNativeDriver: true,
        }),
        Animated.timing(bounceAnim, {
          toValue: 1,
          duration: 450,
          easing: Easing.in(Easing.quad),
          useNativeDriver: true,
        }),
      ]).start(({ finished }) => {
        if (finished) {
          setTimeout(loopBounce, 2000);
        }
      });
    };

    loopBounce();
  }, [bounceAnim]);

  const loadAll = useCallback(async () => {
    try {
      setLoading(true);
      const [ins, exps] = await Promise.all([fetchIncomes(), fetchExpenses()]);

      const insUI: IncomeUI[] = ins as IncomeUI[];
      const expsUI: ExpenseUI[] = exps as ExpenseUI[];

      setCurrentMonthIncomes(insUI);
      setCurrentMonthExpenses(expsUI);

      if (monthOffset === 0) {
        setIncomes(insUI);
        setExpenses(expsUI);
      }
      setError(null);
    } catch (e) {
      console.error(e);
      setError("No se pudieron cargar los datos.");
    } finally {
      setLoading(false);
    }
  }, [monthOffset]);

  useEffect(() => {
    loadAll();
  }, [loadAll]);

  const totalIncome = useMemo(
    () => incomes.reduce((a, b) => a + b.amount, 0),
    [incomes]
  );
  const totalExpenses = useMemo(
    () => expenses.reduce((a, b) => a + b.amount, 0),
    [expenses]
  );

  // 🔹 NUEVO: dinero disponible ACUMULADO desde offset 0 hasta monthOffset
  const cumulativeAvailable = useMemo(() => {
    let acc = 0;

    for (let off = 0; off <= monthOffset; off++) {
      const snap =
        off === monthOffset
          ? { incomes, expenses }
          : simSnapshots[off] ?? { incomes: [], expenses: [] };

      const totInc = snap.incomes.reduce((s, i) => s + (i.amount ?? 0), 0);
      const totExp = snap.expenses.reduce((s, g) => s + (g.amount ?? 0), 0);

      acc += totInc - totExp;
    }

    return acc;
  }, [monthOffset, incomes, expenses, simSnapshots]);

  // 👉 Guardar totales para que Inicio los lea
  useEffect(() => {
    const saveHeaderTotals = async () => {
      try {
        const available = totalIncome - totalExpenses;

        await AsyncStorage.setItem(
          "@finanzapp_budget_header",
          JSON.stringify({
            totalIncome,
            totalExpenses,
            available, // disponible del mes actual
            cumulativeAvailable, // 👈 NUEVO: disponible acumulado
            monthOffset,
          })
        );
      } catch {
        // ignorar errores de storage
      }
    };

    saveHeaderTotals();
  }, [totalIncome, totalExpenses, cumulativeAvailable, monthOffset]);

  const openAddModal = (type: "income" | "expense") => {
    setModalState({ visible: true, type, editingItem: null });
  };

  const openEditModal = (type: "income" | "expense", item: IncomeUI | ExpenseUI) => {
    setModalState({ visible: true, type, editingItem: item });
  };

  const closeModal = () => {
    setModalState((prev) => ({ ...prev, visible: false }));
  };

  // 👉 Guardar estado (incluye mes actual) para que Balance lo use (web: sessionStorage, native: AsyncStorage)
  useEffect(() => {
    const saveState = async () => {
      try {
        const snapshot = { incomes, expenses };

        // guardamos en memoria para poder acumular disponible
        setSimSnapshots((prev) => ({
          ...prev,
          [monthOffset]: snapshot,
        }));

        if (isWeb) {
          const raw = window.sessionStorage.getItem(SIM_STATE_KEY);
          const data = raw ? JSON.parse(raw) : {};
          data[monthOffset] = snapshot;
          window.sessionStorage.setItem(SIM_STATE_KEY, JSON.stringify(data));
        } else {
          const raw = await AsyncStorage.getItem(SIM_STATE_KEY);
          const data = raw ? JSON.parse(raw) : {};
          data[monthOffset] = snapshot;
          await AsyncStorage.setItem(SIM_STATE_KEY, JSON.stringify(data));
        }
      } catch {
        /* ignore */
      }
    };

    saveState();
  }, [monthOffset, incomes, expenses]);

  const handleModalSubmit = async (data: {
    name: string;
    amount: number;
    day?: number;
    isFixed?: boolean;
    installmentsTotal?: number;
  }) => {
    const { type, editingItem } = modalState;
    const isEditing = !!editingItem;
    const isCurrentMonth = monthOffset === 0;

    const installmentsTotal =
      data.installmentsTotal && data.installmentsTotal > 0
        ? data.installmentsTotal
        : undefined;

    if (isCurrentMonth) {
      // Mes real → backend (sin cuotas en el servidor, sólo en la UI)
      try {
        if (isEditing) {
          if (type === "income") {
            const updated = await updateIncome({
              id: editingItem!.id,
              name: data.name,
              amount: data.amount,
              isFixed: data.isFixed ?? false,
            });
            const updatedUI: IncomeUI = {
              ...(updated as IncomeUI),
              installmentsTotal,
              installmentsRemaining: installmentsTotal ?? undefined,
            };
            setIncomes((prev) => {
              const next = prev.map((i) => (i.id === updated.id ? updatedUI : i));
              setCurrentMonthIncomes(next);
              return next;
            });
          } else {
            const updated = await updateExpense({
              id: editingItem!.id,
              name: data.name,
              amount: data.amount,
              day: data.day!,
              isFixed: data.isFixed ?? false,
            });
            const updatedUI: ExpenseUI = {
              ...(updated as ExpenseUI),
              installmentsTotal,
              installmentsRemaining: installmentsTotal ?? undefined,
            };
            setExpenses((prev) => {
              const next = prev.map((g) => (g.id === updated.id ? updatedUI : g));
              setCurrentMonthExpenses(next);
              return next;
            });
          }
        } else {
          if (type === "income") {
            const created = await addIncome({
              name: data.name,
              amount: data.amount,
              isFixed: data.isFixed ?? false,
            });
            const createdUI: IncomeUI = {
              ...(created as IncomeUI),
              installmentsTotal,
              installmentsRemaining: installmentsTotal ?? undefined,
            };
            setIncomes((prev) => {
              const next = [createdUI, ...prev];
              setCurrentMonthIncomes(next);
              return next;
            });
          } else {
            const created = await addExpense({
              name: data.name,
              amount: data.amount,
              day: data.day!,
              isFixed: data.isFixed ?? false,
            });
            const createdUI: ExpenseUI = {
              ...(created as ExpenseUI),
              installmentsTotal,
              installmentsRemaining: installmentsTotal ?? undefined,
            };
            setExpenses((prev) => {
              const next = [createdUI, ...prev];
              setCurrentMonthExpenses(next);
              return next;
            });
          }
        }
        closeModal();
      } catch (e) {
        console.error(e);
        Alert.alert(
          "Error",
          `No se pudo ${isEditing ? "actualizar" : "agregar"} el ${
            type === "income" ? "ingreso" : "gasto"
          }.`
        );
      }
    } else {
      // Mes simulado → solo estado local
      if (isEditing) {
        if (type === "income") {
          setIncomes((prev) =>
            prev.map((i) =>
              i.id === editingItem!.id
                ? {
                    ...i,
                    name: data.name,
                    amount: data.amount,
                    isFixed: data.isFixed ?? false,
                    installmentsTotal,
                    installmentsRemaining: installmentsTotal ?? i.installmentsRemaining,
                  }
                : i
            )
          );
        } else {
          setExpenses((prev) =>
            prev.map((g) =>
              g.id === editingItem!.id
                ? {
                    ...g,
                    name: data.name,
                    amount: data.amount,
                    day: data.day!,
                    isFixed: data.isFixed ?? false,
                    installmentsTotal,
                    installmentsRemaining: installmentsTotal ?? g.installmentsRemaining,
                  }
                : g
            )
          );
        }
      } else {
        const fakeId = Date.now();
        if (type === "income") {
          const created: IncomeUI = {
            id: fakeId,
            name: data.name,
            amount: data.amount,
            isFixed: data.isFixed ?? false,
            installmentsTotal,
            installmentsRemaining: installmentsTotal ?? undefined,
          };
          setIncomes((prev) => [created, ...prev]);
        } else {
          const created: ExpenseUI = {
            id: fakeId,
            name: data.name,
            amount: data.amount,
            day: data.day!,
            isFixed: data.isFixed ?? false,
            installmentsTotal,
            installmentsRemaining: installmentsTotal ?? undefined,
          };
          setExpenses((prev) => [created, ...prev]);
        }
      }
      closeModal();
    }
  };

  const confirmDelete = (type: "income" | "expense", id: number, name: string) => {
    const isCurrentMonth = monthOffset === 0;

    const run = async () => {
      if (isCurrentMonth) {
        try {
          if (type === "income") {
            await deleteIncome(id);
            setIncomes((prev) => {
              const next = prev.filter((i) => i.id !== id);
              setCurrentMonthIncomes(next);
              return next;
            });
          } else {
            await deleteExpense(id);
            setExpenses((prev) => {
              const next = prev.filter((g) => g.id !== id);
              setCurrentMonthExpenses(next);
              return next;
            });
          }
        } catch (e) {
          console.error(e);
          Alert.alert("Error", "No se pudo eliminar.");
        }
      } else {
        if (type === "income") {
          setIncomes((prev) => prev.filter((i) => i.id !== id));
        } else {
          setExpenses((prev) => prev.filter((g) => g.id !== id));
        }
      }
    };

    if (isWeb) {
      if (window.confirm(`¿Eliminar "${name}"?`)) run();
    } else {
      Alert.alert("Eliminar", `¿Eliminar "${name}"?`, [
        { text: "Cancelar", style: "cancel" },
        { text: "Eliminar", style: "destructive", onPress: run },
      ]);
    }
  };

  // 👉 Continuar al próximo mes (simulado)
  const handleContinueBudgetNextMonth = () => {
    const message = "Solo se trasladarán los ingresos y gastos fijos y en cuotas al próximo mes.";

    const run = () => {
      const nextOffset = monthOffset + 1;

      // Ingresos: sólo fijos
      setIncomes((prev) => prev.filter((i) => i.isFixed));

      // Gastos: fijos + cuotas (disminuyendo cuotas restantes)
      setExpenses((prev) => {
        const next: ExpenseUI[] = [];

        prev.forEach((g) => {
          const total = g.installmentsTotal ?? 0;
          const remaining =
            g.installmentsRemaining ??
            (total > 0 ? total : 0);

          if (total > 0 && remaining > 0) {
            const newRemaining = remaining - 1;
            if (newRemaining > 0) {
              next.push({
                ...g,
                installmentsTotal: total,
                installmentsRemaining: newRemaining,
              });
            }
            // si llega a 0, ya no se agrega (cuotas terminadas)
          } else if (g.isFixed) {
            next.push(g);
          }
        });

        return next;
      });

      // Guardamos qué tan lejos llegó la simulación
      if (isWeb) {
        try {
          const prevStored = Number(
            window.sessionStorage.getItem(SIM_MAX_OFFSET_KEY) || "0"
          );
          const toStore = Math.max(prevStored, nextOffset);
          window.sessionStorage.setItem(SIM_MAX_OFFSET_KEY, String(toStore));
        } catch {
          /* ignore */
        }
      } else {
        AsyncStorage.setItem(SIM_MAX_OFFSET_KEY, String(nextOffset)).catch(() => {});
      }

      setMonthOffset(nextOffset);
    };

    if (isWeb) {
      if (window.confirm(message)) run();
    } else {
      Alert.alert("Continuar al próximo mes", message, [
        { text: "Cancelar", style: "cancel" },
        { text: "Aceptar", onPress: run },
      ]);
    }
  };

  // 👉 Restablecer: volver al mes real y borrar simulación
  const handleResetMonth = () => {
    setMonthOffset(0);
    setIncomes(currentMonthIncomes);
    setExpenses(currentMonthExpenses);
    setSimSnapshots({}); // limpiamos snapshots en memoria

    if (isWeb) {
      try {
        window.sessionStorage.removeItem(SIM_MAX_OFFSET_KEY);
        window.sessionStorage.removeItem(SIM_STATE_KEY);
      } catch {
        /* ignore */
      }
    } else {
      AsyncStorage.removeItem(SIM_MAX_OFFSET_KEY).catch(() => {});
      AsyncStorage.removeItem(SIM_STATE_KEY).catch(() => {});
    }
  };

  if (loading) {
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
        <ActivityIndicator size="large" color={PURPLE} />
        <Text style={{ marginTop: 10, color: "#555" }}>Cargando…</Text>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: "#fff" }}>
      {/* Header morado */}
      <View
        style={{
          backgroundColor: PURPLE,
          paddingTop: insets.top + 10,
          paddingHorizontal: 16,
          paddingBottom: 18,
          borderBottomLeftRadius: 12,
          borderBottomRightRadius: 12,
          shadowColor: "#000",
          shadowOpacity: 0.15,
          shadowRadius: 8,
          elevation: 2,
        }}
      >
        <View style={{ flexDirection: "row", alignItems: "center" }}>
          <TouchableOpacity
            onPress={() => router.back()}
            hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
            style={{
              padding: 4,
              borderRadius: 999,
              backgroundColor: "rgba(255,255,255,0.1)",
            }}
          >
            <ArrowLeft color="#fff" size={22} />
          </TouchableOpacity>
          <Text style={{ color: "#fff", fontSize: 25, fontWeight: "700", marginLeft: 12 }}>
            Gestionar presupuesto
          </Text>
        </View>
      </View>

      {/* Banner de mes simulado */}
      {monthOffset !== 0 && (
        <View
          style={{
            marginTop: 12,
            marginHorizontal: 16,
            paddingHorizontal: 12,
            paddingVertical: 10,
            backgroundColor: "#F3F4F6",
            borderRadius: 12,
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <Text style={{ color: "#111827", flex: 1, marginRight: 8 }}>
            Estás viendo el mes: <Text style={{ fontWeight: "700" }}>{monthName}</Text>
          </Text>
          <TouchableOpacity onPress={handleResetMonth}>
            <Text style={{ color: PURPLE, fontWeight: "600" }}>Restablecer</Text>
          </TouchableOpacity>
        </View>
      )}

      {error ? (
        <View style={{ padding: 16 }}>
          <Text style={{ color: "#b91c1c" }}>{error}</Text>
        </View>
      ) : (
        <ScrollView
          contentContainerStyle={{
            paddingBottom: (insets.bottom || 0) + 110,
          }}
        >
          {/* Totales */}
          <View style={{ paddingVertical: 18, alignItems: "center" }}>
            <Text style={{ color: "#444", marginBottom: 4 }}>Mi presupuesto</Text>
            <Text style={{ fontSize: 28, fontWeight: "800" }}>{currency(totalIncome)}</Text>

            <Text style={{ color: "#444", marginTop: 10 }}>Mis gastos</Text>
            <Text style={{ fontSize: 28, fontWeight: "800" }}>{currency(totalExpenses)}</Text>

            {/* DINERO DISPONIBLE ACUMULADO */}
            <Text style={{ color: "#444", marginTop: 10 }}>Dinero disponible</Text>
            <Text style={{ fontSize: 28, fontWeight: "800", color: "#16a34a" }}>
              {currency(cumulativeAvailable)}
            </Text>
          </View>

          {/* Ingresos */}
          <View
            style={{
              borderTopWidth: 6,
              borderTopColor: "#F2F2F2",
              borderBottomWidth: 1,
              borderBottomColor: GRAY_BORDER,
              paddingHorizontal: 16,
              paddingVertical: 12,
            }}
          >
            <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 8 }}>
              <Text style={{ color: PURPLE, fontSize: 20, fontWeight: "700", flex: 1 }}>
                Ingresos
              </Text>
              <TouchableOpacity onPress={() => openAddModal("income")}>
                <Plus color={PURPLE} size={22} />
              </TouchableOpacity>
            </View>

            {incomes.map((i) => (
              <View
                key={i.id}
                style={{
                  flexDirection: "row",
                  justifyContent: "space-between",
                  paddingVertical: 10,
                  alignItems: "center",
                }}
              >
                <View>
                  <Text style={{ color: "#333", fontSize: 16 }}>{i.name}</Text>
                  {i.isFixed && (
                    <Text style={{ color: "#16a34a", fontSize: 12 }}>Ingreso fijo</Text>
                  )}
                </View>
                <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
                  <Text style={{ color: "#111", fontSize: 22, fontWeight: "700" }}>
                    {currency(i.amount)}
                  </Text>
                  <TouchableOpacity
                    onPress={(ev: any) => {
                      if (isWeb) {
                        const rect = ev?.target?.getBoundingClientRect?.();
                        setMenu({
                          type: "income",
                          id: i.id,
                          x: rect ? rect.left : 0,
                          y: rect ? rect.bottom : 0,
                        });
                      } else {
                        Alert.alert("Opciones", i.name, [
                          { text: "Editar", onPress: () => openEditModal("income", i) },
                          {
                            text: "Eliminar",
                            style: "destructive",
                            onPress: () => confirmDelete("income", i.id, i.name),
                          },
                          { text: "Cancelar", style: "cancel" },
                        ]);
                      }
                    }}
                    hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                  >
                    <MoreHorizontal size={20} color="#444" />
                  </TouchableOpacity>
                </View>
              </View>
            ))}
          </View>

          {/* Gastos */}
          <View
            style={{
              borderTopWidth: 6,
              borderTopColor: "#F2F2F2",
              paddingHorizontal: 16,
              paddingVertical: 12,
            }}
          >
            <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 8 }}>
              <Text style={{ color: PURPLE, fontSize: 20, fontWeight: "700", flex: 1 }}>
                Gastos
              </Text>
              <TouchableOpacity onPress={() => openAddModal("expense")}>
                <Plus color={PURPLE} size={22} />
              </TouchableOpacity>
            </View>

            {expenses.map((g) => {
              const hasInstallments = (g.installmentsTotal ?? 0) > 0;
              const remaining =
                g.installmentsRemaining ??
                (hasInstallments ? g.installmentsTotal ?? 0 : 0);

              return (
                <View
                  key={g.id}
                  style={{
                    flexDirection: "row",
                    justifyContent: "space-between",
                    paddingVertical: 12,
                    borderBottomWidth: 1,
                    borderBottomColor: GRAY_BORDER,
                    alignItems: "center",
                  }}
                >
                  <View>
                    <Text style={{ color: "#333", fontSize: 16 }}>{g.name}</Text>
                    <Text style={{ color: "#777", fontSize: 12 }}>
                      Gasto mensual el día {String(g.day).padStart(2, "0")}
                    </Text>
                    {g.isFixed && (
                      <Text style={{ color: "#16a34a", fontSize: 12 }}>Gasto fijo</Text>
                    )}
                    {hasInstallments && remaining && remaining > 0 && (
                      <Text style={{ color: "#16a34a", fontSize: 12 }}>
                        Cuotas restantes: {remaining}
                      </Text>
                    )}
                  </View>
                  <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
                    <Text style={{ color: "#111", fontSize: 22, fontWeight: "700" }}>
                      {currency(g.amount)}
                    </Text>
                    <TouchableOpacity
                      onPress={(ev: any) => {
                        if (isWeb) {
                          const rect = ev?.target?.getBoundingClientRect?.();
                          setMenu({
                            type: "expense",
                            id: g.id,
                            x: rect ? rect.left : 0,
                            y: rect ? rect.bottom : 0,
                          });
                        } else {
                          Alert.alert("Opciones", g.name, [
                            { text: "Editar", onPress: () => openEditModal("expense", g) },
                            {
                              text: "Eliminar",
                              style: "destructive",
                              onPress: () => confirmDelete("expense", g.id, g.name),
                            },
                            { text: "Cancelar", style: "cancel" },
                          ]);
                        }
                      }}
                      hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                    >
                      <MoreHorizontal size={20} color="#444" />
                    </TouchableOpacity>
                  </View>
                </View>
              );
            })}

            {/* Botón continuar próximo mes */}
            <TouchableOpacity
              onPress={handleContinueBudgetNextMonth}
              style={{
                marginTop: 16,
                paddingVertical: 12,
                borderRadius: 12,
                backgroundColor: PURPLE,
                alignItems: "center",
              }}
            >
              <Text style={{ color: "#fff", fontWeight: "700" }}>
                Continuar mi presupuesto en el próximo mes
              </Text>
            </TouchableOpacity>
          </View>

          {/* Ayuda flotante */}
          <View
            style={{
              alignItems: "center",
              justifyContent: "center",
              marginTop: 16,
            }}
          >
            <AnimatedTouchableOpacity
              style={{
                width: 42,
                height: 42,
                borderRadius: 21,
                backgroundColor: PURPLE,
                alignItems: "center",
                justifyContent: "center",
                shadowColor: "#000",
                shadowOffset: { width: 0, height: 2 },
                shadowOpacity: 0.25,
                shadowRadius: 4,
                elevation: 4,
                transform: [{ scale: bounceAnim }],
              }}
              onPress={() => setHelpVisible(true)}
              activeOpacity={0.85}
            >
              <Text
                style={{
                  color: "#fff",
                  fontWeight: "bold",
                  fontSize: 22,
                  marginTop: -2,
                }}
              >
                ?
              </Text>
            </AnimatedTouchableOpacity>
            <Text
              style={{
                marginTop: 4,
                fontSize: 12,
                color: "#6b7280",
              }}
            >
              ¿Necesitas ayuda?
            </Text>
          </View>
        </ScrollView>
      )}

      {/* Menú contextual web */}
      {isWeb && menu && (
        <>
          <View
            style={{
              position: "fixed" as any,
              inset: 0,
              backgroundColor: "transparent",
              zIndex: 9998,
            }}
            onStartShouldSetResponder={() => true}
            onResponderRelease={() => setMenu(null)}
          />

          <View
            style={{
              position: "fixed" as any,
              left: menu.x - 140,
              top: menu.y + 6,
              zIndex: 9999,
              backgroundColor: "#fff",
              borderWidth: 1,
              borderColor: "#e5e7eb",
              borderRadius: 12,
              boxShadow: "0 8px 24px rgba(0,0,0,0.12)" as any,
            }}
            onStartShouldSetResponder={() => true}
          >
            <TouchableOpacity
              style={{ padding: 12, minWidth: 140 }}
              onPress={() => {
                const list = menu.type === "income" ? incomes : expenses;
                const found = list.find((x) => x.id === menu.id);
                if (found) openEditModal(menu.type, found as any);
                setMenu(null);
              }}
            >
              <Text>Editar</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={{ padding: 12 }}
              onPress={() => {
                const list = menu.type === "income" ? incomes : expenses;
                const found = list.find((x) => x.id === menu.id);
                if (found) confirmDelete(menu.type, menu.id, found.name);
                setMenu(null);
              }}
            >
              <Text style={{ color: "#b91c1c" }}>Eliminar</Text>
            </TouchableOpacity>

            <TouchableOpacity style={{ padding: 12 }} onPress={() => setMenu(null)}>
              <Text>Cancelar</Text>
            </TouchableOpacity>
          </View>
        </>
      )}

      <BottomNav />

      <BudgetModal
        visible={modalState.visible}
        onClose={closeModal}
        type={modalState.type}
        editingItem={modalState.editingItem}
        onSubmit={handleModalSubmit}
      />

      {/* Modal de ayuda */}
      <Modal
        visible={helpVisible}
        transparent
        animationType="fade"
        onRequestClose={() => setHelpVisible(false)}
      >
        <View
          style={{
            flex: 1,
            backgroundColor: "rgba(15,23,42,0.55)",
            alignItems: "center",
            justifyContent: "center",
            padding: 24,
          }}
        >
          <View
            style={{
              width: "100%",
              maxWidth: 420,
              backgroundColor: "#ffffff",
              borderRadius: 18,
              paddingVertical: 24,
              paddingHorizontal: 20,
              alignItems: "center",
            }}
          >
            <View
              style={{
                width: 56,
                height: 56,
                borderRadius: 28,
                backgroundColor: PURPLE,
                alignItems: "center",
                justifyContent: "center",
                marginBottom: 12,
              }}
            >
              <Text
                style={{
                  color: "white",
                  fontSize: 28,
                  fontWeight: "bold",
                  marginTop: -3,
                }}
              >
                ?
              </Text>
            </View>
            <Text
              style={{
                fontSize: 18,
                fontWeight: "700",
                color: "#111827",
                marginBottom: 8,
                textAlign: "center",
              }}
            >
              Guía rápida
            </Text>
            <Text
              style={{
                fontSize: 14,
                color: "#4b5563",
                textAlign: "center",
                lineHeight: 20,
              }}
            >
              Este es tu presupuesto, aquí podrás añadir tus ingresos y gastos, puedes decir si
              son fijos o no y si tus gastos tienen cuotas. Puedes transferir tu presupuesto para
              el otro mes si deseas.
            </Text>
            <TouchableOpacity
              style={{
                marginTop: 22,
                backgroundColor: PURPLE,
                paddingVertical: 10,
                paddingHorizontal: 26,
                borderRadius: 999,
              }}
              onPress={() => setHelpVisible(false)}
            >
              <Text
                style={{
                  color: "white",
                  fontWeight: "600",
                  fontSize: 14,
                }}
              >
                Entendido
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

/* ======== Estilos ======== */
const styles = StyleSheet.create({
  input: {
    borderBottomWidth: 1,
    borderBottomColor: GRAY_BORDER,
    paddingVertical: 10,
    fontSize: 16,
    color: "#111827",
  },
  modalBackdrop: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.4)",
    justifyContent: "flex-end",
  },
  modalCard: {
    backgroundColor: "#fff",
    padding: 16,
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
  },
  modalTitle: { fontSize: 18, fontWeight: "700", marginBottom: 10 },
  label: { color: PURPLE, fontWeight: "700" },
  modalActions: { flexDirection: "row", justifyContent: "flex-end", gap: 12, marginTop: 16 },
  accessoryBar: {
    backgroundColor: "#F6F6F8",
    borderTopWidth: StyleSheet.hairlineWidth,
    borderColor: "#D1D5DB",
    paddingHorizontal: 12,
    paddingVertical: 8,
    flexDirection: "row",
    alignItems: "center",
  },
  accessoryBtn: { color: PURPLE, fontWeight: "700", fontSize: 16 },

  fixedRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 12,
    gap: 8,
  },
  fixedLabel: {
    fontSize: 14,
    color: "#374151",
  },
});
