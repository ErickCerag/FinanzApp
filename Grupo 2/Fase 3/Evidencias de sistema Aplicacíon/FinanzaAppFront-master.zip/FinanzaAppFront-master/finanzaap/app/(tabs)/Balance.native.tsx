// app/(tabs)/Balance.native.tsx
import React, {
  useEffect,
  useMemo,
  useState,
  useCallback,
} from "react";
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Alert,
  Modal,
  Animated,
  Easing,
} from "react-native";
import { useRouter, useFocusEffect } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  ArrowLeft,
  Filter,
  FileDown,
  FileSpreadsheet,
  TrendingUp,
  PieChart,
  BarChart3,
} from "lucide-react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as FileSystem from "expo-file-system";
import * as LegacyFileSystem from "expo-file-system/legacy";
import * as Sharing from "expo-sharing";
import * as Print from "expo-print";

import BottomNav from "@/components/BarraNav";
import { obtenerSesion } from "@/Service/user/user.service";
import { obtenerWishlistConItems } from "@/Service/wishList/wishlist.service";
import {
  fetchIncomes,
  fetchExpenses,
  type Income,
  type Expense,
} from "@/Service/budget/budget.service";

const PURPLE = "#6B21A8";
const GREEN = "#15803d";
const GRAY_BORDER = "#e5e7eb";

const currency = (v: number) =>
  new Intl.NumberFormat("es-CL", {
    style: "currency",
    currency: "CLP",
    maximumFractionDigits: 0,
  }).format(v);

type Goal = { name: string; progress: number };

type FilterKey =
  | "all"
  | "incomes"
  | "incomesFixed"
  | "expenses"
  | "expensesFixed";

const FILTER_KEY = "balance_filter_native_v1";

// mismas claves que en Presupuesto.tsx
const SIM_MAX_OFFSET_KEY = "finanzapp_max_month_offset_v1";
const SIM_STATE_KEY = "finanzapp_sim_months_state_v1";

// nombre de meses en español (para historial)
const MONTH_NAMES_ES = [
  "Enero",
  "Febrero",
  "Marzo",
  "Abril",
  "Mayo",
  "Junio",
  "Julio",
  "Agosto",
  "Septiembre",
  "Octubre",
  "Noviembre",
  "Diciembre",
];

// misma estructura de filas que en web
type Row = {
  id: string;
  name: string;
  amount: number;
  kind: "income" | "expense";
  isFixed: boolean;
  hasInstallments?: boolean;
};

type SimMonthState = {
  incomes: Income[];
  expenses: Expense[];
};

const AnimatedTouchableOpacity =
  Animated.createAnimatedComponent(TouchableOpacity);

export default function BalanceScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [incomes, setIncomes] = useState<Income[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [goals, setGoals] = useState<Goal[]>([]);

  const [filter, setFilter] = useState<FilterKey>("all");

  const [filters] = useState({
    month: new Date().getMonth() + 1,
    year: new Date().getFullYear(),
  });

  // hasta qué mes adicional llegó la simulación
  const [maxMonthOffset, setMaxMonthOffset] = useState(0);

  // estado de cada mes simulado (offset → incomes/expenses)
  const [simMonths, setSimMonths] = useState<Record<number, SimMonthState>>(
    {}
  );

  // === estado para historial ===
  // null = vista normal (top movimientos del mes actual)
  // 0..N = ver historial de ese offset (incluye el mes actual si eliges 0)
  const [selectedHistoryOffset, setSelectedHistoryOffset] = useState<
    number | null
  >(null);
  const [historyModalVisible, setHistoryModalVisible] = useState(false);

  // === ayuda ===
  const [helpVisible, setHelpVisible] = useState(false);
  const bounceAnim = React.useRef(new Animated.Value(1)).current;

  useEffect(() => {
    const loopBounce = () => {
      Animated.sequence([
        Animated.timing(bounceAnim, {
          toValue: 1.08,
          duration: 450,
          easing: Easing.out(Easing.quad),
          useNativeDriver: true,
        }),
        Animated.timing(bounceAnim, {
          toValue: 1,
          duration: 450,
          easing: Easing.in(Easing.quad),
          useNativeDriver: true,
        }),
      ]).start(({ finished }) => {
        if (finished) {
          setTimeout(loopBounce, 2000);
        }
      });
    };

    loopBounce();
  }, [bounceAnim]);

  // opciones de meses disponibles para historial (desde actual hasta último simulado)
  const historyOptions = useMemo(() => {
    const opts: { offset: number; label: string }[] = [];
    const now = new Date();
    const lastOffset = Math.max(0, maxMonthOffset);

    for (let offset = 0; offset <= lastOffset; offset++) {
      const d = new Date(now.getFullYear(), now.getMonth() + offset, 1);
      const label = `${MONTH_NAMES_ES[d.getMonth()]} ${d.getFullYear()}`;
      opts.push({ offset, label });
    }
    return opts;
  }, [maxMonthOffset]);

  // etiqueta que se muestra en el botón blanco del header
  const historyButtonLabel = useMemo(() => {
    if (selectedHistoryOffset === null) return "Seleccionar mes";

    const now = new Date();
    const d = new Date(
      now.getFullYear(),
      now.getMonth() + selectedHistoryOffset,
      1
    );
    return `${MONTH_NAMES_ES[d.getMonth()]} ${d.getFullYear()}`;
  }, [selectedHistoryOffset]);

  // === Cargar filtro guardado (UX) ===
  useEffect(() => {
    (async () => {
      try {
        const saved = await AsyncStorage.getItem(FILTER_KEY);
        if (
          saved === "all" ||
          saved === "incomes" ||
          saved === "incomesFixed" ||
          saved === "expenses" ||
          saved === "expensesFixed"
        ) {
          setFilter(saved);
        }
      } catch {
        /* ignore */
      }
    })();
  }, []);

  const saveFilter = useCallback(async (value: FilterKey) => {
    setFilter(value);
    try {
      await AsyncStorage.setItem(FILTER_KEY, value);
    } catch {
      /* ignore */
    }
  }, []);

  // === Sincronizar simulación desde AsyncStorage (equivalente a sessionStorage en web) ===
  const syncSimStateFromStorage = useCallback(async () => {
    try {
      const rawMax = await AsyncStorage.getItem(SIM_MAX_OFFSET_KEY);
      const n = rawMax ? parseInt(rawMax, 10) : 0;
      if (!Number.isNaN(n) && n > 0) setMaxMonthOffset(n);
      else setMaxMonthOffset(0);
    } catch {
      /* ignore */
    }

    try {
      const rawState = await AsyncStorage.getItem(SIM_STATE_KEY);
      if (rawState) {
        const parsed = JSON.parse(rawState) as Record<
          string,
          { incomes: Income[]; expenses: Expense[] }
        >;
        const normalized: Record<number, SimMonthState> = {};
        Object.keys(parsed).forEach((k) => {
          const num = parseInt(k, 10);
          if (!Number.isNaN(num)) {
            normalized[num] = parsed[k as any] as SimMonthState;
          }
        });
        setSimMonths(normalized);
      } else {
        setSimMonths({});
      }
    } catch {
      /* ignore */
    }
  }, []);

  // si al limpiar la simulación el offset seleccionado ya no existe,
  // volvemos automáticamente al mes actual
  useEffect(() => {
    if (
      selectedHistoryOffset !== null &&
      selectedHistoryOffset > maxMonthOffset
    ) {
      setSelectedHistoryOffset(null);
    }
  }, [maxMonthOffset, selectedHistoryOffset]);

  // === Cargar datos ===
  const loadData = useCallback(async () => {
    let cancel = false;
    setLoading(true);
    try {
      const [ins, exps] = await Promise.all([fetchIncomes(), fetchExpenses()]);
      if (cancel) return;
      setIncomes(ins);
      setExpenses(exps);

      const u = await obtenerSesion();
      const uid = u?.id_usuario ?? null;
      if (!uid) {
        setGoals([]);
      } else {
        const { items } = await obtenerWishlistConItems(uid);
        if (cancel) return;

        const mapped: Goal[] = items.map((it: any) => {
          const total = Number(it.Monto || 0);
          const saved = Number(it.Ahorrado || 0);
          const completed = (it.Completado ?? 0) === 1;

          let progress = 0;
          if (total > 0) {
            progress = Math.round(
              Math.min(100, (Math.max(saved, 0) / total) * 100)
            );
          }
          if (completed) progress = 100;
          return { name: it.Nombre, progress };
        });

        setGoals(mapped);
      }

      setError(null);
    } catch (err) {
      console.error(err);
      setError("No se pudieron cargar los datos.");
    } finally {
      if (!cancel) setLoading(false);
    }

    return () => {
      cancel = true;
    };
  }, []);

  // Recargar cuando la pantalla gana foco
  useFocusEffect(
    useCallback(() => {
      let active = true;
      (async () => {
        if (!active) return;
        await syncSimStateFromStorage();
        await loadData();
      })();
      return () => {
        active = false;
      };
    }, [loadData, syncSimStateFromStorage])
  );

  // === Helper: construir filas para un mes (offset) – igual que en web ===
  const buildRowsForOffset = useCallback(
    (offset: number): { month: number; year: number; rows: Row[] } => {
      const now = new Date();
      const d = new Date(now.getFullYear(), now.getMonth() + offset, 1);
      const month = d.getMonth() + 1;
      const year = d.getFullYear();

      // 1) Base: datos reales del backend
      let baseIncomes: Income[] = incomes;
      let baseExpenses: Expense[] = expenses;

      // 2) Si hay snapshot de Presupuesto para este offset, lo usamos (incluye cuotas)
      const sim = simMonths[offset];
      if (sim) {
        baseIncomes = sim.incomes as Income[];
        baseExpenses = sim.expenses as Expense[];
      } else if (offset > 0) {
        // 3) Fallback: mes simulado sin snapshot → sólo fijos
        baseIncomes = baseIncomes.filter((i) => i.isFixed);
        baseExpenses = baseExpenses.filter((e) => e.isFixed);
      }

      const incomeRows: Row[] = baseIncomes.map((i) => ({
        id: `inc-${offset}-${i.id}`,
        name: i.name,
        amount: i.amount,
        kind: "income",
        isFixed: !!i.isFixed,
        hasInstallments: false,
      }));

      const expenseRows: Row[] = baseExpenses.map((e: any) => {
        const total = Number(e.installmentsTotal ?? 0);
        const remaining =
          e.installmentsRemaining ?? (total > 0 ? total : 0);
        const hasInstallments = total > 0 && remaining > 0;

        return {
          id: `exp-${offset}-${e.id}`,
          name: e.name,
          amount: e.amount,
          kind: "expense" as const,
          isFixed: !!e.isFixed,
          hasInstallments,
        };
      });

      let rows: Row[];
      switch (filter) {
        case "incomes":
          rows = incomeRows.filter((r) => !r.isFixed);
          break;
        case "incomesFixed":
          rows = incomeRows.filter((r) => r.isFixed);
          break;
        case "expenses":
          rows = expenseRows.filter((r) => !r.isFixed);
          break;
        case "expensesFixed":
          rows = expenseRows.filter((r) => r.isFixed);
          break;
        default:
          rows = [...incomeRows, ...expenseRows];
          break;
      }

      // ⬇️ ordenar siempre de mayor a menor monto
      rows.sort((a, b) => b.amount - a.amount);

      return { month, year, rows };
    },
    [incomes, expenses, filter, simMonths]
  );

  // 🔹 Helper: totales de ingresos/gastos y dinero disponible por offset (solo ese mes)
  const getTotalsForOffset = useCallback(
    (offset: number) => {
      // misma lógica base que buildRowsForOffset, pero sin filtros
      let baseIncomes: Income[] = incomes;
      let baseExpenses: Expense[] = expenses;

      const sim = simMonths[offset];
      if (sim) {
        baseIncomes = sim.incomes as Income[];
        baseExpenses = sim.expenses as Expense[];
      } else if (offset > 0) {
        baseIncomes = baseIncomes.filter((i) => i.isFixed);
        baseExpenses = baseExpenses.filter((e) => e.isFixed);
      }

      const totalIncomes = baseIncomes.reduce(
        (acc, cur) => acc + (cur.amount ?? 0),
        0
      );
      const totalExpenses = baseExpenses.reduce(
        (acc, cur) => acc + (cur.amount ?? 0),
        0
      );

      return {
        totalIncomes,
        totalExpenses,
        available: totalIncomes - totalExpenses,
      };
    },
    [incomes, expenses, simMonths]
  );

  // 🔹 NUEVO: dinero disponible ACUMULADO desde offset 0 hasta el offset dado
  const getCumulativeAvailableUntilOffset = useCallback(
    (offset: number) => {
      let acc = 0;
      for (let off = 0; off <= offset; off++) {
        const { available } = getTotalsForOffset(off);
        acc += available;
      }
      return acc;
    },
    [getTotalsForOffset]
  );

  // Dataset del mes que se muestra en pantalla
  const {
    month: viewingMonth,
    year: viewingYear,
    rows: filteredRows,
  } = useMemo(
    () => buildRowsForOffset(selectedHistoryOffset ?? 0),
    [buildRowsForOffset, selectedHistoryOffset]
  );

  const viewingMonthLabel = useMemo(() => {
    const d = new Date(viewingYear, viewingMonth - 1, 1);
    return `${MONTH_NAMES_ES[d.getMonth()]} ${viewingYear}`;
  }, [viewingMonth, viewingYear]);

  const totalFiltered = useMemo(
    () => filteredRows.reduce((a, b) => a + b.amount, 0),
    [filteredRows]
  );

  // 🔹 Dinero disponible ACUMULADO del mes que se está visualizando
  const availableCurrentMonth = useMemo(
    () =>
      getCumulativeAvailableUntilOffset(
        selectedHistoryOffset ?? 0
      ),
    [getCumulativeAvailableUntilOffset, selectedHistoryOffset]
  );

  // Título dinámico cuando NO hay historial activo
  const filterTitle = useMemo(() => {
    switch (filter) {
      case "incomes":
        return "Top ingresos del mes";
      case "incomesFixed":
        return "Top ingresos fijos del mes";
      case "expenses":
        return "Top gastos del mes";
      case "expensesFixed":
        return "Top gastos fijos del mes";
      default:
        return "Top movimientos del mes";
    }
  }, [filter]);

  const handleFilter = () => {
    Alert.alert("Filtros", `Mes: ${filters.month} / Año: ${filters.year}`);
  };

  // ===== Exportar a PDF (todas las tablas de meses simulados) =====
  const exportPDF = async () => {
    try {
      const lastOffset = Math.max(0, maxMonthOffset);
      let sectionsHtml = "";

      for (let offset = 0; offset <= lastOffset; offset++) {
        const { month, year, rows } = buildRowsForOffset(offset);
        const available = getCumulativeAvailableUntilOffset(offset); // ⬅ acumulado por mes
        const monthStr = String(month).padStart(2, "0");

        const rowsHtml = rows
          .map((r) => {
            const tipo = r.kind === "income" ? "Ingreso" : "Gasto";
            const categoria =
              r.kind === "expense" && r.hasInstallments
                ? "Cuota"
                : r.isFixed
                ? "Fijo"
                : "Variable";
            return `<tr>
              <td>${tipo}</td>
              <td>${categoria}</td>
              <td>${r.name}</td>
              <td style="text-align:right;">${currency(r.amount)}</td>
            </tr>`;
          })
          .join("");

        // Fila extra: Excedente / Dinero disponible
        const excedenteRow = `
          <tr>
            <td>Resumen</td>
            <td>Excedente</td>
            <td>Dinero disponible</td>
            <td style="text-align:right;">${currency(available)}</td>
          </tr>`;

        sectionsHtml += `
          <h1>Balance FinanzApp</h1>
          <h2>Mes ${monthStr} / ${year}</h2>
          <table>
            <thead>
              <tr>
                <th>Tipo</th>
                <th>Categoría</th>
                <th>Nombre</th>
                <th>Monto</th>
              </tr>
            </thead>
            <tbody>
              ${rowsHtml}
              ${excedenteRow}
            </tbody>
          </table>
          <br/><br/>
        `;
      }

      const html = `
        <html>
          <head>
            <meta charset="utf-8" />
            <style>
              body { font-family: -apple-system, BlinkMacSystemFont, sans-serif; padding: 16px; }
              h1 { font-size: 18px; margin-bottom: 4px; }
              h2 { font-size: 14px; margin-top: 0; color: #555; }
              table { width: 100%; border-collapse: collapse; margin-top: 12px; }
              th, td { border: 1px solid #ddd; padding: 6px 8px; font-size: 12px; }
              th { background: #f3f4f6; text-align: left; }
            </style>
          </head>
          <body>
            ${sectionsHtml}
          </body>
        </html>
      `;

      const { uri } = await Print.printToFileAsync({ html });

      const canShare = await Sharing.isAvailableAsync();
      if (canShare) {
        await Sharing.shareAsync(uri, {
          mimeType: "application/pdf",
          dialogTitle: "Compartir balance en PDF",
        });
      } else {
        Alert.alert("PDF generado", `Archivo guardado en:\n${uri}`);
      }
    } catch (e) {
      console.error(e);
      Alert.alert("Error", "No se pudo exportar a PDF.");
    }
  };

  // ===== Exportar a PDF individual (solo un mes del historial) =====
  const exportPDFIndividual = async (offset: number) => {
    try {
      const { month, year, rows } = buildRowsForOffset(offset);
      const available = getCumulativeAvailableUntilOffset(offset); // ⬅ acumulado individual
      const monthName = MONTH_NAMES_ES[month - 1] ?? String(month);
      const monthStr = String(month).padStart(2, "0");

      const rowsHtml = rows
        .map((r) => {
          const tipo = r.kind === "income" ? "Ingreso" : "Gasto";
          const categoria =
            r.kind === "expense" && r.hasInstallments
              ? "Cuota"
              : r.isFixed
              ? "Fijo"
              : "Variable";
          return `<tr>
            <td>${tipo}</td>
            <td>${categoria}</td>
            <td>${r.name}</td>
            <td style="text-align:right;">${currency(r.amount)}</td>
          </tr>`;
        })
        .join("");

      const excedenteRow = `
        <tr>
          <td>Resumen</td>
          <td>Excedente</td>
          <td>Dinero disponible</td>
          <td style="text-align:right;">${currency(available)}</td>
        </tr>`;

      const html = `
        <html>
          <head>
            <meta charset="utf-8" />
            <style>
              body { font-family: -apple-system, BlinkMacSystemFont, sans-serif; padding: 16px; }
              h1 { font-size: 18px; margin-bottom: 4px; }
              h2 { font-size: 14px; margin-top: 0; color: #555; }
              table { width: 100%; border-collapse: collapse; margin-top: 12px; }
              th, td { border: 1px solid #ddd; padding: 6px 8px; font-size: 12px; }
              th { background: #f3f4f6; text-align: left; }
            </style>
          </head>
          <body>
            <h1>Balance individual - ${monthName} ${year}</h1>
            <h2>Mes ${monthStr} / ${year}</h2>
            <table>
              <thead>
                <tr>
                  <th>Tipo</th>
                  <th>Categoría</th>
                  <th>Nombre</th>
                  <th>Monto</th>
                </tr>
              </thead>
              <tbody>
                ${rowsHtml}
                ${excedenteRow}
              </tbody>
            </table>
          </body>
        </html>
      `;

      const { uri } = await Print.printToFileAsync({ html });

      const canShare = await Sharing.isAvailableAsync();
      if (canShare) {
        await Sharing.shareAsync(uri, {
          mimeType: "application/pdf",
          dialogTitle: `Compartir Balance individual - ${monthName}`,
        });
      } else {
        Alert.alert(
          "PDF generado",
          `Balance individual - ${monthName} ${year}\nRuta:\n${uri}`
        );
      }
    } catch (e) {
      console.error(e);
      Alert.alert("Error", "No se pudo exportar el PDF individual.");
    }
  };

  // ===== Exportar a CSV (Excel) — todos los meses simulados =====
  const exportXLSX = async () => {
    try {
      const lastOffset = Math.max(0, maxMonthOffset);

      let csv = "";

      for (let offset = 0; offset <= lastOffset; offset++) {
        const { month, year, rows } = buildRowsForOffset(offset);
        const available = getCumulativeAvailableUntilOffset(offset); // ⬅ acumulado por mes
        const monthStr = String(month).padStart(2, "0");

        csv += `Balance FinanzApp;${monthStr}/${year}\n\n`;
        csv += "Tipo;Categoría;Nombre;Monto\n";

        rows.forEach((r) => {
          const tipo = r.kind === "income" ? "Ingreso" : "Gasto";
          const categoria =
            r.kind === "expense" && r.hasInstallments
              ? "Cuota"
              : r.isFixed
              ? "Fijo"
              : "Variable";
          csv += `${tipo};${categoria};${r.name};${r.amount}\n`;
        });

        // Fila extra de excedente + línea en blanco final
        csv += `Resumen;Excedente;Dinero disponible;${available}\n\n`;
      }

      const now = new Date();
      const baseMonth = String(now.getMonth() + 1).padStart(2, "0");
      const baseYear = now.getFullYear();

      let fileName: string;
      if (lastOffset > 0) {
        // calcular mes final real (igual que en web)
        const endDate = new Date(
          now.getFullYear(),
          now.getMonth() + lastOffset,
          1
        );
        const endMonthStr = String(endDate.getMonth() + 1).padStart(2, "0");
        fileName = `balance-${baseYear}-${baseMonth}-${endMonthStr}.csv`;
      } else {
        fileName = `balance-${baseYear}-${baseMonth}.csv`;
      }

      const legacyAny = LegacyFileSystem as any;
      const baseDir: string =
        legacyAny.documentDirectory ??
        legacyAny.cacheDirectory ??
        legacyAny.temporaryDirectory ??
        (FileSystem as any).documentDirectory ??
        (FileSystem as any).cacheDirectory ??
        (FileSystem as any).temporaryDirectory ??
        "";

      if (!baseDir || baseDir === "/") {
        Alert.alert(
          "Error",
          "No se encontró un directorio válido para guardar el archivo."
        );
        return;
      }

      const fileUri = baseDir + fileName;

      await legacyAny.writeAsStringAsync(fileUri, csv);

      const canShare = await Sharing.isAvailableAsync();
      if (canShare) {
        await Sharing.shareAsync(fileUri, {
          mimeType: "text/csv",
          dialogTitle: "Compartir reporte Excel",
          UTI: "public.comma-separated-values-text",
        });
      } else {
        Alert.alert("Archivo generado", `Ruta:\n${fileUri}`);
      }
    } catch (e) {
      console.error(e);
      Alert.alert("Error", "No se pudo exportar a Excel.");
    }
  };

  // ===== Exportar a CSV (Excel) individual — solo un mes =====
  const exportXLSXIndividual = async (offset: number) => {
    try {
      const { month, year, rows } = buildRowsForOffset(offset);
      const available = getCumulativeAvailableUntilOffset(offset); // ⬅ acumulado individual
      const monthName = MONTH_NAMES_ES[month - 1] ?? String(month);

      let csv = "";
      csv += `Balance individual - ${monthName} ${year}\n\n`;
      csv += "Tipo;Categoría;Nombre;Monto\n";

      rows.forEach((r) => {
        const tipo = r.kind === "income" ? "Ingreso" : "Gasto";
        const categoria =
          r.kind === "expense" && r.hasInstallments
            ? "Cuota"
            : r.isFixed
            ? "Fijo"
            : "Variable";
        csv += `${tipo};${categoria};${r.name};${r.amount}\n`;
      });

      // Fila de excedente (Dinero disponible)
      csv += `Resumen;Excedente;Dinero disponible;${available}\n`;

      const fileName = `Balance individual - ${monthName} ${year}.csv`;

      const legacyAny = LegacyFileSystem as any;
      const baseDir: string =
        legacyAny.documentDirectory ??
        legacyAny.cacheDirectory ??
        legacyAny.temporaryDirectory ??
        (FileSystem as any).documentDirectory ??
        (FileSystem as any).cacheDirectory ??
        (FileSystem as any).temporaryDirectory ??
        "";

      if (!baseDir || baseDir === "/") {
        Alert.alert(
          "Error",
          "No se encontró un directorio válido para guardar el archivo."
        );
        return;
      }

      const fileUri = baseDir + fileName;

      await legacyAny.writeAsStringAsync(fileUri, csv);

      const canShare = await Sharing.isAvailableAsync();
      if (canShare) {
        await Sharing.shareAsync(fileUri, {
          mimeType: "text/csv",
          dialogTitle: `Compartir Balance individual - ${monthName}`,
          UTI: "public.comma-separated-values-text",
        });
      } else {
        Alert.alert(
          "Archivo generado",
          `Balance individual - ${monthName} ${year}\nRuta:\n${fileUri}`
        );
      }
    } catch (e) {
      console.error(e);
      Alert.alert("Error", "No se pudo exportar el Excel individual.");
    }
  };

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: "#fff" }}>
        <View
          style={{
            flex: 1,
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <ActivityIndicator size="large" color={PURPLE} />
          <Text style={{ marginTop: 10, color: "#555" }}>
            Cargando datos…
          </Text>
        </View>
        <BottomNav active="balance" />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: "#fff" }}>
      {/* HEADER */}
      <View
        style={{
          backgroundColor: PURPLE,
          paddingTop: insets.top + 10,
          paddingHorizontal: 16,
          paddingBottom: 18,
          borderBottomLeftRadius: 12,
          borderBottomRightRadius: 12,
          shadowColor: "#000",
          shadowOpacity: 0.15,
          shadowRadius: 8,
          elevation: 2,
        }}
      >
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
          }}
        >
          <TouchableOpacity
            onPress={() => router.back()}
            hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
            style={{
              padding: 4,
              borderRadius: 999,
              backgroundColor: "rgba(255,255,255,0.1)",
            }}
          >
            <ArrowLeft color="#fff" size={26} />
          </TouchableOpacity>

          <Text
            style={{
              color: "#fff",
              fontSize: 22,
              fontWeight: "700",
              marginLeft: 12,
            }}
          >
            Balance
          </Text>

          {/* Botón historial de meses (a la derecha, estilo pill blanco) */}
          <View style={{ flex: 1, alignItems: "flex-end" }}>
            <TouchableOpacity
              onPress={() => setHistoryModalVisible(true)}
              style={{
                paddingHorizontal: 10,
                paddingVertical: 4,
                backgroundColor: "#fff",
                borderRadius: 8,
              }}
            >
              <Text
                style={{
                  fontSize: 12,
                  color: PURPLE,
                  fontWeight: "600",
                }}
              >
                {historyButtonLabel}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>

      {error ? (
        <View style={{ padding: 16 }}>
          <Text style={{ color: "#b91c1c" }}>{error}</Text>
        </View>
      ) : (
        <ScrollView
          contentContainerStyle={{ padding: 16, paddingBottom: 80 }}
        >
          {/* Filtros */}
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              marginBottom: 12,
            }}
          >
            {(
              [
                ["Todo", "all"],
                ["Ingresos", "incomes"],
                ["Ingresos fijos", "incomesFixed"],
                ["Gastos", "expenses"],
                ["Gastos fijos", "expensesFixed"],
              ] as const
            ).map(([label, key]) => {
              const active = filter === key;
              return (
                <TouchableOpacity
                  key={key}
                  onPress={() => saveFilter(key as FilterKey)}
                >
                  <Text
                    style={{
                      fontSize: 14,
                      fontWeight: active ? "700" : "400",
                      color: active ? PURPLE : "#111",
                    }}
                  >
                    {label}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>

          {/* Top movimientos del mes / Historial */}
          <View
            style={{
              backgroundColor: "#fff",
              borderRadius: 12,
              borderWidth: 1,
              borderColor: GRAY_BORDER,
              padding: 14,
              marginBottom: 16,
            }}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginBottom: 8,
              }}
            >
              <Text
                style={{
                  color: PURPLE,
                  fontSize: 18,
                  fontWeight: "700",
                  flex: 1,
                }}
              >
                {selectedHistoryOffset === null
                  ? filterTitle
                  : `Estás viendo el mes: ${viewingMonthLabel}`}
              </Text>

              {/* Botón Filtrar oculto a nivel de código (por ahora no se usa) */}
              {false && (
                <TouchableOpacity
                  onPress={handleFilter}
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    gap: 6,
                  }}
                >
                  <Text style={{ color: "#555", fontWeight: "600" }}>
                    Filtrar
                  </Text>
                  <Filter size={18} color="#111" />
                </TouchableOpacity>
              )}
            </View>

            <View style={{ gap: 6 }}>
              {filteredRows.map((e) => (
                <View
                  key={e.id}
                  style={{
                    flexDirection: "row",
                    justifyContent: "space-between",
                  }}
                >
                  <Text style={{ color: "#111", fontSize: 16 }}>
                    {e.name}
                  </Text>

                  <Text
                    style={{
                      color: "#111",
                      fontSize: 16,
                      fontWeight: "600",
                    }}
                  >
                    {e.kind === "expense"
                      ? `-${currency(e.amount)}`
                      : currency(e.amount)}
                  </Text>
                </View>
              ))}
            </View>

            {/* 🔹 Dinero disponible (después del último movimiento) */}
            <View
              style={{
                marginTop: filteredRows.length ? 10 : 6,
                flexDirection: "row",
                justifyContent: "space-between",
              }}
            >
              <Text
                style={{
                  color: "#555",
                  fontWeight: "600",
                }}
              >
                Dinero disponible
              </Text>
              <Text
                style={{
                  color: GREEN,
                  fontWeight: "700",
                  fontSize: 16,
                }}
              >
                {currency(availableCurrentMonth)}
              </Text>
            </View>

            {/* Exportar datos */}
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginTop: 12,
                gap: 12,
              }}
            >
              <Text
                style={{
                  color: PURPLE,
                  fontWeight: "600",
                }}
              >
                Exportar datos :
              </Text>
              <TouchableOpacity
                onPress={() =>
                  selectedHistoryOffset === null
                    ? exportPDF()
                    : exportPDFIndividual(selectedHistoryOffset)
                }
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  gap: 6,
                  paddingVertical: 6,
                  paddingHorizontal: 10,
                  borderWidth: 1,
                  borderColor: GRAY_BORDER,
                  borderRadius: 8,
                }}
              >
                <FileDown size={18} color="#b91c1c" />
                <Text
                  style={{
                    color: "#b91c1c",
                    fontWeight: "700",
                  }}
                >
                  PDF
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() =>
                  selectedHistoryOffset === null
                    ? exportXLSX()
                    : exportXLSXIndividual(selectedHistoryOffset)
                }
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  gap: 6,
                  paddingVertical: 6,
                  paddingHorizontal: 10,
                  borderWidth: 1,
                  borderColor: GRAY_BORDER,
                  borderRadius: 8,
                }}
              >
                <FileSpreadsheet size={18} color="#065f46" />
                <Text
                  style={{
                    color: "#065f46",
                    fontWeight: "700",
                  }}
                >
                  EXCEL
                </Text>
              </TouchableOpacity>
            </View>

            {/* Total: solo cuando el filtro NO es "Todo" */}
            {filter !== "all" && (
              <View
                style={{
                  marginTop: 10,
                  borderTopWidth: 1,
                  borderTopColor: GRAY_BORDER,
                  paddingTop: 8,
                }}
              >
                <View
                  style={{
                    flexDirection: "row",
                    justifyContent: "space-between",
                  }}
                >
                  <Text style={{ color: "#555" }}>Total</Text>
                  <Text style={{ color: "#111", fontWeight: "700" }}>
                    {currency(totalFiltered)}
                  </Text>
                </View>
              </View>
            )}
          </View>

          {/* Progreso de metas */}
          <View
            style={{
              backgroundColor: "#fff",
              borderRadius: 12,
              borderWidth: 1,
              borderColor: GRAY_BORDER,
              padding: 14,
            }}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginBottom: 10,
                gap: 8,
              }}
            >
              <Text
                style={{
                  color: PURPLE,
                  fontSize: 18,
                  fontWeight: "700",
                  flex: 1,
                }}
              >
                Progreso de metas
              </Text>
              <TrendingUp size={18} color="#111" />
              <PieChart size={18} color="#111" />
              <BarChart3 size={18} color="#111" />
            </View>

            <View style={{ gap: 14 }}>
              {goals.map((g) => (
                <View key={g.name}>
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      marginBottom: 6,
                    }}
                  >
                    <Text style={{ color: "#111" }}>{g.name}</Text>
                    <Text style={{ color: "#111", fontWeight: "600" }}>
                      {g.progress} %
                    </Text>
                  </View>
                  <View
                    style={{
                      height: 8,
                      backgroundColor: "#f3f4f6",
                      borderRadius: 999,
                      overflow: "hidden",
                      borderWidth: 1,
                      borderColor: "#e5e7eb",
                    }}
                  >
                    <View
                      style={{
                        width: `${g.progress}%`,
                        height: "100%",
                        backgroundColor:
                          g.progress >= 100 ? GREEN : "#22c55e",
                      }}
                    />
                  </View>
                </View>
              ))}
            </View>
          </View>

          {/* Ayuda flotante */}
          <View
            style={{
              alignItems: "center",
              justifyContent: "center",
              marginTop: 16,
            }}
          >
            <AnimatedTouchableOpacity
              style={{
                width: 42,
                height: 42,
                borderRadius: 21,
                backgroundColor: PURPLE,
                alignItems: "center",
                justifyContent: "center",
                shadowColor: "#000",
                shadowOffset: { width: 0, height: 2 },
                shadowOpacity: 0.25,
                shadowRadius: 4,
                elevation: 4,
                transform: [{ scale: bounceAnim }],
              }}
              onPress={() => setHelpVisible(true)}
              activeOpacity={0.85}
            >
              <Text
                style={{
                  color: "#fff",
                  fontWeight: "bold",
                  fontSize: 22,
                  marginTop: -2,
                }}
              >
                ?
              </Text>
            </AnimatedTouchableOpacity>
            <Text
              style={{
                marginTop: 4,
                fontSize: 12,
                color: "#6b7280",
              }}
            >
              ¿Necesitas ayuda?
            </Text>
          </View>
        </ScrollView>
      )}

      <BottomNav active="balance" />

      {/* Modal de ayuda */}
      <Modal
        visible={helpVisible}
        transparent
        animationType="fade"
        onRequestClose={() => setHelpVisible(false)}
      >
        <View
          style={{
            flex: 1,
            backgroundColor: "rgba(15,23,42,0.55)",
            alignItems: "center",
            justifyContent: "center",
            padding: 24,
          }}
        >
          <View
            style={{
              width: "100%",
              maxWidth: 420,
              backgroundColor: "#ffffff",
              borderRadius: 18,
              paddingVertical: 24,
              paddingHorizontal: 20,
              alignItems: "center",
            }}
          >
            <View
              style={{
                width: 56,
                height: 56,
                borderRadius: 28,
                backgroundColor: PURPLE,
                alignItems: "center",
                justifyContent: "center",
                marginBottom: 12,
              }}
            >
              <Text
                style={{
                  color: "white",
                  fontSize: 28,
                  fontWeight: "bold",
                  marginTop: -3,
                }}
              >
                ?
              </Text>
            </View>
            <Text
              style={{
                fontSize: 18,
                fontWeight: "700",
                color: "#111827",
                marginBottom: 8,
                textAlign: "center",
              }}
            >
              Guía rápida
            </Text>
            <Text
              style={{
                fontSize: 14,
                color: "#4b5563",
                textAlign: "center",
                lineHeight: 20,
              }}
            >
              Este es tu balance, puedes ver tus finanzas filtrando por mes,
              seleccionando un mes en la esquina superior derecha, verás el
              avance en tu wishlist y podrás exportar tu presupuesto en excel y
              pdf.
            </Text>
            <TouchableOpacity
              style={{
                marginTop: 22,
                backgroundColor: PURPLE,
                paddingVertical: 10,
                paddingHorizontal: 26,
                borderRadius: 999,
              }}
              onPress={() => setHelpVisible(false)}
            >
              <Text
                style={{
                  color: "white",
                  fontWeight: "600",
                  fontSize: 14,
                }}
              >
                Entendido
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Modal de selección de mes (historial) */}
      <Modal
        visible={historyModalVisible}
        transparent
        animationType="fade"
        onRequestClose={() => setHistoryModalVisible(false)}
      >
        <View
          style={{
            flex: 1,
            backgroundColor: "rgba(0,0,0,0.4)",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <View
            style={{
              backgroundColor: "#fff",
              borderRadius: 12,
              padding: 16,
              minWidth: "75%",
            }}
          >
            <Text
              style={{
                fontWeight: "700",
                fontSize: 16,
                marginBottom: 8,
                color: "#111",
              }}
            >
              Selecciona un mes
            </Text>

            <TouchableOpacity
              onPress={() => {
                setSelectedHistoryOffset(null);
                setHistoryModalVisible(false);
              }}
              style={{ paddingVertical: 8 }}
            >
              <Text style={{ color: "#111" }}>
                Ver mes actual (sin historial)
              </Text>
            </TouchableOpacity>

            {historyOptions.map((opt) => (
              <TouchableOpacity
                key={opt.offset}
                onPress={() => {
                  setSelectedHistoryOffset(opt.offset);
                  setHistoryModalVisible(false);
                }}
                style={{ paddingVertical: 8 }}
              >
                <Text
                  style={{
                    color:
                      opt.offset === selectedHistoryOffset
                        ? PURPLE
                        : "#111",
                    fontWeight:
                      opt.offset === selectedHistoryOffset
                        ? "700"
                        : "400",
                  }}
                >
                  {opt.label}
                </Text>
              </TouchableOpacity>
            ))}

            <TouchableOpacity
              onPress={() => setHistoryModalVisible(false)}
              style={{ marginTop: 12 }}
            >
              <Text
                style={{
                  color: "#6b7280",
                  textAlign: "right",
                }}
              >
                Cerrar
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}
